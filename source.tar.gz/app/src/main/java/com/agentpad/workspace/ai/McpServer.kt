package com.agentpad.workspace.ai

import android.content.Context
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

/**
 * MCP 服务端：在手机上开一个 HTTP 端口，把本 App 的工具以 MCP 协议暴露出去，
 * 供其它 App、电脑上的 AI 客户端（Claude Desktop / Cursor / Cherry Studio…）调用。
 *
 * 协议：MCP「Streamable HTTP」——单端点 POST JSON-RPC 2.0，响应 application/json。
 * 支持方法：initialize / notifications/initialized / tools/list / tools/call / ping。
 *
 * 生命周期：由 [McpServerManager] 持有，进程内单例；开关在「设置 → MCP 服务」。
 */
class McpServer(
    private val context: Context,
    /** 工具来源：返回当前可用工具规格 */
    private val specProvider: () -> List<ToolSpec>,
    /** 工具执行：按名字执行，返回 JSON 字符串结果 */
    private val executor: (name: String, args: JSONObject) -> String,
) {

    companion object {
        private const val TAG = "McpServer"
        private const val PROTOCOL_VERSION = "2025-06-18"
        /** 请求体上限，超出直接 413。 */
        private const val MAX_BODY_BYTES = 8 * 1024 * 1024
        /** 请求头上限，防慢速灌头。 */
        private const val MAX_HEADER_BYTES = 32 * 1024
        /** 并发连接上限。 */
        private const val MAX_CONNECTIONS = 32
    }

    @Volatile private var serverSocket: ServerSocket? = null
    @Volatile private var running = false
    private var pool: ThreadPoolExecutor? = null
    private var acceptThread: Thread? = null

    /** 当前实际监听端口（0 表示未启动）。 */
    @Volatile var boundPort: Int = 0
        private set

    val isRunning: Boolean get() = running

    class Config(
        val port: Int,
        val allowLan: Boolean,
        val token: String,
        val exposedTools: Set<String>,
    )

    /**
     * 启动服务。抛异常表示启动失败（端口占用、局域网无令牌等）。
     */
    @Synchronized
    fun start(config: Config) {
        if (running) return
        // 局域网广播且无令牌 = 同一网段任何人可调用本机工具，直接拒绝启动。
        if (config.allowLan && config.token.isBlank()) {
            throw IllegalArgumentException("局域网模式下必须设置访问令牌")
        }
        val addr = if (config.allowLan) InetAddress.getByName("0.0.0.0") else InetAddress.getByName("127.0.0.1")
        val ss = ServerSocket(config.port, 50, addr)
        val p = ThreadPoolExecutor(
            2, MAX_CONNECTIONS, 60L, TimeUnit.SECONDS,
            LinkedBlockingQueue<Runnable>(MAX_CONNECTIONS * 2),
        )
        serverSocket = ss
        pool = p
        boundPort = ss.localPort
        running = true
        acceptThread = Thread({
            while (running) {
                val socket = try {
                    ss.accept()
                } catch (e: Exception) {
                    if (running) Log.w(TAG, "accept 失败：${e.message}")
                    break
                }
                try {
                    p.execute { runCatching { handle(socket, config) }.onFailure { Log.w(TAG, "处理异常：${it.message}") } }
                } catch (e: Exception) {
                    // 线程池饱和：丢弃该连接，不要静默挂死。
                    Log.w(TAG, "连接被拒绝：${e.message}")
                    runCatching { socket.close() }
                }
            }
        }, "mcp-accept").apply { isDaemon = true; start() }
        Log.i(TAG, "MCP 服务已启动：${if (config.allowLan) "0.0.0.0" else "127.0.0.1"}:$boundPort")
    }

    @Synchronized
    fun stop() {
        running = false
        runCatching { serverSocket?.close() }
        serverSocket = null
        // 关掉线程池，避免缓存线程长期驻留。
        runCatching { pool?.shutdownNow() }
        pool = null
        acceptThread = null
        boundPort = 0
    }

    // ---------------- HTTP 处理 ----------------

    private fun handle(socket: Socket, config: Config) {
        socket.use { s ->
            s.soTimeout = 30000
            val input = s.getInputStream()
            val out = s.getOutputStream()

            // 按字节读请求行与头部：绝不能用 BufferedReader，
            // 它会预读并把 body 字节吞进自己的缓冲区，导致后面按 Content-Length 读不足。
            val requestLine = try {
                readLine(input)
            } catch (e: LineTooLongException) {
                writeResponse(out, 431, "Request Header Fields Too Large", "{}")
                return
            } ?: run {
                writeResponse(out, 400, "Bad Request", "{}")
                return
            }
            val headers = HashMap<String, String>()
            var headerBytes = requestLine.length
            try {
                while (true) {
                    val line = readLine(input) ?: break
                    if (line.isEmpty()) break
                    headerBytes += line.length
                    if (headerBytes > MAX_HEADER_BYTES) {
                        writeResponse(out, 431, "Request Header Fields Too Large", "{}")
                        return
                    }
                    val idx = line.indexOf(':')
                    if (idx > 0) {
                        headers[line.substring(0, idx).trim().lowercase()] = line.substring(idx + 1).trim()
                    }
                }
            } catch (e: LineTooLongException) {
                // 超长头部：必须显式拒绝，不能当成「头部结束」继续处理，
                // 否则畸形请求会被当作合法请求放过去。
                writeResponse(out, 431, "Request Header Fields Too Large", "{}")
                return
            }

            val parts = requestLine.split(" ")
            if (parts.size < 2) {
                writeResponse(out, 400, "Bad Request", "{}")
                return
            }
            val method = parts[0].uppercase()
            val path = parts[1].substringBefore('?')
            val origin = headers["origin"]
            val tokenRequired = config.token.isNotBlank()
            // 只有配置了令牌才回显 CORS 来源；无令牌时不下发 ACAO，
            // 浏览器端的跨域 JS 会被同源策略挡住，避免任意网页驱动本机工具。
            val corsOrigin = if (tokenRequired) origin else null

            fun reply(code: Int, status: String, body: String, extra: String? = null) =
                writeResponse(out, code, status, body, corsOrigin, extra)

            // ---- CORS 预检 ----
            if (method == "OPTIONS") {
                reply(204, "No Content", "", "Allow: POST, GET, OPTIONS")
                return
            }

            // 健康检查
            if (method == "GET" && (path == "/health" || path == "/")) {
                reply(200, "OK", JSONObject()
                    .put("status", "ok").put("server", "AgentWorkspace-MCP")
                    .put("protocol", PROTOCOL_VERSION).toString())
                return
            }
            // SSE 端点（部分客户端会先 GET 建流；我们直接提示用 POST）
            if (method == "GET" && path == "/mcp") {
                reply(405, "Method Not Allowed",
                    JSONObject().put("error", "请使用 POST 调用 MCP").toString(),
                    "Allow: POST, OPTIONS")
                return
            }
            if (method != "POST") {
                reply(405, "Method Not Allowed", "{}", "Allow: POST, OPTIONS")
                return
            }
            if (path != "/mcp") {
                reply(404, "Not Found", "{}")
                return
            }

            // 鉴权
            if (tokenRequired) {
                val auth = headers["authorization"] ?: ""
                if (!auth.equals("Bearer ${config.token}", ignoreCase = true)) {
                    reply(401, "Unauthorized",
                        JSONObject().put("jsonrpc", "2.0").put("id", JSONObject.NULL)
                            .put("error", JSONObject().put("code", -32001).put("message", "unauthorized")).toString())
                    return
                }
            }

            // ---- 读 body（字节） ----
            val contentLength = headers["content-length"]?.toIntOrNull() ?: -1
            if (contentLength > MAX_BODY_BYTES) {
                reply(413, "Payload Too Large",
                    JSONObject().put("jsonrpc", "2.0").put("id", JSONObject.NULL)
                        .put("error", JSONObject().put("code", -32600).put("message", "请求体过大")).toString())
                return
            }
            if (contentLength < 0 && headers["transfer-encoding"] != null) {
                reply(411, "Length Required",
                    JSONObject().put("jsonrpc", "2.0").put("id", JSONObject.NULL)
                        .put("error", JSONObject().put("code", -32600).put("message", "需要 Content-Length")).toString())
                return
            }
            val bodyBytes = readBody(input, contentLength)
            if (bodyBytes == null) {
                reply(400, "Bad Request",
                    JSONObject().put("jsonrpc", "2.0").put("id", JSONObject.NULL)
                        .put("error", JSONObject().put("code", -32700).put("message", "请求体读取不完整")).toString())
                return
            }
            val body = String(bodyBytes, Charsets.UTF_8)

            val response = try {
                dispatch(body, config)
            } catch (e: Exception) {
                JSONObject().put("jsonrpc", "2.0").put("id", JSONObject.NULL)
                    .put("error", JSONObject().put("code", -32603).put("message", e.message ?: "internal error"))
            }

            // 通知类（无 id）返回 202 空体
            if (response == null) {
                reply(202, "Accepted", "")
            } else {
                reply(200, "OK", response.toString())
            }
        }
    }

    /** 单行超长时抛出，由调用方显式回 431，而不是当成头部结束。 */
    private class LineTooLongException : Exception("header line too long")

    /** 读一行（以 \n 结尾，去掉 \r）。实际按字节读，避免与 body 抢缓冲。 */
    private fun readLine(input: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = input.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) return sb.toString().trimEnd('\r')
            // 头部字段按 ISO-8859-1 语义处理：逐字节映射，不做 UTF-8 解码。
            sb.append((b and 0xFF).toChar())
            // 单行上限，防无 \n 的畸形请求把内存吃满。
            if (sb.length > MAX_HEADER_BYTES) throw LineTooLongException()
        }
    }

    /** 按字节精确读取 Content-Length 指定的长度，返回 null 表示连接提前断开。 */
    private fun readBody(input: InputStream, contentLength: Int): ByteArray? {
        if (contentLength <= 0) return ByteArray(0)
        val buf = ByteArray(contentLength)
        var read = 0
        while (read < contentLength) {
            val n = input.read(buf, read, contentLength - read)
            if (n < 0) return null
            read += n
        }
        return buf
    }

    /** 分发 JSON-RPC 方法。通知类返回 null。 */
    private fun dispatch(body: String, config: Config): JSONObject? {
        val req = runCatching { JSONObject(body) }.getOrElse {
            return JSONObject().put("jsonrpc", "2.0").put("id", JSONObject.NULL)
                .put("error", JSONObject().put("code", -32700).put("message", "解析失败"))
        }
        val id = if (req.has("id") && !req.isNull("id")) req.get("id") else null
        val method = req.optString("method", "")
        val params = req.optJSONObject("params") ?: JSONObject()

        fun ok(result: JSONObject): JSONObject =
            JSONObject().put("jsonrpc", "2.0").put("id", id).put("result", result)

        fun err(code: Int, msg: String): JSONObject =
            JSONObject().put("jsonrpc", "2.0").put("id", id)
                .put("error", JSONObject().put("code", code).put("message", msg))

        if (id == null) {
            // 客户端通知：不需要响应体
            return null
        }

        return when (method) {
            "initialize" -> ok(JSONObject()
                .put("protocolVersion", PROTOCOL_VERSION)
                .put("capabilities", JSONObject().put("tools", JSONObject()))
                .put("serverInfo", JSONObject()
                    .put("name", "agentpad-workspace").put("version", "1.0.0")))

            "ping" -> ok(JSONObject())

            "tools/list" -> {
                val arr = JSONArray()
                exposedSpecs(config).forEach { spec ->
                    val schema = runCatching { JSONObject(spec.parametersSchema) }
                        .getOrElse { JSONObject().put("type", "object") }
                    arr.put(JSONObject()
                        .put("name", spec.name)
                        .put("description", spec.description)
                        .put("inputSchema", schema))
                }
                ok(JSONObject().put("tools", arr))
            }

            "tools/call" -> {
                val name = params.optString("name", "")
                val args = params.optJSONObject("arguments") ?: JSONObject()
                if (name.isBlank()) return err(-32602, "缺少工具名")
                if (!isExposed(name, config)) return err(-32602, "工具未开放：$name")
                val resultText = runCatching { executor(name, args) }
                    .getOrElse { JSONObject().put("success", false).put("error", it.message ?: "执行失败").toString() }
                ok(JSONObject()
                    .put("content", JSONArray().put(JSONObject().put("type", "text").put("text", resultText)))
                    .put("isError", runCatching { JSONObject(resultText).optBoolean("success", true) }.getOrDefault(true).not()))
            }

            else -> err(-32601, "未知方法：$method")
        }
    }

    private fun isExposed(name: String, config: Config): Boolean =
        config.exposedTools.isEmpty() || name in config.exposedTools

    private fun exposedSpecs(config: Config): List<ToolSpec> =
        specProvider().filter { isExposed(it.name, config) }

    // ---------------- HTTP 输出 ----------------

    private fun writeResponse(
        out: OutputStream,
        code: Int,
        status: String,
        body: String,
        corsOrigin: String? = null,
        extraHeaders: String? = null,
    ) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        val header = buildString {
            append("HTTP/1.1 $code $status\r\n")
            append("Content-Type: application/json; charset=utf-8\r\n")
            append("Content-Length: ${bytes.size}\r\n")
            if (corsOrigin != null) {
                append("Access-Control-Allow-Origin: $corsOrigin\r\n")
                append("Vary: Origin\r\n")
            }
            append("Access-Control-Allow-Headers: Content-Type, Authorization, Mcp-Session-Id\r\n")
            append("Access-Control-Allow-Methods: POST, GET, OPTIONS\r\n")
            if (extraHeaders != null) append("$extraHeaders\r\n")
            append("Connection: close\r\n")
            append("\r\n")
        }
        runCatching {
            out.write(header.toByteArray(Charsets.UTF_8))
            if (bytes.isNotEmpty()) out.write(bytes)
            out.flush()
        }
    }
}
