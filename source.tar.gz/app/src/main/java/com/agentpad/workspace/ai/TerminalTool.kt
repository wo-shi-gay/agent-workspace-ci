package com.agentpad.workspace.ai

import org.json.JSONObject

data class TerminalRequest(val command: String, val cwd: String? = null, val timeoutMs: Long? = null)
data class TerminalOutput(val exitCode: Int, val stdout: String, val stderr: String)

interface TerminalBackend {
    fun run(request: TerminalRequest): TerminalOutput
}

class TerminalTool(private val backend: TerminalBackend) {
    fun execute(args: JSONObject): String {
        val request = TerminalRequest(
            command = args.optString("command"),
            cwd = args.optString("cwd").takeIf { it.isNotBlank() },
            timeoutMs = args.optLong("timeout_ms", 120_000L).takeIf { it > 0 }
        )
        val result = backend.run(request)
        val stdout = truncate(result.stdout, 1800)
        val stderr = truncate(result.stderr, 1200)
        val summary = buildString {
            append(if (result.exitCode == 0) "done" else "error")
            append(" | exit_code=")
            append(result.exitCode)
            if (stdout.isNotBlank()) append(" | stdout_chars=").append(result.stdout.length)
            if (stderr.isNotBlank()) append(" | stderr_chars=").append(result.stderr.length)
        }
        return JSONObject()
            .put("success", result.exitCode == 0)
            .put("status", if (result.exitCode == 0) "success" else "error")
            .put("summary", summary)
            .put("exit_code", result.exitCode)
            .put("stdout", stdout)
            .put("stderr", stderr)
            .put("stdout_truncated", result.stdout.length > stdout.length)
            .put("stderr_truncated", result.stderr.length > stderr.length)
            .toString()
    }

    private fun truncate(text: String, maxChars: Int): String {
        if (text.length <= maxChars) return text
        val head = text.take(maxChars / 2)
        val tail = text.takeLast(maxChars / 2)
        return "$head\n... [truncated ${text.length - maxChars} chars] ...\n$tail"
    }
}