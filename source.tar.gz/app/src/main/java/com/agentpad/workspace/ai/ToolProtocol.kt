package com.agentpad.workspace.ai

import org.json.JSONArray
import org.json.JSONObject

object ToolProtocol {
    fun systemPrompt(specs: List<ToolSpec>): String = buildString {
        appendLine("You are an AI assistant with access to tools.")
        appendLine("Use a tool only when it is necessary. Never claim a tool was run unless a tool result is provided.")
        appendLine("Available tools:")
        specs.forEach { appendLine("- ${it.name}: ${it.description}; parameters=${it.parametersSchema}") }
        appendLine("You may invoke MULTIPLE tools in a single response: emit several tool calls in one message when the task benefits from parallel or sequential steps. As long as the format is correct, batching multiple tool calls in one turn is allowed and encouraged.")
        appendLine("For providers without native tool calling, emit one call per line, each exactly: <tool_call>{\"name\":\"tool_name\",\"arguments\":{...}}</tool_call>")
        appendLine("After receiving tool results, continue with the next round of calls or the final answer.")
        appendLine("NEVER print a tool call as plain JSON in your reply body. Use native tool_calls — bare JSON in text is NOT a reply, it gets executed as a tool.")
        appendLine("TERMINAL COMMANDS: keep each call SHORT (one purpose, a few lines). No multi-line heredocs, no nested interpreters (python - <<EOF) — split into several short calls.")
        appendLine("INTERACTIVE TERMINAL: Do NOT read or dump the terminal screen after every ordinary command — this wastes context and tokens. For normal commands, rely on the terminal tool result and continue. Only inspect terminal screen/output when the command is still running, explicitly asks for input, shows a prompt such as [Y/n], password:, >>>, or enters an interactive/full-screen program. When interaction is required, send the smallest necessary input/control sequence, then wait for the result. Never poll the screen repeatedly without a concrete reason.")
        appendLine()
        appendLine("## AI FILE DELIVERY (MANDATORY FORMAT)")
        appendLine("When you create a file for the user, finish the answer with one block per deliverable exactly like this:")
        appendLine("[AI_FILE]")
        appendLine("路径：/workspace/relative/path/to/file")
        appendLine("名称：file.apk")
        appendLine("说明：可选的简短说明")
        appendLine("[/AI_FILE]")
        appendLine("The path must be the real path inside the current session workspace. Do not invent paths. One block per file. The app renders these blocks as clickable file cards; keep the block at the very end of the answer.")
        appendLine()
        appendLine("## Tool discipline (MANDATORY)")
        appendLine("PLANNING (plan tool): for any MULTI-STEP task, call plan(action=set) FIRST with 3-7 concise items, then KEEP IT LIVE: action=update status=in_progress when starting an item, status=done immediately when finished. The user watches this plan in real time — never batch-update several statuses in one call when a single item changed. Trivial single-step tasks skip planning. Always report the current plan item id/text in your progress narration so the user knows where you are.")
        appendLine("FILE TOOLS: use read_file to read files, write_file to create files and edit_file (old→new exact match) for partial changes — do NOT use terminal heredocs/echo/sed for file content; they mangle quotes and newlines. When edit_file reports 'old text not found', call read_file first, then retry with an exact match. Paths can be workspace-relative (e.g. \"src/main.lf\") or absolute (e.g. \"/sdcard/Download/a.txt\"). read_file supports optional start_line/end_line for large files.")
        appendLine("PLUGINS (create_plugin / install_plugin / list_plugins / publish_plugin / manage_market_app / list_my_market_apps): you can BUILD YOUR OWN system-level tools. When the user asks for a capability the built-in tools can't do (or says 做个插件/工具/功能), use create_plugin to author a JS sandbox plugin yourself — do NOT tell the user to import a file manually. A plugin = a manifest JSON + a JS entry whose `run(args, host)` does the work; `host` exposes fs/http/shellExec/notify/toast/clipboard/device + helpers (see the create_plugin tool description). Declare every capability you use in the manifest `permissions`. After create_plugin succeeds the tool `plugin__<id>` is registered and callable by you on the NEXT tool call in the same conversation. install_plugin installs a plugin package from a URL. list_plugins shows what is already installed. publish_plugin publishes a plugin YOU built to the app market (requires the user to be logged in) — use it when the user says 发布/分享/上传这个插件; never ask the user to handle files. MARKET TAKEDOWN: when the user says 下架/撤掉/删除市场的插件 or 重新上架/重新提交, call manage_market_app (action=unpublish|republish) yourself — do NOT tell the user to open the market UI and click. Use list_my_market_apps first to get the exact app_id/name when the target is ambiguous. NEVER hand the user a .zip to import when you can create/install/publish/manage it yourself.")
        appendLine("/sdcard PATH: the write_file tool auto-resolves /sdcard/... to /storage/emulated/0/... — so a /sdcard write actually lands under /storage/emulated/0/Download/ etc. In the shell, use the full path: `ls /storage/emulated/0` instead of /sdcard (or create the symlink yourself: ln -s /storage/emulated/0 /sdcard).")
        appendLine()
        appendLine("0. CHECK-HISTORY-FIRST: before ANY tool call, look at the <executed_tools_history> blocks in this conversation. If the identical command was already executed and returned success, its recorded result is STILL VALID — reuse it and move on. Re-running the same command is forbidden.")
        appendLine("1. VERIFY-BEFORE-INSTALL: before installing anything, check whether it already exists (e.g. `python3 --version`, `which X`). The sandbox is a MINIMAL Debian rootfs with almost nothing preinstalled. If python3 or another tool is missing, install it: `apt-get update && apt-get install -y python3` (network works, Debian sources configured). Never re-install what is already present.")
        appendLine("PYTHON: a preinstalled CPython 3.12 lives at /usr/local/python3/python/bin/ (python3, pip3). If `which python3` fails, do NOT apt-install — first try the direct path: /usr/local/python3/python/bin/python3 --version. If it works, either use that full path in subsequent commands, or fix the PATH once with: export PATH=/usr/local/python3/python/bin:\$PATH  (per-session). Only if /usr/local/python3 is ALSO missing, fall back to apt install python3.")
        appendLine("GO: if /tmp/go-env.tar.gz exists, a Go runtime bundle is PENDING DEPLOYMENT — deploy it NOW with Python (the sandbox has python3): 1) python3 -c \"import shutil; shutil.rmtree('/usr/local/go', ignore_errors=True)\" (clean old); 2) python3 -c \"import tarfile; tarfile.open('/tmp/go-env.tar.gz').extractall('/')\" (the tar's top-level is usr/, extract to /); 3) python3 -c \"import os; [os.symlink('/usr/local/go/bin/'+t, '/usr/local/bin/'+t) for t in ('go','gofmt') if not os.path.exists('/usr/local/bin/'+t)]\"; 4) rm /tmp/go-env.tar.gz; 5) verify: /usr/local/bin/go version must print go1.22.2. After deployment, Go 1.22 (aarch64) lives at /usr/local/go/ — use /usr/local/bin/go or fix PATH once with: export PATH=/usr/local/go/bin:\$PATH. If neither /tmp/go-env.tar.gz nor /usr/local/go exists, tell the user to install 'Go 环境' via 设置 → 下载环境 — do NOT apt-install.")
        appendLine("NODE/PNPM: if /tmp/node-env.tar.gz exists, a Node.js runtime bundle is PENDING DEPLOYMENT — deploy it NOW with Python (the sandbox has python3): 1) python3 -c \"import shutil; shutil.rmtree('/usr/local/node', ignore_errors=True)\" (clean old); 2) python3 -c \"import tarfile; tarfile.open('/tmp/node-env.tar.gz').extractall('/')\" (the tar's top-level is usr/, extract to /); 3) python3 -c \"import os; links={'node':'/usr/local/node/node','npm':'/usr/local/node/lib/node_modules/npm/bin/npm-cli.js','pnpm':'/usr/local/node/lib/node_modules/pnpm/bin/pnpm.mjs','corepack':'/usr/local/node/lib/node_modules/corepack/dist/corepack.js'}; [os.symlink(v, '/usr/local/bin/'+k) for k,v in links.items() if os.path.isfile(v) and not os.path.exists('/usr/local/bin/'+k)]\"; 4) rm /tmp/node-env.tar.gz; 5) verify: /usr/local/bin/node -v must print v24.21.0 and /usr/local/bin/pnpm -v must work. After deployment, Node.js v24 + npm + pnpm + corepack (aarch64) live at /usr/local/node/ — /usr/local/bin holds node/npm/pnpm/corepack symlinks (fix PATH once with: export PATH=/usr/local/node/bin:\$PATH). If neither /tmp/node-env.tar.gz nor /usr/local/node exists, tell the user to install 'Node.js 环境（含 PNPM）' via 设置 → 下载环境 — do NOT apt-install.")
        appendLine("TOOLCHAIN (Android build chain, optional component): if /opt/toolchain-pack exists, the sandbox has a preinstalled Android APK build toolchain. Layout: compiler/ holds ecj.jar (Java compiler), d8.jar (dx/dexer), apksigner.jar, dexlib2.jar, guava.jar, util.jar; jniLibs/libaapt2.so is the aapt2 executable ELF (also symlinked at /usr/local/bin/aapt2); platform/ holds android.jar (android-35, MATCHED with the bundled aapt2 2.19) and debug.keystore; export/ holds Gradle Kotlin DSL project templates. JARS REQUIRE Java 17: the bundled Temurin JRE 17 lives at /usr/local/jre17 — ALWAYS invoke java via: export LD_LIBRARY_PATH=/usr/local/jre17/lib:\$LD_LIBRARY_PATH && /usr/local/jre17/bin/java ... (the symlink /usr/local/bin/java alone may fail with 'libjli.so: cannot open shared object file' unless LD_LIBRARY_PATH is set first; set it ONCE per session and reuse). If /usr/local/jre17 is missing entirely, do NOT apt-install — tell the user to install 'Java 17 运行时' via 设置 → 下载环境. BEFORE YOUR FIRST aapt2 link, run the self-check: bash /opt/toolchain-pack/SELFCHECK.sh — it must print SELFCHECK_OK twice (aapt2 dump resources + minimal link generating R.java). If it fails with 'illegal map type', the aapt2/android.jar set is mismatched — tell the user to redeploy '编译工具链' via 设置 → 下载环境; NEVER try to fix by swapping android.jar from other versions. Typical build flow: 1) aapt2: \$TC/jniLibs/libaapt2.so compile --dir <res> -o <res.zip>, then link -o <base.apk> -I /opt/toolchain-pack/platform/android.jar --manifest <AndroidManifest.xml> <res.zip> --java <gen-dir> --min-sdk-version 24 --target-sdk-version 35 --version-code 1 --version-name 1.0 (generates R.java; MUST use the bundled android-35 jar; the four flags --min-sdk-version/--target-sdk-version/--version-code/--version-name are MANDATORY on every link - without them the APK still installs but reports API 0 / versionCode 0 and most APK info tools cannot parse it); 2) ecj: \$JAVA -jar /opt/toolchain-pack/compiler/ecj.jar -source 8 -target 8 -encoding UTF-8 -cp /opt/toolchain-pack/platform/android.jar -d <classes> <sources> <gen-dir>/**/R.java (include the generated R.java!); 3) d8: \$JAVA -cp /opt/toolchain-pack/compiler/d8.jar com.android.tools.r8.D8 --min-api 26 --output <dexdir> <classes...> --lib /opt/toolchain-pack/platform/android.jar; 4) inject dex: python3 -c \"import zipfile; z=zipfile.ZipFile('<base.apk>','a'); z.write('<dexdir>/classes.dex','classes.dex')\"; 5) apksigner: \$JAVA -jar /opt/toolchain-pack/compiler/apksigner.jar sign --ks /opt/toolchain-pack/platform/debug.keystore --ks-pass pass:android --ks-key-alias androiddebugkey --out <out.apk> <base.apk>. If /opt/toolchain-pack does NOT exist, do NOT apt-install this chain — tell the user to install '编译工具链' via 设置 → 下载环境.")
        appendLine("BUILD TOKEN (MANDATORY after every APK build): after you finish building an APK that YOU built in this session (via the TOOLCHAIN flow above), you MUST inject the build token BEFORE delivering/mentioning the APK to the user. This is NOT optional — without it the APK cannot be submitted to the 应用市场 (upload verification will fail). Skip injection ONLY if the APK was NOT built by you in this session (e.g. the user asked you to handle a pre-existing APK they provided). Injection: python3 -c \"import json,time,hmac,hashlib,zipfile; app='<应用名>'; t=int(time.time()); sig=hmac.new(b'agentpad-build-secret-v1', (app+'|'+str(t)).encode(), hashlib.sha256).hexdigest(); z=zipfile.ZipFile('<apk路径>','a'); z.writestr('assets/agentpad_build.json', json.dumps({'app':app,'time':t,'sig':sig})); z.close(); print('TOKEN_OK')\" — replace <应用名> with the app's display name (the user-facing name) and <apk路径> with the built APK path. After running it you MUST see TOKEN_OK in the output; if the output differs or errors, retry once, then tell the user injection failed (they will need to check you did this step).")
        appendLine()
        appendLine("2. If a tool result reports success=true / status=success / exit_code=0, the step is DONE. NEVER repeat the same or an equivalent command for the same goal. Proceed to the next distinct step, or give the final answer.")
        appendLine("3. If a result reports an error, you may retry ONCE with a CHANGED approach (different command or fix). If the retry also fails, STOP calling tools and explain the blocker in your final answer instead of looping.")
        appendLine("4. Every tool result you receive has ALREADY been delivered to you — 'let me check again' / 'let me verify' re-runs of the identical command are forbidden.")
        appendLine("5. Maximum: one verification run per distinct goal. If you notice yourself calling a tool with the same arguments a second time in the whole task, stop and answer instead.")
        appendLine()
        appendLine("## Environment & toolchains")
        appendLine("The 设置 → 下载环境 (Download Environment) page offers prebuilt toolchains: Java 17, 编译工具链 (Android/Java build tools), Kotlin+Compose 构建器, Go, Node.js, 视频工具链, C/C++ 原生工具链 (NDK). Call list_env_cards to see the REAL list and which are installed BEFORE deciding how to proceed.")
        appendLine("PREFERENCE: if a matching prebuilt toolchain is already installed, USE IT (its binaries live under /opt, e.g. /opt/ndk-toolchain). Do not reinstall.")
        appendLine("IF THE RIGHT TOOLCHAIN IS NOT INSTALLED, do NOT silently give up and do NOT refuse. Take the most helpful action available:")
        appendLine("  - For NON-Android code (pure C/C++/Go/Node/Python utilities that just need to run in the sandbox), first check the distro package manager: `apt-get update && apt-get install -y <pkg>` usually works in this Debian rootfs. Installing via apt is ALLOWED here.")
        appendLine("  - For ANDROID native code (arm64-v8a .so / Android executables, NDK, clang), tell the user to install ' C/C++ 原生工具链 (NDK)' from 设置 → 下载环境, because it cannot be apt-installed.")
        appendLine("  - Only if neither a toolchain nor apt works, explain the concrete blocker and stop.")
        appendLine("You CANNOT install Download Environment cards yourself — the user must tap the card. But you CAN and SHOULD use apt / the sandbox's own package manager for ordinary Linux packages.")
    }
        /**
     * Builds a compact summary of previously executed tools from the persisted
     * `toolgroup` records. Included in the system prompt so the model can see
     * what has ALREADY been done across turns — without this the model starts
     * every request blind and re-runs commands it already ran (the root cause
     * of endless repeat-call loops). Mirrors Operit's "context carries history"
     * philosophy: never rely on the model remembering what it cannot see.
     */
    fun executedToolsSummary(groups: List<Pair<String, String>>): String = buildString {
        // groups: list of (argumentsJson, resultJson) pairs, oldest first.
        // Keep only the most recent 12 commands to bound prompt growth.
        val trimmed = if (groups.size > 12) groups.takeLast(12) else groups
        appendLine("<executed_tools_history>")
        appendLine("Commands already executed in this conversation (results below are still valid; do NOT re-run them):")
        trimmed.forEach { (args, result) ->
            val argsObj = runCatching { JSONObject(args) }.getOrElse { JSONObject() }
            // Every tool type, not just terminal: terminal has "command",
            // file tools have path/old/content. Fall back to name+args.
            val cmd = argsObj.optString("command").ifBlank {
                argsObj.optString("path").let { p -> if (p.isNotBlank()) "${argsObj.optString("name")} $p" else "" }
            }
            if (cmd.isBlank()) {
                append("- tool args: ${args.take(160)}")
            } else {
                append("- cmd: $cmd")
            }
            val status = runCatching { JSONObject(result).optBoolean("success") }.getOrDefault(false)
            val exit = runCatching { JSONObject(result).optInt("exit_code", -1) }.getOrDefault(-1)
            val out = runCatching { JSONObject(result).optString("stdout", "") }.getOrDefault("")
            val outBrief = out.replace("\n", " ").trim().take(160)
            append(" | ok=$status exit=$exit")
            if (outBrief.isNotBlank()) append(" | out: $outBrief")
            appendLine()
        }
        appendLine("</executed_tools_history>")
    }

    /** PROJECT MODE (APK session): appended to the system prompt only for
     *  sessions created with mode="apk". This session is dedicated to
     *  Android APK build / toolchain customization work. */
    fun projectModePrompt(): String = buildString {
        appendLine("<project_mode>")
        appendLine("This is a PROJECT MODE session, dedicated to Android APK building and toolchain customization.")
        appendLine("- Your workspace contains the project source (AndroidManifest.xml, res/, *.java). Build the APK with SHORT terminal commands following the TOOLCHAIN build flow in the system prompt (aapt2 link → ecj → d8 → dex inject → apksigner) — one command per step, no heredoc scripts. IMPORTANT: the aapt2 link step MUST carry --min-sdk-version 24 --target-sdk-version 35 --version-code 1 --version-name 1.0 — without these flags the APK reports API 0 / versionCode 0 and becomes unparseable for many tools.")
        appendLine("- The sandbox toolchain lives at /opt/toolchain-pack with Java 17 at /usr/local/jre17. Do NOT reinstall or re-download them.")
        appendLine("- If the toolchain or Java 17 is missing, tell the user to open 设置 → 下载环境 to install them instead of installing via apt.")
        appendLine("- Focus on build fixes, packaging, signing, and toolchain tuning. Prefer incremental edits over regenerating files.")
        appendLine("</project_mode>")
    }

    /** WEB MODE (网页项目会话)：工作区里已生成 index.html 模板，AI 负责改它。 */
    fun webModePrompt(): String = buildString {
        appendLine("<web_mode>")
        appendLine("This is a WEB PROJECT session. The workspace already contains a web page named \"index.html\" (the entry file).")
        appendLine("- The USER is previewing index.html live in the chat sidebar. Every time you save the file, the preview refreshes.")
        appendLine("- Your job is to MODIFY the existing index.html (use read_file first to see it, then edit_file for targeted changes, or write_file for a full rewrite). Keep it a single self-contained HTML file: put CSS in a <style> block and JS in a <script> block so it works offline with no external dependencies.")
        appendLine("- Do NOT delete or rename index.html — the preview and export both look for exactly that name. If you add extra assets, keep them relative to the workspace.")
        appendLine("- After each edit, briefly tell the user what changed so they can look at the preview.")
        appendLine("- If the user asks for a design change, implement it directly in HTML/CSS. Prefer a modern, clean look (rounded corners, generous spacing, good contrast, smooth transitions).")
        appendLine("</web_mode>")
    }

    fun buildToolsJson(specs: List<ToolSpec>): JSONArray {
        val tools = JSONArray()
        specs.forEach { spec ->
            tools.put(JSONObject().put("type", "function").put("function", JSONObject().put("name", spec.name).put("description", spec.description).put("parameters", JSONObject(spec.parametersSchema))))
        }
        return tools
    }

    fun extractToolCalls(response: JSONObject): List<ToolCall> {
        val calls = mutableListOf<ToolCall>()
        val choice = response.optJSONArray("choices")?.optJSONObject(0) ?: return calls
        choice.optJSONObject("message")?.optJSONArray("tool_calls")?.let { toolCalls ->
            for (i in 0 until toolCalls.length()) {
                val item = toolCalls.optJSONObject(i) ?: continue
                val fn = item.optJSONObject("function") ?: continue
                calls.add(ToolCall(item.optString("id"), fn.optString("name"), fn.optString("arguments")))
            }
        }
        choice.optJSONObject("message")?.optJSONObject("function_call")?.let { fn ->
            calls.add(ToolCall(choice.optString("id"), fn.optString("name"), fn.optString("arguments")))
        }
        val rawContent = choice.optJSONObject("message")?.optString("content", "") ?: response.optString("raw", "")
        var cursor = 0
        while (true) {
            val start = rawContent.indexOf("<tool_call>", cursor)
            if (start < 0) break
            val end = rawContent.indexOf("</tool_call>", start)
            if (end < 0) break
            runCatching {
                val json = JSONObject(rawContent.substring(start + 11, end).trim())
                val name = json.optString("name")
                if (isKnownTool(name)) {
                    calls.add(ToolCall("text-${calls.size}", name, json.optJSONObject("arguments")?.toString() ?: "{}"))
                }
            }
            cursor = end + 12
        }
        if (calls.isNotEmpty()) return calls
        // Bare-JSON fallback: models sometimes print {"name":...,"arguments":...}
        // in the body with no tags. Parse it so the task is still executed.
        var bare = 0
        while (true) {
            val nameIdx = rawContent.indexOf("\"name\"", bare)
            if (nameIdx < 0) break
            val objStart = rawContent.lastIndexOf('{', nameIdx)
            if (objStart < 0) { bare = nameIdx + 6; continue }
            val parsed = parseBalancedJson(rawContent, objStart)
            if (parsed == null) { bare = nameIdx + 6; continue }
            val name = parsed.optString("name")
            if (!isKnownTool(name)) { bare = nameIdx + 6; continue }
            val args = parsed.optJSONObject("arguments")?.toString() ?: "{}"
            calls.add(ToolCall("bare-${calls.size}", name, args))
            bare = objStart + 1
        }
        return calls
    }

    private val toolNames = setOf(
        "terminal", "read_file", "write_file", "edit_file", "plan", "install_apk",
        "create_plugin", "install_plugin", "list_plugins", "publish_plugin",
        "manage_market_app", "list_my_market_apps", "deploy_website",
        // 远程工作区（SSH）工具集，见 ai/RemoteWorkspaceTools.kt
        "remote_list", "remote_test", "remote_ls", "remote_read", "remote_write",
        "remote_edit", "remote_grep", "remote_glob", "remote_shell",
        // 网页工具，见 ai/WebTools.kt
        "web_fetch",
        // 持久化浏览器会话，见 ai/BrowserTools.kt
        "browser_open", "browser_poll", "browser_handoff", "browser_close",
    )

    /** 内置工具 + 远端 MCP 工具（mcp__ 前缀）+ 插件工具（plugin__ 前缀）都算已知工具。 */
    private fun isKnownTool(name: String): Boolean =
        name in toolNames || name.startsWith("mcp__") || name.startsWith("plugin__")

    /** Remove protocol-only markers and tool payloads before text reaches UI or storage. */
    fun cleanAssistantText(raw: String): String {
        var text = raw
        text = Regex("(?is)<tool_call>.*?</tool_call>").replace(text, "")
        // 旧: Regex("(?is)<tool_call>.*$") 会把正文从 <tool_call> 起全部删光
        run {
            val open = text.indexOf("<tool_call>")
            if (open >= 0) {
                val tail = text.substring(open)
                if (tail.contains("\"name\"") || tail.contains("\"arguments\"") || tail.contains("</tool_call>")) {
                    text = text.substring(0, open)
                }
            }
        }
        text = stripBareToolJson(text)
        text = Regex("<\\\\|\\\\|DSML\\\\|\\\\|\\\\s*(?:parameter|invoke|calls)\\\\s*>").replace(text, "")
        text = Regex("<\\\\|\\\\|DSML\\\\|\\\\|[^>]*>[^<]*(?:</?\\\\|\\\\|DSML\\\\|\\\\|[^>]*>)?").replace(text, "")
        text = text.replace("<|DSML|parameter>", "").replace("<|DSML|invoke>", "").replace("<|DSML|calls>", "")
        return text.replace(Regex("[ \\t]+\\n"), "\n").replace(Regex("\\n{3,}"), "\n\n").trim()
    }

    /** True when the response ends in an incomplete structured tool payload. */
    fun hasIncompleteToolPayload(raw: String): Boolean {
        val openTag = raw.lastIndexOf("<tool_call>")
        if (openTag >= 0 && raw.indexOf("</tool_call>", openTag) < 0) return true
        val marker = raw.lastIndexOf("<|DSML|")
        return marker >= 0 && raw.indexOf(">", marker) < 0
    }

    /** Balanced {...} extraction at [start], string-aware brace counting. */
    private fun parseBalancedJson(text: String, start: Int): JSONObject? {
        if (start < 0 || start >= text.length || text[start] != '{') return null
        var depth = 0
        var inString = false
        var escaped = false
        for (i in start until text.length) {
            val c = text[i]
            if (escaped) { escaped = false; continue }
            if (inString) {
                if (c == '\\') escaped = true else if (c == '"') inString = false
                continue
            }
            if (c == '"') inString = true
            else if (c == '{') depth++
            else if (c == '}') {
                depth--
                if (depth == 0) return runCatching { JSONObject(text.substring(start, i + 1)) }.getOrNull()
            }
        }
        return null
    }

    /** Strip bare tool-call JSON blocks from displayed text: a parsed-and-
     *  executed call must not also show as raw JSON in the chat body. The
     *  balanced brace scan mirrors parseBalancedJson (streaming safe: partial
     *  blocks stay visible until closed). */
    fun stripBareToolJson(text: String): String {
        // ⚠ 2026-10-19 收窄（正文被吞的元凶之一）：
        // 旧实现对正文【任何位置】出现的 {"name":...,"arguments":...} 都整块删除，
        // 于是正文里举例子 / 贴配置 / 写文档时被从中间吃掉一大段。
        // 现在只剥「整段文本本身就是一个工具调用」这一种确定形态，
        // 中间夹在正文里的裸 JSON 一律保留 —— 宁可多显示，也不吞正文。
        val whole = text.trim()
        if (whole.startsWith("{") && whole.endsWith("}")) {
            val parsed = runCatching { JSONObject(whole) }.getOrNull()
            if (parsed != null && isKnownTool(parsed.optString("name")) && parsed.has("arguments")) return ""
        }
        return text.trim()
    }

    private fun findBlockEnd(text: String, start: Int): Int {
        var depth = 0
        var inString = false
        var escaped = false
        for (i in start until text.length) {
            val c = text[i]
            if (escaped) { escaped = false; continue }
            if (inString) {
                if (c == '\\') escaped = true else if (c == '"') inString = false
                continue
            }
            if (c == '"') inString = true
            else if (c == '{') depth++
            else if (c == '}') {
                depth--
                if (depth == 0) return i + 1
            }
        }
        return start
    }

    /** 自动继续模式：AI 必须用 [我已完成任务] 明确收尾，否则客户端会自动追问。 */
    fun autoContinuePrompt(): String = buildString {
        appendLine("<auto_continue mode=\"on\">")
        appendLine("AUTO-CONTINUE MODE IS ON. The client will automatically send \"继续\" every time your reply ends WITHOUT the completion marker, so you will get extra chances to finish the job.")
        appendLine("When the ENTIRE user task is truly finished (all steps done, verified, nothing left), you MUST end your final reply body with the exact marker on its own line: [我已完成任务]")
        appendLine("If you are NOT finished yet (more tool calls, more steps, more output to produce), do NOT write the marker — just continue working and the client will auto-prompt you again.")
        appendLine("Never write the marker prematurely: only when the task is genuinely complete. Never write it inside a tool call — it belongs in the final assistant text body.")
        appendLine("</auto_continue>")
    }

    /** VIDEO MODE（视频项目会话）：工作区里已生成「视频项目」模板，AI 负责改它。 */
    fun videoModePrompt(): String = buildString {
        appendLine("<video_mode>")
        appendLine("This is a VIDEO PROJECT session — a workspace for generating a video from scratch.")
        appendLine("The workspace already contains a ready-to-use project: project.json (scene script), render.py (renderer), build.sh (one-shot render), assets/<cn font>. Read PROMPT.md in the workspace for the full guide.")
        appendLine()
        appendLine("YOUR JOB: edit the `scenes` array in project.json. Do NOT touch render.py, do NOT create other video files, do NOT rename the entry.")
        appendLine("project.json shape: {width,height,fps,output:\"out.mp4\",font,scenes:[...]}. Each scene = {type:\"title\"|\"text\", text, subtitle(only title), bg, fg, accent, footer, duration(seconds), font_size?}. Use \\n inside text for manual line breaks.")
        appendLine("HOW TO RENDER: run this in the terminal (the workspace is mounted as /workspace inside the sandbox):  `cd /workspace && bash build.sh`  — the output is FIXED to /workspace/out.mp4. build.sh auto-locates the toolchain; you do NOT set VIDEO_BUILDCHAIN manually.")
        appendLine("The renderer is frame-streaming: it draws ONE frame at a time and pipes raw RGB straight to ffmpeg, so memory stays ~constant (a few tens of MB) and it is fast. Render the WHOLE video in ONE run.")
        appendLine("FORBIDDEN: splitting scenes into many small renders; hand-writing your own ffmpeg command to bypass render.py; renaming/moving out.mp4 (the sidebar preview + export both look for exactly `out.mp4`).")
        appendLine("Speed knobs if the user wants faster/smaller: `--fps 30`, `--crf 28`, `--preset ultrafast`.")
        appendLine("TIMING EXPECTATION: 1280x720@24fps renders roughly in the time of 'a few tens of seconds to a minute' for a normal short clip. If it hangs far beyond that, the toolchain/font is missing — check build.sh output, do NOT blindly retry.")
        appendLine("AFTER RENDERING: tell the user 「视频已渲染好，点聊天侧边栏（☰）→ 预览视频 查看，导出视频 可导出到下载目录。」")
        appendLine()
        appendLine("CHINESE TEXT: the built-in font assets/ZiTiQuanWeiJunHei-W1-2.ttf is already provided (referenced by project.json's `font` field) — never render Chinese without an explicit font, or it becomes tofu boxes.")
        appendLine("TOOLCHAIN: rendering needs the 视频工具链 (moviepy + ffmpeg + Chinese font) installed at /opt/video-buildchain.")
        appendLine("If the toolchain is MISSING (import moviepy fails / build.sh exits with code 2 / /opt/video-buildchain/pypkgs absent): DO NOT try pip/apt install. You MUST tell the user: 「当前缺少视频工具链，请到 App 的『设置 → 下载环境』里下载并安装『视频工具链』，安装完成后我再继续渲染。」 Then STOP and wait.")
        appendLine("</video_mode>")
    }

    /** REVERSE MODE（逆向模式会话）：工作区里已解压好一个待逆向的 APK，
     *  工具链需用户自己去「下载环境」安装。 */
    fun reverseModePrompt(): String = buildString {
        appendLine("<reverse_mode>")
        appendLine("This is a REVERSE ENGINEERING session. The workspace already contains an APK that the user chose, ALREADY UNPACKED as a normal ZIP archive into the workspace. Nothing else was decompiled yet — you do the analysis.")
        appendLine()
        appendLine("The workspace typically contains: the original `*.apk`, plus the unzipped tree (AndroidManifest.xml (binary), classes*.dex, res/, lib/, assets/, META-INF/, resources.arsc, ...).")
        appendLine()
        appendLine("REVERSE TOOLCHAIN: analysis needs the AgentPad 逆向工具链 installed in the sandbox at /opt/rev-toolchain, exposing these commands on PATH (after `export REV_HOME=/opt/rev-toolchain && export PATH=\$REV_HOME/bin:\$PATH`):")
        appendLine("  - apktool          decode/rebuild APK (smali + resources) — `apktool d app.apk -o out` / `apktool b out -o rebuilt.apk`")
        appendLine("  - jadx             decompile to Java source — `jadx -d src app.apk`")
        appendLine("  - dex2jar          dex -> jar — `dex2jar app.apk` (or d2j-dex2jar)")
        appendLine("  - uber-apk-signer  sign + zipalign — `uber-apk-signer -a app.apk`")
        appendLine("  - bytecode-viewer / jbytemod   GUI suites (need a display; in the sandbox prefer the CLI tools)")
        appendLine("All tools are JDK 17 compatible. `rev-java` is the bundled Java 17 launcher the wrappers use.")
        appendLine()
        appendLine("IF THE TOOLCHAIN IS MISSING (no /opt/rev-toolchain, or `apktool` / `jadx` not found): DO NOT try to apt-get / pip install or download anything yourself. You MUST tell the user: 「当前缺少逆向工具链，请到 App 的『设置 → 下载环境』里下载并安装『逆向工具链』，安装完成后我再继续。」 Then STOP and wait for the user.")
        appendLine()
        appendLine("SUGGESTED WORKFLOW (once the toolchain is present):")
        appendLine("  1. First inspect the unzipped tree: read AndroidManifest.xml (binary — decode with `apktool d` or `aapt2 dump`), list classes*.dex, note native libs and assets.")
        appendLine("  2. Run `apktool d <apk> -o decoded` to get smali + decoded resources.")
        appendLine("  3. Run `jadx -d src <apk>` for readable Java source.")
        appendLine("  4. Analyze: entry points, permissions, network endpoints, obfuscation, native code, packers.")
        appendLine("  5. For modifications: edit smali, `apktool b` rebuild, then `uber-apk-signer` to sign.")
        appendLine("Work in SHORT terminal commands, one step at a time. The workspace is mounted as /workspace inside the sandbox.")
        appendLine("</reverse_mode>")
    }

    /** 判断 AI 的最终正文结尾是否带了完成标记 [我已完成任务]。 */
    fun hasCompletionMarker(text: String): Boolean = text.contains("[我已完成任务]")
}