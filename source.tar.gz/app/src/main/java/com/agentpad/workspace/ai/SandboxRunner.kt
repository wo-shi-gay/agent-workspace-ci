package com.agentpad.workspace.ai

import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Runs commands inside a PRoot container by delegating to the bundled
 * init-sandbox.sh launcher (the same layout used by the reference APK:
 * libproot.so as loader + libproot-xed.so as the actual proot binary).
 *
 * argv layout handed to init-sandbox.sh:
 *   init-sandbox.sh <PREFIX> <ROOTFS> <NATIVE> <PROJECT> sh -c <command>
 * The trailing `sh -c <command>` makes the in-container shell parse the raw
 * command string, so pipelines, && etc. work.
 */
class SandboxRunner(
    private val sandboxDir: File,
    private val rootfs: File,
    private val nativeDir: File,
    private val initScript: File,
    private val projectDir: File,
    private val monitorSessionId: String = "ai-terminal"
) : TerminalBackend {
    companion object {
        @Volatile private var current: Process? = null

        /** Kill the running container command (used by the chat abort button). */
        fun abortCurrent() {
            runCatching { current?.destroy() }
            runCatching { current?.destroyForcibly() }
        }

        /**
         * 一次性阻塞执行一条沙箱命令（供插件 host.shellExec 调用）。
         * 用一个临时 runner，跑完即返回合并后的输出；沙箱未就绪返回 null。
         */
        fun runOnceBlocking(context: android.content.Context, command: String, workspace: File): String? {
            return runCatching {
                val runner = SandboxRunner(
                    sandboxDir = SandboxInstaller.sandboxDir(context),
                    rootfs = SandboxInstaller.rootfsDir(context),
                    nativeDir = SandboxInstaller.nativeDir(context),
                    initScript = SandboxInstaller.initScript(context),
                    projectDir = workspace,
                    monitorSessionId = "plugin-shell",
                )
                val out = runner.run(TerminalRequest(command = command, cwd = workspace.absolutePath, timeoutMs = 120_000L))
                (out.stdout + out.stderr).trim().ifBlank { "(无输出，exit=${out.exitCode})" }
            }.getOrNull()
        }
    }

    override fun run(request: TerminalRequest): TerminalOutput {
        if (!sandboxDir.isDirectory) return TerminalOutput(-1, "", "sandbox missing: ${sandboxDir.absolutePath}")
        if (!rootfs.isDirectory) return TerminalOutput(-1, "", "rootfs missing: ${rootfs.absolutePath}")
        if (!nativeDir.isDirectory) return TerminalOutput(-1, "", "native dir missing: ${nativeDir.absolutePath}")
        if (!initScript.isFile) return TerminalOutput(-1, "", "init-sandbox.sh missing: ${initScript.absolutePath}")
        val command = request.command.trim()
        if (command.isEmpty()) return TerminalOutput(-1, "", "empty command")
        val effectiveCwd = request.cwd?.takeIf { it.isNotBlank() }?.let(::File) ?: projectDir
        return TerminalService.execute(monitorSessionId, "AI 终端", sandboxDir, rootfs, nativeDir, initScript, effectiveCwd, command, (request.timeoutMs ?: 120_000L).coerceIn(1_000L, 600_000L))

        // Explicit cwd from the tool call: prefix an exact `cd` so relative
        // paths land where the AI asked (overrides the default start dir).
        val effective = request.cwd?.takeIf { it.isNotBlank() }?.let { cwd ->
            val safe = cwd.replace("'", "'\\''")
            "cd '$safe' 2>/dev/null || { echo \"cwd not found: $cwd\" >&2; exit 2; }\n$command"
        } ?: command

        val timeout = (request.timeoutMs ?: 120_000L).coerceIn(1_000L, 600_000L)
        TerminalMonitor.update(TerminalMonitor.Session(monitorSessionId, "AI 终端", projectDir.absolutePath, command = command, running = true))
        val process = try {
            // We do NOT exec() init-sandbox.sh directly: on several devices the
            // copy loses its exec bit and Android returns EACCES. Instead the
            // Android system shell (/system/bin/sh) interprets the script, so
            // the script only needs to be readable — which it always is inside
            // the app's private files dir.
            ProcessBuilder(
                listOf(
                    "/system/bin/sh",
                    initScript.absolutePath,     // script filename
                    sandboxDir.absolutePath,     // PREFIX
                    rootfs.absolutePath,         // ROOTFS_DIR
                    nativeDir.absolutePath,      // NATIVE_LIB_DIR
                    projectDir.absolutePath,     // PROJECT_DIR -> /workspace
                    "sh", "-c", effective          // in-container shell parses the raw command
                )
            ).directory(sandboxDir).redirectErrorStream(false).start()
        } catch (error: Exception) {
            return TerminalOutput(-1, "", "failed to start sandbox: ${error.message}")
        }

        val stdout = StringBuilder()
        val stderr = StringBuilder()
        fun publish(running: Boolean = true, exitCode: Int? = null) {
            TerminalMonitor.update(TerminalMonitor.Session(monitorSessionId, "AI 终端", projectDir.absolutePath, command, stdout.toString() + stderr.toString(), running, exitCode))
        }
        // Reader threads MUST swallow IO errors: when the process is destroyed
        // (timeout or user abort) read() throws InterruptedIOException. An
        // uncaught exception here previously killed the whole app.
        val outThread = Thread {
            try { process.inputStream.bufferedReader().useLines { it.forEach { line -> stdout.appendLine(line); publish() } } }
            catch (_: Exception) { /* process destroyed */ }
        }
        val errThread = Thread {
            try { process.errorStream.bufferedReader().useLines { it.forEach { line -> stderr.appendLine(line); publish() } } }
            catch (_: Exception) { /* process destroyed */ }
        }
        current = process
        outThread.start(); errThread.start()
        try {
            val completed = process.waitFor(timeout, TimeUnit.MILLISECONDS)
            if (!completed) {
                process.destroy()
                if (!process.waitFor(1_000, TimeUnit.MILLISECONDS)) process.destroyForcibly()
                outThread.join(1_000); errThread.join(1_000)
                return TerminalOutput(124, stdout.toString(), (stderr.toString() + "\ncommand timed out after ${timeout}ms").trim())
            }
            outThread.join(1_000); errThread.join(1_000)
            return TerminalOutput(process.exitValue(), stdout.toString(), stderr.toString())
        } catch (e: InterruptedException) {
            process.destroy()
            return TerminalOutput(130, stdout.toString(), "aborted")
        } finally {
            if (current === process) current = null
        }
    }
}