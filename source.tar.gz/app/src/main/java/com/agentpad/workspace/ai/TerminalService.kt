package com.agentpad.workspace.ai

import java.io.File
import com.ai.assistance.operit.terminal.Pty
import com.agentpad.workspace.terminal.AnsiParser
import com.agentpad.workspace.terminal.AnsiScreen
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Terminal sessions.
 *
 * Two very different jobs live here:
 *
 * 1. **Interactive sessions** (`createSession` / `sendInput` / `resize`) — a
 *    persistent PRoot shell rendered by the terminal screen and driven by the
 *    user's virtual keyboard.
 *
 * 2. **One-shot AI command execution** (`execute`) — every `terminal` tool call
 *    gets its OWN PRoot process with a plain (non-interactive) shell. Output is
 *    read straight from the process stdout and the REAL exit code comes from
 *    `waitFor()`. This is deterministic and fast: no marker echo to fight, no
 *    interactive prompt state, no shared-PTY contention. The command, its live
 *    output and its exit status are still mirrored into the interface session so
 *    the user can watch them on the terminal screen.
 *
 * (The previous design ran AI commands by typing a marker into the *shared
 * interactive* PTY and polling for the echo — it was slow and reported bogus
 * exit codes.)
 */
object TerminalService {
    private class Session(
        val id: String,
        val title: String,
        val cwd: File,
        val pty: Pty,
        val screen: AnsiScreen,
        val parser: AnsiParser,
        val lock: Any = Any()
    ) {
        /** 有界的纯文本镜像（给 terminal_screen / 完成检测用）。 */
        val textBuf = StringBuilder(8192)
    }

    /**
     * 文本镜像上限（字符）。超过就裁掉头部。
     * 以前用 `old.output + chunk` 累加，是 O(n²) 且无上限——
     * 几十 MB 的日志会让每次 publish 都整串拷贝，GC 抖动直接卡死 UI。
     */
    private const val TEXT_BUF_LIMIT = 256 * 1024
    private val sessions = ConcurrentHashMap<String, Session>()

    /** One shared interactive shell per chat session. */
    fun aiSessionId(chatSessionId: String): String =
        if (chatSessionId.isBlank()) "ai-terminal" else "ai-terminal-$chatSessionId"

    fun screen(id: String): AnsiScreen? = sessions[id]?.screen

    // ------------------------------------------------------------------ one-shot

    fun execute(id: String, title: String, sandbox: File, rootfs: File, native: File, script: File, cwd: File, command: String, timeoutMs: Long): TerminalOutput {
        if (command.isBlank()) return TerminalOutput(-1, "", "empty command")
        // Interface session so the user can watch the command on the terminal screen.
        val session = sessions[id] ?: synchronized(sessions) {
            sessions[id] ?: start(id, title, sandbox, rootfs, native, script, cwd).also { sessions[id] = it }
        }

        val safeCwd = cwd.absolutePath.replace("'", "'\\''")
        val runCommand = "cd '$safeCwd' 2>/dev/null || { echo \"cwd not found: $safeCwd\" >&2; exit 2; }\n$command"
        feedMirror(session, "\u001b[38;5;244m› $command\u001b[0m\n")

        // KEY: pass the command as EXTRA argv so init-sandbox.sh takes its
        // non-interactive branch (`exec "$@"`). With no extra args it starts the
        // interactive shell (`exec "$0"`), which never exits — that is exactly
        // why every AI command used to time out with exit_code=124.
        val argv = arrayOf(
            "/system/bin/sh", script.absolutePath,
            sandbox.absolutePath, rootfs.absolutePath, native.absolutePath, cwd.absolutePath,
            "sh", "-c", runCommand
        )
        val pty = try {
            Pty.start(argv, buildEnv(), sandbox)
        } catch (e: Exception) {
            return TerminalOutput(-1, "", "failed to start command: ${e.message}")
        }

        val out = StringBuilder()
        val reader = Thread {
            val buf = ByteArray(8192)
            var carry: ByteArray? = null
            try {
                while (true) {
                    val n = try { pty.stdout.read(buf) } catch (_: Exception) { -1 }
                    if (n < 0) break
                    if (n == 0) continue
                    val decoded = AnsiParser.decodePtyBytes(buf, n, carry)
                    carry = decoded.second
                    val chunk = decoded.first
                    if (chunk.isEmpty()) continue
                    synchronized(out) { out.append(chunk) }
                    feedMirror(session, chunk)
                }
            } catch (_: Exception) { }
        }.apply { name = "ai-exec-$id"; isDaemon = true; start() }

        // `waitFor()` (no timeout) blocks on the native pid and records the real
        // exit code; run it on a helper thread so we can enforce our own timeout.
        val exited = java.util.concurrent.CountDownLatch(1)
        Thread {
            runCatching { pty.process.waitFor() }
            exited.countDown()
        }.apply { name = "ai-exec-wait-$id"; isDaemon = true; start() }

        val done = try { exited.await(timeoutMs, TimeUnit.MILLISECONDS) } catch (_: InterruptedException) { false }
        if (!done) {
            runCatching { pty.destroy() }
            reader.join(400)
            val text = synchronized(out) { out.toString() }
            feedMirror(session, "\u001b[38;5;203m(command timed out)\u001b[0m\n")
            return TerminalOutput(124, text, "command timed out after ${timeoutMs}ms")
        }

        reader.join(800)
        val text = synchronized(out) { out.toString() }
        val exit = runCatching { pty.process.exitValue() }.getOrDefault(-1)
        runCatching { pty.destroy() }
        feedMirror(session, if (exit == 0) "\u001b[38;5;114m(exit 0)\u001b[0m\n" else "\u001b[38;5;203m(exit $exit)\u001b[0m\n")
        return TerminalOutput(exit, text, "")
    }

    // ------------------------------------------------------------- interactive

    private fun start(id: String, title: String, sandbox: File, rootfs: File, native: File, script: File, cwd: File): Session {
        installColorRc(sandbox)
        val pty = Pty.start(arrayOf("/system/bin/sh", script.absolutePath, sandbox.absolutePath, rootfs.absolutePath, native.absolutePath, cwd.absolutePath), buildEnv(), sandbox)

        val screen = AnsiScreen(30, 96)
        val parser = AnsiParser(screen)
        parser.onReply = { reply -> runCatching { pty.stdin.write(reply.toByteArray(Charsets.UTF_8)); pty.stdin.flush() } }

        Thread {
            val buffer = ByteArray(16384)
            var carry: ByteArray? = null
            val text = StringBuilder()
            var lastPublish = 0L
            fun publish(running: Boolean, exitCode: Int? = null, force: Boolean = true) {
                val now = System.currentTimeMillis()
                if (!force && now - lastPublish < 150) return
                lastPublish = now
                val old = TerminalMonitor.snapshot().firstOrNull { it.id == id }
                TerminalMonitor.update(TerminalMonitor.Session(
                    id, title, cwd.absolutePath, old?.command.orEmpty(),
                    text.toString(), running, exitCode, screen
                ))
            }
            try {
                while (true) {
                    val n = try { pty.stdout.read(buffer) } catch (_: Exception) { -1 }
                    if (n < 0) break
                    if (n == 0) continue
                    val decoded = AnsiParser.decodePtyBytes(buffer, n, carry)
                    carry = decoded.second
                    val chunk = decoded.first
                    if (chunk.isEmpty()) continue
                    text.append(chunk)
                    // 有界：长日志不再无限增长（配合 publish 节流，避免 GC 卡顿）
                    if (text.length > TEXT_BUF_LIMIT) text.delete(0, text.length - TEXT_BUF_LIMIT)
                    parser.feed(chunk)
                    publish(running = true, force = false)
                }
            } catch (_: Exception) { }
            publish(running = false, exitCode = runCatching { pty.process.waitFor() }.getOrNull())
        }.apply { name = "agent-terminal-$id"; isDaemon = true; start() }

        val session = Session(id, title, cwd, pty, screen, parser)
        TerminalMonitor.update(TerminalMonitor.Session(id, title, cwd.absolutePath, running = true, screen = screen))
        return session
    }

    fun createSession(id: String, title: String, sandbox: File, rootfs: File, native: File, script: File, cwd: File): Boolean {
        synchronized(sessions) {
            if (sessions.containsKey(id)) return false
            sessions[id] = start(id, title, sandbox, rootfs, native, script, cwd)
        }
        return true
    }

    fun resize(id: String, rows: Int, cols: Int): Boolean {
        val s = sessions[id] ?: return false
        s.screen.resize(rows, cols)
        return runCatching { s.pty.setWindowSize(rows, cols) }.getOrDefault(false)
    }

    fun sendInput(id: String, input: String): Boolean {
        val s = sessions[id] ?: return false
        return synchronized(s.lock) {
            runCatching {
                s.pty.stdin.write(input.toByteArray(Charsets.UTF_8))
                s.pty.stdin.flush()
                true
            }.getOrElse {
                sessions.remove(id, s)
                TerminalMonitor.snapshot().firstOrNull { it.id == id }?.let { TerminalMonitor.update(it.copy(running = false)) }
                false
            }
        }
    }

    /** Send ETX through the PTY without closing the session. */
    fun interrupt(id: String): Boolean = sendInput(id, "\u0003")

    fun closeSession(id: String) {
        sessions.remove(id)?.let { runCatching { it.pty.destroy() } }
        TerminalMonitor.snapshot().firstOrNull { it.id == id }?.let { TerminalMonitor.update(it.copy(running = false)) }
    }

    fun isRunning(id: String): Boolean = sessions[id]?.pty?.process?.isAlive == true

    /** Mirror a chunk into the session's emulator + text buffer (screen only). */
    private fun feedMirror(session: Session, chunk: String) {
        runCatching { session.parser.feed(chunk) }
        synchronized(session.textBuf) {
            session.textBuf.append(chunk)
            // 文本缓冲上限：超过就裁掉头部。以前是无界 StringBuilder，
            // 长日志（编译 / npm install）能涨到几十 MB，每次 publish 都
            // 整串 toString() → GC 抖动 → 卡顿。
            if (session.textBuf.length > TEXT_BUF_LIMIT) {
                session.textBuf.delete(0, session.textBuf.length - TEXT_BUF_LIMIT)
            }
        }
        val old = TerminalMonitor.snapshot().firstOrNull { it.id == session.id } ?: return
        TerminalMonitor.update(TerminalMonitor.Session(
            session.id, old.title, old.cwd, old.command,
            synchronized(session.textBuf) { session.textBuf.toString() },
            old.running, old.exitCode, session.screen
        ))
    }

    private fun buildEnv(): Map<String, String> = mapOf(
        "PATH" to "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
        "HOME" to "/root",
        "TERM" to "xterm-256color",
        "COLORTERM" to "truecolor",
        "CLICOLOR" to "1",
        "CLICOLOR_FORCE" to "1",
        "TERM_PROGRAM" to "AgentPad",
        "LANG" to "C.UTF-8",
        "LC_ALL" to "C.UTF-8",
        "LC_CTYPE" to "C.UTF-8",
        "PYTHONIOENCODING" to "utf-8",
        "PYTHONUTF8" to "1"
    )

    // ------------------------------------------------------------------- rc

    private fun installColorRc(sandbox: File) {
        runCatching {
            val publicDir = File(sandbox, "public")
            publicDir.mkdirs()
            File(publicDir, ".agentpad_rc").writeText(shRc)
            File(sandbox, ".agentpad_rc").writeText(shRc)
            File(publicDir, ".bashrc").writeText(bashRc)
            File(sandbox, ".bashrc").writeText(bashRc)
        }
    }

    private val shRc: String = """
        export TERM=xterm-256color
        export COLORTERM=truecolor
        export CLICOLOR=1
        export CLICOLOR_FORCE=1
        export LANG=C.UTF-8
        export LC_ALL=C.UTF-8
        export LC_CTYPE=C.UTF-8
        export PYTHONIOENCODING=utf-8
        export PYTHONUTF8=1
        export LS_COLORS='di=01;34:ln=01;36:so=01;35:pi=33:ex=01;32:bd=01;33:cd=01;33:or=01;31:mi=01;31:*.tar=01;31:*.tgz=01;31:*.zip=01;31:*.gz=01;31:*.jpg=01;35:*.png=01;35:*.mp4=01;35:*.mp3=01;35:*.c=01;36:*.h=01;36:*.py=01;33:*.js=01;33:*.json=01;33:*.kt=01;33:*.java=01;33'
        alias ls='ls --color=auto'
        alias ll='ls -alF --color=auto'
        alias la='ls -A --color=auto'
        alias grep='grep --color=auto'
        alias fgrep='fgrep --color=auto'
        alias egrep='egrep --color=auto'
        alias diff='diff --color=auto'
        _AP_ESC=${'$'}(printf '\033')
        PS1="${'$'}{_AP_ESC}[1;32mroot@agentpad${'$'}{_AP_ESC}[0m# "
        export PS1
        unset _AP_ESC
    """.trimIndent() + "\n"

    private val bashRc: String = """
        export TERM=xterm-256color
        export COLORTERM=truecolor
        export CLICOLOR=1
        export CLICOLOR_FORCE=1
        export LANG=C.UTF-8
        export LC_ALL=C.UTF-8
        export LC_CTYPE=C.UTF-8
        export PYTHONIOENCODING=utf-8
        export PYTHONUTF8=1
        export LS_COLORS='di=01;34:ln=01;36:so=01;35:pi=33:ex=01;32:bd=01;33:cd=01;33:or=01;31:mi=01;31:*.tar=01;31:*.tgz=01;31:*.zip=01;31:*.gz=01;31:*.jpg=01;35:*.png=01;35:*.mp4=01;35:*.mp3=01;35:*.c=01;36:*.h=01;36:*.py=01;33:*.js=01;33:*.json=01;33:*.kt=01;33:*.java=01;33'
        alias ls='ls --color=auto'
        alias ll='ls -alF --color=auto'
        alias la='ls -A --color=auto'
        alias grep='grep --color=auto'
        alias fgrep='fgrep --color=auto'
        alias egrep='egrep --color=auto'
        alias diff='diff --color=auto'
        bind 'set convert-meta off' 2>/dev/null
        bind 'set input-meta on' 2>/dev/null
        bind 'set output-meta on' 2>/dev/null
        bind 'set enable-bracketed-paste off' 2>/dev/null
        PS1='\[\033[1;32m\]root@agentpad\[\033[0m\]:\[\033[1;34m\]\w\[\033[0m\]# '
    """.trimIndent() + "\n"
}