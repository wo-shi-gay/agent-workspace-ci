package com.agentpad.workspace.terminal

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Terminal canvas with one gesture owner:
 * - one pointer: scroll / long-press selection
 * - two pointers: pinch font scale only
 *
 * PTY grid size changes only after the font metrics settle. The screen model
 * performs soft-wrap reflow; the view never converts a pinch into scrolling.
 */
class TerminalView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    var screen: AnsiScreen? = null
        private set
    var onGridChanged: ((rows: Int, cols: Int) -> Unit)? = null
    var onCopyRequested: ((String) -> Unit)? = null
    var onSelectionChanged: ((Boolean) -> Unit)? = null
    var onTap: (() -> Unit)? = null

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.MONOSPACE
        isSubpixelText = false
    }
    private val fillPaint = Paint()
    private val scrollPaint = Paint()
    /**
     * Terminal font size. Pinch changes it in fixed 2px steps (not continuously)
     * so the screen reflows at most once per step instead of on every frame.
     * 18px default is comfortably readable on a phone.
     */
    private var fontSize = 18f
    private var cellW = 11f
    private var cellH = 22f
    private var baseline = 14f
    private var rowsVisible = 1
    private var colsVisible = 1
    private var bottomInset = 0
    private var lastGridRows = 0
    private var lastGridCols = 0

    private enum class GestureMode { NONE, SCROLL, SELECT }
    private var gestureMode = GestureMode.NONE
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var downAt = 0L
    private var moved = false
    private var velocityY = 0f
    private var lastMoveAt = 0L
    private var scrollAccum = 0f
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop

    private var selecting = false
    private var selectStartLine = 0
    private var selectStartCol = 0
    private var selectEndLine = 0
    private var selectEndCol = 0

    private var cursorOn = true
    private val blink = object : Runnable {
        override fun run() {
            cursorOn = !cursorOn
            invalidate()
            if (isAttachedToWindow) postDelayed(this, 520L)
        }
    }

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        fillPaint.color = TermPalette.DEFAULT_BG
        scrollPaint.color = 0x66FFFFFF
        updateMetrics()
    }

    fun bind(value: AnsiScreen) {
        screen = value
        lastGridRows = 0
        lastGridCols = 0
        updateGrid(force = true)
        invalidate()
    }

    fun getFontSize(): Float = fontSize

    fun setFontSize(value: Float) {
        // Snap to 2px steps so a pinch reflows only a handful of times instead
        // of continuously (which made the view jump around).
        val snapped = ((value / 2f).toInt() * 2f).coerceIn(12f, 32f)
        if (abs(snapped - fontSize) < 0.1f) return
        fontSize = snapped
        updateMetrics()
        // Reflow once for the new size, then tell the PTY.
        updateGrid(force = true)
        invalidate()
    }

    fun setBottomInset(px: Int) {
        val next = px.coerceAtLeast(0)
        if (next == bottomInset) return
        bottomInset = next
        updateGrid(force = false)
        invalidate()
    }

    private fun updateMetrics() {
        textPaint.textSize = fontSize
        val fm = textPaint.fontMetrics
        baseline = -fm.ascent
        cellW = textPaint.measureText("M").coerceAtLeast(1f)
        cellH = (fm.descent - fm.ascent).coerceAtLeast(fontSize * 1.08f)
    }

    private fun desiredGrid(): Pair<Int, Int> {
        val w = width.coerceAtLeast(1)
        val h = (height - bottomInset).coerceAtLeast(1)
        return (h / cellH).toInt().coerceAtLeast(2) to
            (w / cellW).toInt().coerceAtLeast(8)
    }

    private fun updateGrid(force: Boolean) {
        if (width <= 0 || height <= 0) return
        val (rows, cols) = desiredGrid()
        rowsVisible = rows
        colsVisible = cols
        if (!force && rows == lastGridRows && cols == lastGridCols) return
        if (rows == lastGridRows && cols == lastGridCols) return
        lastGridRows = rows
        lastGridCols = cols
        screen?.resize(rows, cols)
        onGridChanged?.invoke(rows, cols)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        updateGrid(force = true)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        postDelayed(blink, 520L)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(blink)
        super.onDetachedFromWindow()
    }

    // -------------------------------------------------------------- rendering

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(TermPalette.DEFAULT_BG)
        val s = screen ?: return
        // 关键：绘制前清 dirty。以前 dirty 永远是 true，导致 90ms 轮询
        // 每次都重绘整个屏幕（数百次 drawText），日志越多越卡。
        s.consumeDirty()
        val first = (s.totalLines - rowsVisible - s.scrollOffset).coerceAtLeast(0)
        val selection = normalizedSelection()

        for (viewRow in 0 until rowsVisible) {
            val lineIndex = first + viewRow
            if (lineIndex >= s.totalLines) break
            val line = s.lineAt(lineIndex)
            var col = 0
            while (col < colsVisible) {
                val attr = line.attr[col].toInt()
                if (attr and ATTR_WIDE_CONT != 0) { col++; continue }
                var fg = line.fg[col]
                var bg = line.bg[col]
                if (attr and ATTR_REVERSE != 0) { val t = fg; fg = bg; bg = t }
                if (attr and ATTR_DIM != 0) fg = dim(fg)
                if (isSelected(selection, lineIndex, col)) bg = TermPalette.SELECTION
                if (bg != TermPalette.DEFAULT_BG) {
                    fillPaint.color = bg
                    canvas.drawRect(col * cellW, viewRow * cellH, (col + 1) * cellW + 1f, (viewRow + 1) * cellH, fillPaint)
                }
                val ch = line.chars[col]
                if (ch != ' ' && ch != '\u0000') {
                    textPaint.color = fg
                    textPaint.isFakeBoldText = attr and ATTR_BOLD != 0
                    textPaint.textSkewX = if (attr and ATTR_ITALIC != 0) -0.2f else 0f
                    textPaint.isUnderlineText = attr and ATTR_UNDERLINE != 0
                    textPaint.isStrikeThruText = attr and ATTR_STRIKE != 0
                    canvas.drawText(ch.toString(), col * cellW, viewRow * cellH + baseline, textPaint)
                    textPaint.isFakeBoldText = false
                    textPaint.textSkewX = 0f
                    textPaint.isUnderlineText = false
                    textPaint.isStrikeThruText = false
                }
                col += if (AnsiScreen.isWide(ch)) 2 else 1
            }
        }
        drawCursor(canvas, s, first)
        drawScrollbar(canvas, s)
    }

    private fun drawCursor(canvas: Canvas, s: AnsiScreen, first: Int) {
        if (!s.cursorVisible || s.scrollOffset != 0 || !cursorOn) return
        if (s.cursorRow !in 0 until rowsVisible || s.cursorCol !in 0 until colsVisible) return
        val left = s.cursorCol * cellW
        val top = s.cursorRow * cellH
        val ch = runCatching { s.lineAt(first + s.cursorRow).chars[s.cursorCol] }.getOrDefault(' ')
        fillPaint.color = TermPalette.CURSOR
        canvas.drawRect(left, top + 1f, left + cellW, top + cellH - 1f, fillPaint)
        if (ch != ' ' && ch != '\u0000') {
            textPaint.color = TermPalette.DEFAULT_BG
            canvas.drawText(ch.toString(), left, top + baseline, textPaint)
        }
    }

    private fun drawScrollbar(canvas: Canvas, s: AnsiScreen) {
        if (s.historySize == 0) return
        val total = s.totalLines.toFloat()
        val barH = max(24f, height * rowsVisible / total)
        val progress = if (s.historySize == 0) 0f else s.scrollOffset / s.historySize.toFloat()
        // At the live bottom (progress 0) the thumb must sit at the bottom.
        val top = (height - barH) * (1f - progress)
        canvas.drawRoundRect(RectF(width - 6f, top, width - 2f, top + barH), 2f, 2f, scrollPaint)
    }

    private fun dim(c: Int): Int = Color.argb(Color.alpha(c), (Color.red(c) * .6f).toInt(), (Color.green(c) * .6f).toInt(), (Color.blue(c) * .6f).toInt())

    // --------------------------------------------------------------- gestures

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val s = screen ?: return true
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gestureMode = GestureMode.NONE
                moved = false
                downX = event.x; downY = event.y
                lastX = event.x; lastY = event.y
                downAt = SystemClock.uptimeMillis()
                lastMoveAt = downAt
                velocityY = 0f
                scrollAccum = 0f
                parent?.requestDisallowInterceptTouchEvent(true)
                postDelayed({
                    if (!moved && gestureMode == GestureMode.NONE && event.pointerCount == 1) beginSelection(event.x, event.y)
                }, ViewConfiguration.getLongPressTimeout().toLong())
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                // Zoom is intentionally not supported: the font size is fixed.
                moved = true
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                // Ignore multi-touch entirely — no pinch scroll, no pinch zoom.
                if (event.pointerCount >= 2) return true
                val dy = event.y - lastY
                if (abs(event.x - downX) > touchSlop || abs(event.y - downY) > touchSlop) {
                    moved = true
                    if (gestureMode == GestureMode.NONE) gestureMode = if (selecting) GestureMode.SELECT else GestureMode.SCROLL
                }
                val now = SystemClock.uptimeMillis()
                if (now > lastMoveAt) velocityY = dy / (now - lastMoveAt) * 1000f
                lastMoveAt = now
                if (gestureMode == GestureMode.SELECT) {
                    updateSelection(event.x, event.y)
                } else if (gestureMode == GestureMode.SCROLL) {
                    // Natural direction: dragging the content down (dy>0) reveals
                    // older lines above; dragging up returns toward the live prompt.
                    scrollAccum += dy
                    val lines = (scrollAccum / cellH).toInt()
                    if (lines != 0) { scrollAccum -= lines * cellH; s.scrollBy(lines); invalidate() }
                }
                lastX = event.x; lastY = event.y
                return true
            }
            MotionEvent.ACTION_POINTER_UP -> return true
            MotionEvent.ACTION_UP -> {
                if (gestureMode == GestureMode.SCROLL && abs(velocityY) > 350f) {
                    val flingLines = (velocityY / cellH / 8f).toInt()
                    if (flingLines != 0) s.scrollBy(flingLines)
                }
                if (!moved && !selecting) onTap?.invoke()
                if (selecting) { onSelectionChanged?.invoke(true) }
                gestureMode = GestureMode.NONE
                scrollAccum = 0f
                parent?.requestDisallowInterceptTouchEvent(false)
                invalidate()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                gestureMode = GestureMode.NONE
                scrollAccum = 0f
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return true
    }

    private fun distance(e: MotionEvent): Float {
        if (e.pointerCount < 2) return 0f
        return hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1))
    }

    // ------------------------------------------------------------- selection

    private fun beginSelection(x: Float, y: Float) {
        val cell = cellAt(x, y) ?: return
        selecting = true
        selectStartLine = cell.first; selectStartCol = cell.second
        selectEndLine = cell.first; selectEndCol = cell.second
        performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        onSelectionChanged?.invoke(true)
        invalidate()
    }

    private fun updateSelection(x: Float, y: Float) {
        val cell = cellAt(x, y) ?: return
        selectEndLine = cell.first; selectEndCol = cell.second
        invalidate()
    }

    private fun clearSelectionIfNeeded() {
        if (selecting) {
            selecting = false
            onSelectionChanged?.invoke(false)
            invalidate()
        }
    }

    private fun normalizedSelection(): IntArray? {
        if (!selecting) return null
        return if (selectStartLine < selectEndLine || (selectStartLine == selectEndLine && selectStartCol <= selectEndCol))
            intArrayOf(selectStartLine, selectStartCol, selectEndLine, selectEndCol)
        else intArrayOf(selectEndLine, selectEndCol, selectStartLine, selectStartCol)
    }

    private fun isSelected(selection: IntArray?, line: Int, col: Int): Boolean {
        if (selection == null) return false
        val a = selection[0]; val ac = selection[1]; val b = selection[2]; val bc = selection[3]
        return line in a..b && (line > a || col >= ac) && (line < b || col <= bc)
    }

    private fun cellAt(x: Float, y: Float): Pair<Int, Int>? {
        val s = screen ?: return null
        val col = (x / cellW).toInt().coerceIn(0, colsVisible - 1)
        val row = (y / cellH).toInt().coerceIn(0, rowsVisible - 1)
        val first = (s.totalLines - rowsVisible - s.scrollOffset).coerceAtLeast(0)
        return first + row to col
    }

    fun hasSelection(): Boolean = selecting
    fun clearSelection() { clearSelectionIfNeeded() }

    fun selectedText(): String {
        val s = screen ?: return ""
        val selection = normalizedSelection() ?: return ""
        return s.textBetween(selection[0], selection[1], selection[2], selection[3])
    }

    fun selectAll() {
        val s = screen ?: return
        selecting = true
        selectStartLine = 0; selectStartCol = 0
        selectEndLine = s.totalLines - 1; selectEndCol = colsVisible - 1
        onSelectionChanged?.invoke(true)
        invalidate()
    }

    fun copySelection(): Boolean {
        val text = selectedText()
        if (text.isBlank()) return false
        onCopyRequested?.invoke(text)
        return true
    }

    fun scrollToBottom() { screen?.scrollToBottom(); invalidate() }
    fun pageUp() { screen?.scrollBy(rowsVisible - 1); invalidate() }
    fun pageDown() { screen?.scrollBy(-(rowsVisible - 1)); invalidate() }
    fun lineUp() { screen?.scrollBy(1); invalidate() }
    fun lineDown() { screen?.scrollBy(-1); invalidate() }
    fun scrollTop() { screen?.let { it.scrollBy(it.historySize) }; invalidate() }
    fun invalidateIfDirty() { if (screen?.dirty == true) invalidate() }
}