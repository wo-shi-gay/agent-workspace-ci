package com.agentpad.workspace

import android.app.Application
import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AgentApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // 日志中心最先启动（后台持续收集，与界面无关）
        runCatching { com.agentpad.workspace.data.AppLog.start(this) }
        // 恢复用户上次选择的主题（主色调 + 深色模式）
        runCatching { com.agentpad.workspace.ui.ThemeStore.load(this) }
        installCrashReporter()

        // 若用户此前启用了 MCP 服务，进程启动时自动拉起监听
        runCatching { com.agentpad.workspace.ai.McpServerManager.startIfEnabled(this) }
            .onFailure { writeStartupError(it) }
        // 通知常驻保活（默认开启，用户可在设置里关）：前台服务 + 常驻通知，
        // 不需要任何特殊权限，是「不申请无障碍」时最稳的保活手段。
        // ⚠ 2026-11-07 修复：这里原来是裸 runCatching，失败静默丢弃。
        //   前台服务在 Android 12+ 可能因后台启动限制直接抛
        //   ForegroundServiceStartNotAllowedException，用户表现为
        //   「保活开关是开的但通知栏什么都没有」，排查时毫无线索。
        //   改为记录到启动错误日志（writeStartupError 原本是死代码）。
        runCatching { KeepAliveNotificationService.startIfEnabled(this) }
            .onFailure { writeStartupError(it) }
        // Sandbox setup (download + extract + integrity check) is handled by the
        // BootActivity launcher gate with a progress bar. Nothing blocking here.
    }

    /**
     * 系统白天/黑夜切换时回调（Android 10+ 才有意义）。
     * 仅在用户开启「跟随系统」时刷新色板，Android 8/9 上此回调不产生深色变化。
     */
    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        runCatching { com.agentpad.workspace.ui.ThemeStore.applySystemDark(this) }
    }

    private fun installCrashReporter() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            // InterruptedIOException from aborted process readers is benign —
            // never treat it (or any IO error on background threads) as fatal.
            if (thread.name != "main" && throwable is java.io.IOException) {
                android.util.Log.w("AgentWorkspace", "background io error ignored on ${thread.name}", throwable)
                return@setDefaultUncaughtExceptionHandler
            }
            writeCrash(thread, throwable)
            previous?.uncaughtException(thread, throwable) ?: Runtime.getRuntime().exit(10)
        }
    }

    private fun writeStartupError(error: Throwable) {
        writeText("startup_latest.txt", "startup initialization failed\n\n${error.stackTraceToString()}")
    }

    private fun writeCrash(thread: Thread, throwable: Throwable) {
        // 写入统一日志中心（后台可见、可导出）
        runCatching { com.agentpad.workspace.data.AppLog.crash(thread, throwable) }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        writeText("crash_$stamp.txt", report(thread, throwable))
        writeText("latest.txt", report(thread, throwable))
    }

    private fun report(thread: Thread, throwable: Throwable) = buildString {
        appendLine("Workspace crash report")
        appendLine("time=${System.currentTimeMillis()}")
        appendLine("thread=${thread.name}")
        appendLine("package=$packageName")
        appendLine("version=${appVersion()}")
        appendLine("android=${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        appendLine("device=${Build.MANUFACTURER} ${Build.MODEL}")
        appendLine()
        appendLine(throwable.stackTraceToString())
    }

    /** 从安装包读版本，避免这里写死导致与 build.gradle.kts 脱节。 */
    private fun appVersion(): String = runCatching {
        val info = packageManager.getPackageInfo(packageName, 0)
        "${info.versionName} (${info.longVersionCode})"
    }.getOrElse { "unknown" }

    private fun writeText(name: String, content: String) {
        // 主目录：外部私有目录 /sdcard/Android/data/<pkg>/ —— 任何文件管理器可见，
        //   且 API 19+ 无需任何存储权限，是最省事的位置。
        //   旧实现用 Environment.getExternalStorageDirectory() 手工拼 "Android/data/<pkg>"：
        //   该 API 在 API 29 起已废弃，且在部分 ROM 上会因 scoped storage
        //   返回的根目录与实际挂载点不一致而写入失败（runCatching 静默吞掉，
        //   表现为「崩溃日志偶尔丢失」）。改用 getExternalFilesDir 的父目录，
        //   由系统给出真实路径，必定可写。
        val internal = File(filesDir, "crash")
        val primary = getExternalFilesDir(null)?.parentFile
        val targets = if (primary != null) listOf(primary, internal) else listOf(internal)
        targets.forEach { directory ->
            runCatching {
                directory.mkdirs()
                File(directory, name).writeText(content, Charsets.UTF_8)
            }
        }
    }
}