package com.agentpad.workspace

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.CloudDownload
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agentpad.workspace.ai.FeijipanParser
import com.agentpad.workspace.ui.*
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.zip.GZIPInputStream

/**
 * 下载环境（Compose 重构版）：每张卡片 = 一个可下载部署到沙箱的资源。
 * 下载/解压逻辑与原实现完全一致，仅 UI 改为统一设计系统。
 */
class DownloadEnvironmentActivity : ComponentActivity() {

    private val executor = Executors.newSingleThreadExecutor()

    /** 每张卡片的运行时状态 */
    private class ItemState {
        var progress by mutableStateOf(-1)      // -1 未开始，0..100 进行中，100 完成
        var running by mutableStateOf(false)
        var status by mutableStateOf("")
        var installed by mutableStateOf(false)
        var failed by mutableStateOf(false)
    }

    private fun rootfsDir(): File = File(filesDir, "sandbox/rootfs")

    private inner class Resource(
        val id: String,
        val title: String,
        val desc: String,
        val shareUrl: String = "",
        /** 直链模式：shareUrl 就是可下载的 http(s) 地址，跳过网盘解析 */
        val direct: Boolean = false,
        /** 直链模式下的落盘文件名 */
        val archiveName: String = "",
        /**
         * 特殊补装标记：不走「解析链接 → 下载归档 → install(archive)」通用流程，
         * 直接调用 [com.agentpad.workspace.ai.SandboxInstaller] 里现成的补装入口。
         * 用于「系统镜像」「Python 运行时」——它们的下载/解压逻辑本来就在
         * SandboxInstaller 里（含多源回退、分块解压），不该在这里重写一份。
         */
        val special: String? = null,
        val isInstalled: () -> Boolean,
        val install: ((File) -> Unit)? = null,
    )

    private lateinit var resourceList: List<Resource>
    private lateinit var stateMap: MutableMap<String, ItemState>
    private val tick = mutableStateOf(0)

    private fun resources(): List<Resource> {
        // 卡片目录（title/desc/是否已安装）统一来自 EnvCatalog —— 与 AI 的
        // list_env_cards 工具同源，保证 AI 看到的清单和这里永远一致。
        val act = this
        val env = com.agentpad.workspace.ai.EnvCatalog.cards(this).associateBy { it.id }
        fun t(id: String) = env[id]?.title ?: id
        fun d(id: String) = env[id]?.desc ?: ""
        fun inst(id: String): () -> Boolean = {
            runCatching { env[id]?.installed?.invoke(act) == true }.getOrDefault(false)
        }
        return listOf(
        // ---- 基础设施补装（首次启动本来就会自动装，这里只给"当时跳过了"的人补）----
        Resource(
            id = "rootfs",
            title = t("rootfs"),
            desc = d("rootfs"),
            special = "rootfs",
            isInstalled = inst("rootfs")
        ),
        Resource(
            id = "python3",
            title = t("python3"),
            desc = d("python3"),
            special = "python3",
            isInstalled = inst("python3")
        ),
        Resource(
            id = "jre17",
            title = t("jre17"),
            desc = d("jre17"),
            shareUrl = "https://share.feijipan.com/s/X5924p0K",
            isInstalled = inst("jre17")
        ) { archive ->
            val rootfs = rootfsDir()
            if (!File(rootfs, "bin/sh").isFile) error("沙箱尚未初始化：请先在对话中让 AI 执行一次终端命令，再回来部署")
            val old = File(rootfs, "usr/local/jre17")
            if (old.exists()) deleteRecursive(old)
            extractTarGz(archive, File(rootfs, "usr/local"))
            val extracted = File(rootfs, "usr/local").listFiles { f -> f.isDirectory && f.name.startsWith("jdk-17") }
            if (extracted.isNullOrEmpty()) error("解压布局异常：未找到 jdk-17* 目录")
            if (extracted.size > 1) error("解压布局异常：发现多个 jdk-17* 目录")
            val src = extracted[0]
            val dst = File(rootfs, "usr/local/jre17")
            if (src.absolutePath != dst.absolutePath) { if (!src.renameTo(dst)) error("重命名 jdk-17* → jre17 失败") }
            val bin = File(dst, "bin")
            if (!File(bin, "java").isFile) error("解压布局异常：未找到 bin/java")
            val pathBin = File(rootfs, "usr/local/bin"); pathBin.mkdirs()
            listOf("java", "keytool").forEach { tool ->
                val link = File(pathBin, tool); link.delete()
                android.system.Os.symlink(File(bin, tool).absolutePath, link.absolutePath)
            }
        },
        Resource(
            id = "toolchain",
            title = t("toolchain"),
            desc = d("toolchain"),
            shareUrl = "https://share.feijipan.com/s/Nc9W0a6g",
            isInstalled = inst("toolchain")
        ) { archive ->
            val rootfs = rootfsDir()
            if (!File(rootfs, "bin/sh").isFile) error("沙箱尚未初始化：请先在对话中让 AI 执行一次终端命令，再回来部署")
            val old = File(rootfs, "opt/toolchain-pack")
            if (old.exists()) deleteRecursive(old)
            extractTarGz(archive, File(rootfs, "opt"))
            val aapt2 = File(rootfs, "opt/toolchain-pack/jniLibs/libaapt2.so")
            if (aapt2.isFile) aapt2.setExecutable(true, false)
            val bin = File(rootfs, "usr/local/bin"); bin.mkdirs()
            val link = File(bin, "aapt2"); link.delete()
            android.system.Os.symlink(aapt2.absolutePath, link.absolutePath)
        },
        Resource(
            id = "toolchain_patch_v3",
            title = t("toolchain_patch_v3"),
            desc = d("toolchain_patch_v3"),
            shareUrl = "https://share.feijipan.com/s/V39sOmm4",
            isInstalled = inst("toolchain_patch_v3")
        ) { archive ->
            val rootfs = rootfsDir()
            if (!File(rootfs, "opt/toolchain-pack/compiler").isDirectory) error("请先安装「编译工具链」，再部署此补丁")
            extractTarGz(archive, File(rootfs, "opt"))
            val aapt2 = File(rootfs, "opt/toolchain-pack/jniLibs/libaapt2.so")
            if (aapt2.isFile) aapt2.setExecutable(true, false)
            val bin = File(rootfs, "usr/local/bin"); bin.mkdirs()
            val link = File(bin, "aapt2"); link.delete()
            android.system.Os.symlink(aapt2.absolutePath, link.absolutePath)
        },
        Resource(
            id = "go_env",
            title = t("go_env"),
            desc = d("go_env"),
            shareUrl = "https://share.feijipan.com/s/M3vTmHcw",
            isInstalled = inst("go_env")
        ) { archive ->
            val rootfs = rootfsDir()
            if (!File(rootfs, "bin/sh").isFile) error("沙箱尚未初始化：请先在对话中让 AI 执行一次终端命令，再回来部署")
            val tmp = File(rootfs, "tmp"); if (!tmp.isDirectory) tmp.mkdirs()
            val target = File(tmp, "go-env.tar.gz")
            if (target.exists()) target.delete()
            archive.copyTo(target, overwrite = true)
        },
        // ⚠ 2026-11-05 Node.js 卡片已移除（与 EnvCatalog 同步）。
        //   原因：这里只是把 tar.gz 丢进 /tmp，不解压不部署，
        //   用户以为装了其实 `node` 不存在，导致 Codex 启动莫名失败。
        //   Node 运行时改由「部署服务 → Codex」自己探测/解压管理。
        Resource(
            id = "kotlin_compose",
            title = t("kotlin_compose"),
            desc = d("kotlin_compose"),
            shareUrl = "https://xn--agent666-df8sk40v.ddns.ge/downloads/kotlin-compose-builder.tar.gz",
            direct = true,
            archiveName = "kotlin-compose-builder.tar.gz",
            isInstalled = inst("kotlin_compose")
        ) { archive ->
            val rootfs = rootfsDir()
            if (!File(rootfs, "bin/sh").isFile) error("沙箱尚未初始化：请先在对话中让 AI 执行一次终端命令，再回来部署")
            // 直接解压到 /opt（包内顶层就是 kotlin-toolchain/），解压后得到 /opt/kotlin-toolchain
            val opt = File(rootfs, "opt"); if (!opt.isDirectory) opt.mkdirs()
            val old = File(opt, "kotlin-toolchain")
            if (old.exists()) deleteRecursive(old)
            extractTarGz(archive, opt)
            val bin = File(opt, "kotlin-toolchain/bin/kotlinc")
            if (!bin.isFile) error("解压布局异常：未找到 kotlin-toolchain/bin/kotlinc")
            bin.setExecutable(true, false)
            // 软链到 PATH，方便直接敲 kotlinc
            val pathBin = File(rootfs, "usr/local/bin"); pathBin.mkdirs()
            val link = File(pathBin, "kotlinc"); link.delete()
            runCatching { android.system.Os.symlink(bin.absolutePath, link.absolutePath) }
        },
        Resource(
            id = "video_buildchain",
            title = t("video_buildchain"),
            desc = d("video_buildchain"),
            shareUrl = "https://xn--agent666-df8sk40v.ddns.ge/downloads/video-buildchain-v1.0.0.tar.gz",
            direct = true,
            archiveName = "video-buildchain-v1.0.0.tar.gz",
            isInstalled = inst("video_buildchain")
        ) { archive ->
            val rootfs = rootfsDir()
            if (!File(rootfs, "bin/sh").isFile) error("沙箱尚未初始化：请先在对话中让 AI 执行一次终端命令，再回来部署")
            // 直接解压到 /opt（包内顶层就是 video-buildchain/），解压后得到 /opt/video-buildchain
            val opt = File(rootfs, "opt"); if (!opt.isDirectory) opt.mkdirs()
            val old = File(opt, "video-buildchain")
            if (old.exists()) deleteRecursive(old)
            extractTarGz(archive, opt)
            val proj = File(opt, "video-buildchain/project")
            if (!proj.isDirectory) error("解压布局异常：未找到 video-buildchain/project")
            // 可执行权限 + ffmpeg
            File(proj, "build.sh").takeIf { it.isFile }?.setExecutable(true, false)
            File(proj, "render.py").takeIf { it.isFile }?.setExecutable(true, false)
            val ffdir = File(opt, "video-buildchain/pypkgs/imageio_ffmpeg/binaries")
            ffdir.listFiles { f -> f.isFile && f.name.startsWith("ffmpeg-") }?.forEach { it.setExecutable(true, false) }
        },
        Resource(
            id = "ndk",
            title = t("ndk"),
            desc = d("ndk"),
            shareUrl = "https://share.feijipan.com/s/DVw1Sb6y",
            isInstalled = inst("ndk")
        ) { archive ->
            val rootfs = rootfsDir()
            if (!File(rootfs, "bin/sh").isFile) error("沙箱尚未初始化：请先在对话中让 AI 执行一次终端命令，再回来部署")
            // 解压到 /opt（包内顶层就是 android-ndk-toolchain/），得到 /opt/android-ndk-toolchain
            val opt = File(rootfs, "opt"); if (!opt.isDirectory) opt.mkdirs()
            val old = File(opt, "android-ndk-toolchain")
            if (old.exists()) deleteRecursive(old)
            extractTarGz(archive, opt)
            val tc = File(opt, "android-ndk-toolchain")
            if (!File(tc, "bin/clang").isFile) error("解压布局异常：未找到 android-ndk-toolchain/bin/clang")
            // 复原可执行权限（tar 已带 mode，但保险起见再设一次）
            File(tc, "bin/clang").setExecutable(true, false)
            File(tc, "bin/clang++").setExecutable(true, false)
            File(tc, "bin/ld.lld").setExecutable(true, false)
            File(tc, "bin/ncc").takeIf { it.isFile }?.setExecutable(true, false)
            File(tc, "bin/ncc++").takeIf { it.isFile }?.setExecutable(true, false)
            File(tc, "qemu-x86_64-static").setExecutable(true, false)
            File(tc, "bin").listFiles()?.forEach { it.setExecutable(true, false) }
            // 软链常用入口到 /usr/local/bin，方便直接敲
            val pathBin = File(rootfs, "usr/local/bin"); pathBin.mkdirs()
            listOf("clang", "clang++", "ld.lld", "llvm-ar", "llvm-strip", "llvm-objcopy", "ncc", "ncc++").forEach { name ->
                val src = File(tc, "bin/$name"); if (src.isFile) {
                    val link = File(pathBin, "ndk-$name"); link.delete()
                    runCatching { android.system.Os.symlink(src.absolutePath, link.absolutePath) }
                }
            }
        },
        Resource(
            id = "rev_toolchain",
            title = t("rev_toolchain"),
            desc = d("rev_toolchain"),
            // 不写 direct：走 APK 内 FeijipanParser 解析（网盘直链带时间戳会过期，
            // 每次部署都要重新解析分享链接拿新直链）。
            shareUrl = "https://share.feijipan.com/s/ehwnTbZ8",
            isInstalled = inst("rev_toolchain")
        ) { archive ->
            val rootfs = rootfsDir()
            if (!File(rootfs, "bin/sh").isFile) error("沙箱尚未初始化：请先在对话中让 AI 执行一次终端命令，再回来部署")
            // 直接解压到 /opt（包内顶层就是 rev-toolchain/），得到 /opt/rev-toolchain
            val opt = File(rootfs, "opt"); if (!opt.isDirectory) opt.mkdirs()
            val old = File(opt, "rev-toolchain")
            if (old.exists()) deleteRecursive(old)
            extractTarGz(archive, opt)
            val base = File(opt, "rev-toolchain")
            if (!File(base, "bin/apktool").isFile) error("解压布局异常：未找到 rev-toolchain/bin/apktool")
            // 恢复可执行权限（bin/ 下 wrapper + jadx 脚本 + dex2jar 脚本）
            File(base, "bin").listFiles()?.forEach { it.setExecutable(true, false) }
            File(base, "jadx/bin").listFiles()?.forEach { it.setExecutable(true, false) }
            File(base, "dex2jar").listFiles { f -> f.name.endsWith(".sh") }?.forEach { it.setExecutable(true, false) }
        }
        )
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        resourceList = resources()
        stateMap = resourceList.associate { it.id to ItemState() }.toMutableMap()
        // resources() 若存在重复 id，associate 后的 map 元素数会少于列表长度，
        // 直接 !! 取会在重复项上崩。用 getOrPut 兜住。
        resourceList.forEach {
            stateMap.getOrPut(it.id) { ItemState() }.installed =
                runCatching { it.isInstalled() }.getOrDefault(false)
        }
        setContent { AgentTheme { Content() } }
    }

    @Composable
    private fun Content() {
        SubPage("下载环境", "按需下载并部署运行组件到沙箱，供 AI 终端使用",
            onBack = { finish() }, scrollable = false) {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(resourceList) { res -> ResourceCard(res) }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }

    @Composable
    private fun ResourceCard(res: Resource) {
        val s = stateMap.getOrPut(res.id) { ItemState() }
        AgentCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBox(
                    if (s.installed) Icons.Outlined.CheckCircle else Icons.Outlined.CloudDownload,
                    if (s.installed) AColors.Success else AColors.Accent,
                )
                Column(Modifier.weight(1f).padding(start = 13.dp)) {
                    Text(res.title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = AColors.Ink)
                    if (s.installed && s.progress < 0) {
                        Text("已安装 · 可重新下载覆盖", fontSize = 11.sp, color = AColors.Success,
                            modifier = Modifier.padding(top = 3.dp))
                    }
                }
            }
            Text(res.desc, fontSize = 12.sp, color = AColors.Muted,
                modifier = Modifier.padding(top = 10.dp), lineHeight = 17.sp)

            if (s.progress >= 0) {
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { (s.progress.coerceIn(0, 100)) / 100f },
                    modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)),
                    color = if (s.failed) AColors.Danger else AColors.Accent,
                    trackColor = AColors.LineSoft,
                )
                if (s.status.isNotBlank()) {
                    Text(s.status, fontSize = 11.sp,
                        color = if (s.failed) AColors.Danger else AColors.Muted,
                        modifier = Modifier.padding(top = 7.dp), lineHeight = 15.sp)
                }
            }

            Spacer(Modifier.height(14.dp))
            val label = when {
                s.running -> "下载中…"
                s.failed -> "重试"
                s.installed -> "重新下载"
                else -> "下载部署"
            }
            Box(
                Modifier.clip(RoundedCornerShape(ADimens.CardRadiusSmall))
                    .background(if (s.running) AColors.Accent.copy(alpha = .5f) else AColors.Accent)
                    .clickable(enabled = !s.running) { startDownload(res, s) }
                    .fillMaxWidth().height(44.dp),
                contentAlignment = Alignment.Center,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (!s.running) Icon(Icons.Outlined.Download, contentDescription = null,
                        tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.size(17.dp))
                    if (!s.running) Spacer(Modifier.width(7.dp))
                    Text(label, fontSize = 14.sp, color = androidx.compose.ui.graphics.Color.White,
                        fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }

    private fun startDownload(res: Resource, s: ItemState) {
        if (s.running) return
        s.running = true
        s.failed = false
        s.progress = 0
        s.status = "解析分享链接…"
        executor.execute { runPipeline(res, s) }
    }

    private fun runPipeline(res: Resource, s: ItemState) {
        fun ui(body: () -> Unit) = runOnUiThread(body)
        fun setBar(p: Int) = ui { if (p in 0..100) s.progress = p }
        fun setStatus(t: String) = ui { s.status = t }
        try {
            // ---- 特殊通道：系统镜像 / Python 运行时 ----
            // 这两样首次启动由 BootActivity → SandboxInstaller.ensureInstalled
            // 自动安装；断网会静默跳过（runCatching 放行），所以这里给补装入口。
            // 直接复用 SandboxInstaller 现成的多源回退 + 分块解压，不重写逻辑。
            if (res.special != null) {
                val progress = object : com.agentpad.workspace.ai.SandboxInstaller.Progress {
                    override fun onMessage(text: String) = setStatus(text)
                    override fun onProgress(percent: Int) = setBar(percent)
                }
                when (res.special) {
                    "rootfs" -> com.agentpad.workspace.ai.SandboxInstaller.reinstallRootfs(this, progress)
                    "python3" -> com.agentpad.workspace.ai.SandboxInstaller.reinstallPython(this, progress)
                }
                val verified = runCatching { res.isInstalled() }.getOrDefault(false)
                if (!verified) error("补装完成但校验未通过：未找到目标文件/可执行文件")
                setBar(100)
                setStatus("已部署 ✓")
                s.installed = true
                s.running = false
                ui { Toast.makeText(this, "${res.title}部署完成", Toast.LENGTH_SHORT).show() }
                return
            }

            val (direct, name) = if (res.direct) {
                // 直链模式：shareUrl 本身就是可下载地址，无需解析网盘
                setStatus("开始下载…")
                res.shareUrl to res.archiveName.ifBlank { "${res.id}.tar.gz" }
            } else {
                setStatus("解析分享链接…")
                val resolved = JSONObject(FeijipanParser.resolve(res.shareUrl))
                resolved.getString("url") to resolved.optString("name").ifBlank { "${res.id}.tar.gz" }
            }
            setBar(0)

            val cache = File(cacheDir, "download-env").apply { mkdirs() }
            val archive = File(cache, name)
            if (archive.exists()) archive.delete()

            download(direct, archive) { p, done, total ->
                setBar(p)
                if (total > 0) setStatus("下载中 ${formatSize(done)} / ${formatSize(total)}")
            }

            setStatus("正在部署到沙箱…")
            // special 通道在上面已 return，走到这里的卡片一定带 install。
            res.install?.invoke(archive)
                ?: error("该组件缺少安装逻辑（内部错误：未指定 install 或 special）")
            archive.delete()

            // 部署后按判据重新校验，避免「下载完成但判据不匹配 → 又显示未安装」
            val verified = runCatching { res.isInstalled() }.getOrDefault(false)
            if (!verified) error("部署完成但校验未通过：未找到目标文件，可能是安装判据与实际解压路径不一致")

            setBar(100)
            setStatus("已部署 ✓")
            s.installed = true
            s.running = false
            ui { Toast.makeText(this, "${res.title}部署完成", Toast.LENGTH_SHORT).show() }
        } catch (e: Exception) {
            setStatus("失败：${e.message}")
            ui { s.failed = true; s.running = false }
        }
    }

    private fun download(urlString: String, target: File, onProgress: (Int, Long, Long) -> Unit) {
        target.parentFile?.mkdirs()
        val conn = (URL(urlString).openConnection() as HttpURLConnection).apply {
            connectTimeout = 25_000; readTimeout = 300_000
            // 飞基盘直链需要 Referer；自家服务器直链给了也无害
            setRequestProperty("Referer", "https://www.feijipan.com/")
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36")
            setRequestProperty("Accept", "*/*")
        }
        val total = conn.contentLengthLong
        conn.inputStream.use { input ->
            BufferedInputStream(input).use { buffered ->
                FileOutputStream(target, false).use { out ->
                    val buf = ByteArray(64 * 1024)
                    var read: Int; var done = 0L; var lastPct = -1
                    while (buffered.read(buf).also { read = it } > 0) {
                        out.write(buf, 0, read); done += read
                        if (total > 0) {
                            val pct = (done * 100 / total).toInt().coerceIn(0, 100)
                            if (pct != lastPct) { lastPct = pct; onProgress(pct, done, total) }
                        }
                    }
                }
            }
        }
        conn.disconnect()
        if (total > 0 && target.length() != total) error("下载不完整：${target.length()}/${total} 字节")
    }

    private fun deleteRecursive(f: File) {
        if (f.isDirectory) f.listFiles()?.forEach { deleteRecursive(it) }
        f.delete()
    }

    private fun extractTarGz(archive: File, targetDir: File) {
        targetDir.mkdirs()
        val buffer = ByteArray(8192)
        GZIPInputStream(BufferedInputStream(archive.inputStream())).use { input ->
            while (true) {
                val header = ByteArray(512)
                var off = 0
                while (off < 512) {
                    val n = input.read(header, off, 512 - off)
                    if (n < 0) { if (off == 0) return; throw IllegalStateException("truncated tar header") }
                    off += n
                }
                if (header.all { it == 0.toByte() }) return
                val name = header.copyOfRange(0, 100).decodeToString().trimEnd('\u0000')
                val prefix = header.copyOfRange(345, 500).decodeToString().trimEnd('\u0000')
                val relative = (if (prefix.isBlank()) name else "$prefix/$name").trim()
                if (relative.isBlank()) continue
                val size = parseOctal(header, 124, 12)
                val mode = parseOctal(header, 100, 8).toInt()
                val type = header[156].toInt().toChar()
                val linkName = header.copyOfRange(157, 257).decodeToString().trimEnd('\u0000')
                val outFile = File(targetDir, relative)
                when (type) {
                    '5' -> outFile.mkdirs()
                    '1' -> { val src = File(targetDir, linkName); if (src.isFile) { outFile.delete(); src.copyTo(outFile, overwrite = true) } }
                    '2' -> { outFile.delete(); runCatching { android.system.Os.symlink(linkName, outFile.absolutePath) }.onFailure { runCatching { File(targetDir, linkName).copyTo(outFile, overwrite = true) } } }
                    '0', '\u0000' -> {
                        outFile.delete()
                        outFile.parentFile?.mkdirs()
                        FileOutputStream(outFile, false).use { out ->
                            var left = size
                            while (left > 0) {
                                val count = input.read(buffer, 0, minOf(buffer.size.toLong(), left).toInt())
                                if (count < 0) throw IllegalStateException("truncated tar entry")
                                out.write(buffer, 0, count); left -= count
                            }
                        }
                        if ((mode and 0b001000000) != 0) outFile.setExecutable(true, false)
                    }
                    else -> { var left = size; while (left > 0) { val c = input.read(buffer, 0, minOf(buffer.size.toLong(), left).toInt()); if (c < 0) break; left -= c } }
                }
                val pad = ((size + 511) / 512 * 512 - size).toInt()
                var skip = pad.toLong()
                while (skip > 0) { val c = input.read(buffer, 0, minOf(buffer.size.toLong(), skip).toInt()); if (c < 0) break; skip -= c }
            }
        }
    }

    private fun parseOctal(header: ByteArray, offset: Int, length: Int): Long {
        var result = 0L
        for (i in offset until offset + length) {
            val b = header[i].toInt().toChar()
            if (b == '\u0000' || b == ' ') break
            if (b in '0'..'7') result = result * 8 + (b - '0')
        }
        return result
    }

    private fun formatSize(bytes: Long): String = when {
        bytes >= 1_048_576 -> "%.1f MB".format(bytes / 1_048_576.0)
        bytes >= 1024 -> "%.0f KB".format(bytes / 1024.0)
        else -> "$bytes B"
    }
}