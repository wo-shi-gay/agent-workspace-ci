package com.agentpad.workspace

import android.app.Notification
import android.app.Service
import android.os.Build

/**
 * 前台服务启动兼容层。
 *
 * 为什么需要它（2026-11-05 修复）：
 *   各 Service 原来各自写一份 startForeground，写法不统一，踩了两个坑：
 *
 *   1) AdbPairingService 直接调用 `startForeground(id, notif, type)` 三参重载。
 *      该重载是 **API 29（Q）** 才加入的；本项目 minSdk = 26，
 *      在 Android 8.0 / 9 上调用会抛 NoSuchMethodError。
 *      调用点外面套了 runCatching，异常被吞 → 前台服务根本没起来
 *      → 进程按普通后台服务处理 → 几秒内被系统回收，无线调试配对必断。
 *
 *   2) 另外三个 Service（AdbKeepAlive / KeepAliveNotification / WorkingBubble）
 *      用两参重载，而清单里声明了 `foregroundServiceType="specialUse"`。
 *      Android 14（API 34）起，specialUse 类型必须与清单声明显式匹配，
 *      部分 ROM 上两参重载会抛 MissingForegroundServiceTypeException
 *      （同样被 runCatching 吞掉 → 通知不出现）。
 *
 * 统一策略：
 *   - API 34+ ：三参重载 + FOREGROUND_SERVICE_TYPE_SPECIAL_USE（与清单一致）
 *   - API 29~33：两参重载（用清单里声明的类型）
 *   - API 26~28：两参重载（三参重载不存在）
 *   任一步失败都退到两参重载，再失败只记录不抛出——前台服务失败不该让业务崩。
 */
internal object ForegroundCompat {

    /**
     * ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE 的数值。
     * 该常量本身是 API 34 才公开的，这里用字面量，避免低版本编译期/运行期依赖。
     */
    private const val TYPE_SPECIAL_USE = 0x40000000

    /** API 34 = Android 14，从这里开始 specialUse 需要显式类型。 */
    private const val API_SPECIAL_USE_REQUIRED = 34

    /**
     * 把 service 提升为前台服务。
     * @return true 表示系统已接受前台服务请求。
     */
    fun start(service: Service, id: Int, notification: Notification): Boolean {
        // 首选：API 34+ 用三参重载显式声明 specialUse
        if (Build.VERSION.SDK_INT >= API_SPECIAL_USE_REQUIRED) {
            val ok = runCatching {
                service.startForeground(id, notification, TYPE_SPECIAL_USE)
            }.isSuccess
            if (ok) return true
        }
        // 兜底：两参重载（API 26~33 的唯一选择）
        return runCatching { service.startForeground(id, notification) }.isSuccess
    }
}
