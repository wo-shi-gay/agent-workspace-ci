package com.agentpad.workspace

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.agentpad.workspace.ai.SandboxInstaller
import com.agentpad.workspace.ai.TerminalMonitor
import com.agentpad.workspace.ai.TerminalService
import com.agentpad.workspace.databinding.ActivityTerminalBinding
import com.agentpad.workspace.terminal.VirtualKeyAction
import com.agentpad.workspace.terminal.VirtualKeyConfig
import com.agentpad.workspace.terminal.VirtualKeyboardConfigManager

/**
 * 交互式终端（重构版）。
 *
 * 交互模型（唯一一套，不再有「命令行 / 直接输入」双模式割裂）：
 *  - 底部输入行输入 → 回车 → 直接写 PTY。shell 自己回显，所以屏上
 *    只出现一次命令，不会像旧版那样输入框和终端各显示一份。
 *  - 常驻快捷键条提供 Ctrl+C / ESC / TAB / CTRL / ALT / 方向键。
 *  - 「⌨」展开 2×7 完整虚拟键盘（给 vim / less / top 这类程序）。
 *  - 长按终端画布选中文本 → 顶部浮动条提供复制 / 取消。
 *
 * 输入法用 adjustNothing，键盘弹出不会改变 PTY 行列，避免画面跳动。
 */
class TerminalActivity : Activity() {

    private lateinit var binding: ActivityTerminalBinding
    private lateinit var chatSessionId: String
    private var selectedId: String? = null
    private var unsubscribe: (() -> Unit)? = null
    private val ui = Handler(Looper.getMainLooper())
    private var lastSessionCount = 0

    private var ctrlActive = false
    private var altActive = false
    private var showVirtualKeyboard = false

    private lateinit var layoutManager: VirtualKeyboardConfigManager
    private lateinit var keyboardLayout: com.agentpad.workspace.terminal.VirtualKeyboardLayout

    /** 刷新节拍：只在 screen.dirty 为 true 时才重绘（不再无条件刷）。 */
    private val refresh = object : Runnable {
        override fun run() {
            binding.output.invalidateIfDirty()
            val count = TerminalMonitor.snapshot().size
            if (count != lastSessionCount) { lastSessionCount = count; rebuildTabs() }
            ui.postDelayed(this, REFRESH_MS)
        }
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        binding = ActivityTerminalBinding.inflate(layoutInflater)
        setContentView(binding.root)
        chatSessionId = intent.getStringExtra("session_id") ?: "terminal"
        layoutManager = VirtualKeyboardConfigManager.getInstance(this)
        keyboardLayout = layoutManager.loadLayout()

        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)

        binding.back.setOnClickListener { finish() }
        binding.newSession.setOnClickListener { newSession() }
        binding.closeSession.setOnClickListener { closeCurrent() }
        binding.btnFontUp.setOnClickListener { changeFont(+2f) }
        binding.btnFontDown.setOnClickListener { changeFont(-2f) }

        binding.output.onGridChanged = { rows, cols -> selectedId?.let { TerminalService.resize(it, rows, cols) } }
        binding.output.onCopyRequested = { text -> copyToClipboard(text) }
        binding.output.onSelectionChanged = { has -> binding.copyHint.visibility = if (has) View.VISIBLE else View.GONE }
        binding.btnCopy.setOnClickListener {
            binding.output.copySelection()
            binding.output.clearSelection()
            binding.copyHint.visibility = View.GONE
        }
        binding.btnCopyCancel.setOnClickListener {
            binding.output.clearSelection()
            binding.copyHint.visibility = View.GONE
        }

        setupCommandInput()
        buildQuickKeys()
        buildVirtualKeyboard()
        applyVirtualKeyboardVisibility()

        binding.root.viewTreeObserver.addOnGlobalLayoutListener { updateBottomInset() }

        ensureSession()
        lastSessionCount = TerminalMonitor.snapshot().size
        unsubscribe = TerminalMonitor.observe { updated ->
            if (updated.id != selectedId) return@observe
            ui.post { updateStatus(updated.running, updated.cwd) }
        }
        ui.post(refresh)
    }

    // ------------------------------------------------------------- sessions

    private fun ensureSession() {
        val base = TerminalService.aiSessionId(chatSessionId)
        if (TerminalMonitor.snapshot().any { it.id == base }) { select(base); return }
        createSession(base, "终端 ${chatSessionId.takeLast(4)}")
        select(base)
    }

    private fun newSession() {
        val base = TerminalService.aiSessionId(chatSessionId)
        val id = "${base}_${System.currentTimeMillis()}"
        createSession(id, "终端 ${id.takeLast(4)}")
        select(id)
    }

    private fun createSession(id: String, title: String) {
        val cwd = SandboxInstaller.projectDir(this)
        cwd.mkdirs()
        TerminalService.createSession(
            id, title,
            SandboxInstaller.sandboxDir(this),
            SandboxInstaller.rootfsDir(this),
            SandboxInstaller.nativeDir(this),
            SandboxInstaller.initScript(this), cwd
        )
    }

    private fun select(id: String) {
        selectedId = id
        openSession(id)
    }

    private fun closeCurrent() {
        val id = selectedId ?: return
        TerminalService.closeSession(id)
        selectedId = null
        val next = TerminalMonitor.snapshot().lastOrNull()
        if (next != null) select(next.id) else ensureSession()
    }

    private fun openSession(id: String) {
        val session = TerminalMonitor.snapshot().firstOrNull { it.id == id } ?: return
        val screen = session.screen
        if (screen != null && binding.output.screen !== screen) {
            binding.output.bind(screen)
            binding.output.scrollToBottom()
        }
        binding.title.text = session.title
        updateStatus(session.running, session.cwd)
        rebuildTabs()
    }

    private fun updateStatus(running: Boolean, cwd: String) {
        binding.status.text = shortenCwd(cwd)
        binding.statusDot.setTextColor(if (running) colorRes(R.color.term_ok) else colorRes(R.color.term_muted))
        binding.title.setCompoundDrawablesWithIntrinsicBounds(
            0, 0, 0, 0
        )
    }

    /** 把 /storage/emulated/0/xxx/yyy 缩成 …/xxx/yyy，避免挤掉状态圆点。 */
    private fun shortenCwd(cwd: String): String {
        val parts = cwd.trimEnd('/').split('/').filter { it.isNotBlank() }
        return when {
            parts.isEmpty() -> "/"
            parts.size <= 2 -> "/" + parts.joinToString("/")
            else -> "…/" + parts.takeLast(2).joinToString("/")
        }
    }

    private fun rebuildTabs() {
        binding.sessions.removeAllViews()
        val sessions = TerminalMonitor.snapshot()
        // 只有一个会话时不显示标签栏，省出屏幕高度
        binding.sessionsScroll.visibility = if (sessions.size <= 1) View.GONE else View.VISIBLE
        sessions.forEach { item ->
            val active = item.id == selectedId
            binding.sessions.addView(TextView(this).apply {
                text = item.title
                textSize = 11.5f
                gravity = Gravity.CENTER
                setPadding(dp(12), 0, dp(12), 0)
                setTextColor(colorRes(if (active) R.color.term_fg else R.color.term_muted))
                background = GradientDrawable().apply {
                    cornerRadius = dp(11).toFloat()
                    setColor(colorRes(if (active) R.color.term_key_active else R.color.term_key))
                }
                setOnClickListener { select(item.id) }
            }, LinearLayout.LayoutParams(-2, dp(26)).apply { rightMargin = dp(6) })
        }
    }

    // ----------------------------------------------------------- 输入

    private fun setupCommandInput() {
        binding.command.setOnEditorActionListener { _, actionId, event ->
            val isSend = actionId == EditorInfo.IME_ACTION_SEND ||
                actionId == EditorInfo.IME_ACTION_DONE ||
                actionId == EditorInfo.IME_ACTION_UNSPECIFIED
            // 回车直接执行；Shift+Enter 允许换行（这里单行，行为一致）
            if (isSend) { sendCommand(); true } else false
        }
        binding.send.setOnClickListener { sendCommand() }
    }

    private fun sendCommand() {
        val id = selectedId ?: return
        val text = binding.command.text.toString()
        if (text.isEmpty()) return
        val output = applyModifiers(text)
        binding.command.setText("")
        // \r = 按下回车
        TerminalService.sendInput(id, "$output\r")
        consumeModifiers()
        binding.output.scrollToBottom()
    }

    private fun applyCtrlChar(ch: Char): String? = when {
        ch in 'a'..'z' || ch in 'A'..'Z' -> (ch.uppercaseChar().code - 64).toChar().toString()
        ch == ' ' || ch == '@' -> "\u0000"
        ch == '[' -> "\u001b"
        ch == '\\' -> "\u001c"
        ch == ']' -> "\u001d"
        ch == '^' -> "\u001e"
        ch == '_' -> "\u001f"
        else -> null
    }

    private fun applyModifiers(input: String): String {
        var out = input
        if (ctrlActive) {
            val sb = StringBuilder()
            input.forEach { c ->
                val mapped = applyCtrlChar(c)
                if (mapped != null) sb.append(mapped) else sb.append(c)
            }
            out = sb.toString()
        }
        if (altActive && !out.startsWith("\u001b")) out = "\u001b$out"
        return out
    }

    private fun consumeModifiers() {
        ctrlActive = false
        altActive = false
        styleKeys()
    }

    /** 发送虚拟键的原始输入（带上已按下的修饰键）。 */
    private fun sendDirectInput(value: String) {
        val id = selectedId ?: return
        val decoded = VirtualKeyboardConfigManager.decodeKeyValue(value)
        val out = if (ctrlActive || altActive) applyModifiers(decoded) else decoded
        TerminalService.sendInput(id, out)
        if (ctrlActive || altActive) consumeModifiers()
        binding.output.scrollToBottom()
    }

    // ------------------------------------------------------- 常驻快捷键条

    /**
     * 常驻快捷条：不折叠、不需要先开键盘。
     * 顺序按使用频率排：中断 → ESC → TAB → CTRL → ALT → 方向 → 上翻 → 键盘。
     */
    private fun buildQuickKeys() {
        val keys = listOf(
            QuickKey("Ctrl+C", activeCheck = false) {
                selectedId?.let { TerminalService.sendInput(it, "\u0003") }
                binding.output.scrollToBottom()
            },
            QuickKey("ESC") { sendDirectInput("\\e") },
            QuickKey("TAB") { sendDirectInput("\\t") },
            QuickKey("CTRL", isToggle = true) { ctrlActive = !ctrlActive; styleKeys() },
            QuickKey("ALT", isToggle = true) { altActive = !altActive; styleKeys() },
            QuickKey("←") { sendDirectInput("\\e[D") },
            QuickKey("↑") { binding.output.lineUp() },
            QuickKey("↓") { binding.output.lineDown() },
            QuickKey("→") { sendDirectInput("\\e[C") },
            QuickKey("⇞", compact = true) { binding.output.pageUp() },
            QuickKey("⇟", compact = true) { binding.output.pageDown() },
            QuickKey("⌨", isToggle = true) {
                showVirtualKeyboard = !showVirtualKeyboard
                applyVirtualKeyboardVisibility()
            },
        )
        binding.quickKeys.removeAllViews()
        keys.forEach { k ->
            val tv = TextView(this).apply {
                text = k.label
                textSize = if (k.compact) 14f else 12f
                gravity = Gravity.CENTER
                setPadding(dp(11), 0, dp(11), 0)
                setTextColor(colorRes(R.color.term_key_text))
                background = keyBackground(false)
                setOnClickListener {
                    k.onClick()
                    if (k.isToggle) styleKeys()
                }
                tag = k
            }
            binding.quickKeys.addView(tv, LinearLayout.LayoutParams(-2, dp(30)).apply { rightMargin = dp(6) })
        }
        styleKeys()
    }

    private fun styleKeys() {
        for (i in 0 until binding.quickKeys.childCount) {
            val v = binding.quickKeys.getChildAt(i) as? TextView ?: continue
            val k = v.tag as? QuickKey ?: continue
            val active = when (k.label) {
                "CTRL" -> ctrlActive
                "ALT" -> altActive
                "⌨" -> showVirtualKeyboard
                else -> false
            }
            v.background = keyBackground(active)
            // 注意：这里必须直接 setTextColor(int 颜色值)。
            // 之前写成 colorRes(if (active) Color.WHITE else colorRes(R.color.term_key_text))，
            // 内层 colorRes 已经解析出 ARGB 值，外层又把它当资源 ID 传给
            // ContextCompat.getColor() → Resources$NotFoundException: Resource ID #0xffc9d2e0，
            // 一进终端就闪退。
            v.setTextColor(if (active) Color.WHITE else colorRes(R.color.term_key_text))
        }
        styleVirtualKeys()
    }

    private fun keyBackground(active: Boolean) = GradientDrawable().apply {
        cornerRadius = dp(10).toFloat()
        setColor(colorRes(if (active) R.color.term_key_active else R.color.term_key))
    }

    // ------------------------------------------------------- 完整虚拟键盘

    private fun buildVirtualKeyboard() {
        binding.virtualKeyboard.removeAllViews()
        keyboardLayout.rows.forEach { row ->
            val rowView = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(-1, dp(40)).apply { bottomMargin = dp(5) }
            }
            row.forEach { key ->
                rowView.addView(makeKeyView(key), LinearLayout.LayoutParams(0, -1, 1f).apply { rightMargin = dp(5) })
            }
            binding.virtualKeyboard.addView(rowView)
        }
    }

    private fun makeKeyView(key: VirtualKeyConfig): TextView = TextView(this).apply {
        text = key.label
        textSize = 12f
        gravity = Gravity.CENTER
        setTextColor(colorRes(R.color.term_key_text))
        background = keyBackground(false)
        setOnClickListener {
            when (key.action) {
                VirtualKeyAction.TOGGLE_CTRL -> { ctrlActive = !ctrlActive; styleKeys() }
                VirtualKeyAction.TOGGLE_ALT -> { altActive = !altActive; styleKeys() }
                VirtualKeyAction.SEND_TEXT -> sendDirectInput(key.value)
            }
        }
    }

    private fun styleVirtualKeys() {
        for (i in 0 until binding.virtualKeyboard.childCount) {
            val row = binding.virtualKeyboard.getChildAt(i) as? ViewGroup ?: continue
            for (j in 0 until row.childCount) {
                val v = row.getChildAt(j) as? TextView ?: continue
                val active = (v.text == "CTRL" && ctrlActive) || (v.text == "ALT" && altActive)
                v.background = keyBackground(active)
            }
        }
    }

    private fun applyVirtualKeyboardVisibility() {
        binding.virtualKeyboard.visibility = if (showVirtualKeyboard) View.VISIBLE else View.GONE
        val idx = (0 until binding.quickKeys.childCount)
            .map { binding.quickKeys.getChildAt(it) }
            .filterIsInstance<TextView>()
            .indexOfLast { it.text == "⌨" }
        if (idx >= 0) {
            (binding.quickKeys.getChildAt(idx) as? TextView)?.background = keyBackground(showVirtualKeyboard)
        }
    }

    // ------------------------------------------------------------- 字号

    private fun changeFont(delta: Float) {
        binding.output.setFontSize(binding.output.getFontSize() + delta)
    }

    // ------------------------------------------------------------------- IME

    private fun hideIme() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(binding.command.windowToken, 0)
    }

    private fun showIme() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.showSoftInput(binding.command, InputMethodManager.SHOW_IMPLICIT)
    }

    /** adjustNothing 下自己给画布预留输入法高度。 */
    private fun updateBottomInset() {
        val r = android.graphics.Rect()
        binding.root.getWindowVisibleDisplayFrame(r)
        val hidden = (binding.root.rootView.height - r.bottom).coerceAtLeast(0)
        binding.output.setBottomInset(hidden)
    }

    private fun copyToClipboard(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("terminal", text))
        Toast.makeText(this, "已复制 ${text.length} 个字符", Toast.LENGTH_SHORT).show()
    }

    // -------------------------------------------------------------- lifecycle

    override fun onResume() {
        super.onResume()
        binding.command.requestFocus()
        showIme()
        // 回到前台恢复刷新节拍（onPause 时停掉了，避免后台空转）
        ui.removeCallbacks(refresh)
        ui.post(refresh)
        // 后台期间可能积累了输出，回来立刻补一帧
        binding.output.invalidateIfDirty()
    }

    override fun onPause() {
        super.onPause()
        // 后台停止 100ms 轮询：PTY 仍在跑（AI 可能还在执行命令），
        // 但没必要在不可见时反复 invalidate，省电也避免和主线程抢时间片。
        ui.removeCallbacks(refresh)
    }

    override fun onDestroy() {
        unsubscribe?.invoke()
        unsubscribe = null
        ui.removeCallbacks(refresh)
        super.onDestroy()
    }

    // ------------------------------------------------------------------ util

    private fun colorRes(id: Int): Int = androidx.core.content.ContextCompat.getColor(this, id)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    /** 常驻快捷条上的一个键。 */
    private class QuickKey(
        val label: String,
        val isToggle: Boolean = false,
        val compact: Boolean = false,
        val activeCheck: Boolean = false,
        val onClick: () -> Unit,
    )

    companion object {
        /**
         * 刷新节拍。90ms 太频繁（每秒 11 次 invalidate 检查）；
         * 配合 dirty 标记后 60ms 也够用，但为了省电取 100ms。
         * 真正输出时 AnsiScreen 会置 dirty，下一拍就画。
         */
        private const val REFRESH_MS = 100L
    }
}
