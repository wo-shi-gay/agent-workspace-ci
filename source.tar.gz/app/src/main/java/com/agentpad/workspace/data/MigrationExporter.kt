package com.agentpad.workspace.data

import android.content.Context
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * 4.6 数据迁移导出器 —— 「完整迁移包」。
 *
 * 定位：4.6 只负责**把用户数据完整导出**成一个 zip；真正的换包名 / 换签名
 * 迁移发生在 4.7（新的 importer 负责读这个包）。
 *
 * ── 导什么 ──────────────────────────────────────────────
 *  ✅ SharedPreferences（含登录 token、会话 JSON→里面有 mode 项目类型标识）
 *  ✅ workspaces/<sessionId>/（用户真实工作成果，原样搬运，不筛选、不改名）
 *  ✅ files/plugins/（已装插件）
 *  ✅ files/chat_bg/（对话背景图/视频）
 *  ✅ files/mcp-workspace/（MCP 工作目录）
 *
 * ── 不导什么（主人明确要求）──────────────────────────────
 *  ❌ files/sandbox/rootfs（Debian 系统镜像，几百 MB，4.7 会自动重下）
 *  ❌ Java / Python / Go / Node / NDK / Kotlin / 视频 / 逆向 等工具链
 *     （它们都在 rootfs 的 /opt 或 /usr/local 下，rootfs 不导就自然全部排除）
 *  ❌ logs / crash（无迁移价值）
 *  ❌ ADB 密钥（跟设备绑定，换机无意义）
 *
 * ── 为什么 prefs 要自己序列化 ─────────────────────────────
 * Android 的 SharedPreferences 是进程内对象，磁盘上的 .xml 格式属于实现细节，
 * 直接拷 .xml 会碰到「root 可读但 owner 不同」和「格式版本」两个坑。
 * 这里用 prefs.all 遍历所有键值，写成 JSON —— 4.7 导入时用同一套类型规则
 * 反序列化即可，不依赖 Android 内部格式。
 */
object MigrationExporter {

    /** 迁移包格式版本。4.7 的 importer 靠它判断兼容性。 */
    const val SCHEMA_VERSION = 1

    /** 导出包内的目录布局（importer 必须与此一致）。 */
    private const val DIR_PREFS = "prefs"
    private const val DIR_FILES = "files"
    private const val DIR_WORKSPACES = "workspaces"
    private const val MANIFEST = "manifest.json"

    /**
     * 需要导出的 SharedPreferences 文件名。
     *
     * 刻意**不含** sandbox_prefs / adb_permission / wireless_adb / terminal_settings /
     * announcement_state —— 这些是设备/沙箱绑定状态，换包名后无意义甚至有害。
     */
    val EXPORTED_PREFS = listOf(
        "agent_workspace_store",   // 会话 JSON（含 mode）、API 配置、工作区路径、思考等级
        "user_store",              // 登录 token + 用户名 ← 登录状态
        "theme_prefs",             // 主题色 / 深色
        "chat_background_pref",    // 对话背景
        "prompt_store",            // 全局 + 会话提示词
        "plugin_config",           // 插件启用列表
        "mcp_config",              // MCP 服务器配置
        "remote_workspaces",       // 远程工作区（SSH）
        "file_history",            // 文件改动历史
    )

    /** files/ 下需要导出的子目录（相对 filesDir）。 */
    val EXPORTED_FILE_DIRS = listOf(
        "plugins",
        "chat_bg",
        "mcp-workspace",
    )

    /** 进度回调（都在后台线程调用，UI 侧自行切主线程）。 */
    interface Progress {
        fun onMessage(text: String)
        /** 0..100；总量未知时传 -1（UI 显示不确定进度）。 */
        fun onProgress(percent: Int)
    }

    /**
     * 导出结果。
     * @param ok          是否成功
     * @param zip         产出的 zip 文件（失败时为 null）
     * @param message     给人看的说明
     * @param sessions    导出时识别到的会话数
     * @param bytes       包体积（字节）
     */
    data class Result(
        val ok: Boolean,
        val zip: File?,
        val message: String,
        val sessions: Int = 0,
        val bytes: Long = 0L,
        val mode: Mode = Mode.ZIP,
    )

    /**
     * 导出模式。
     *
     * - [ZIP]  ：打成单个 `.zip`，便于分享/上传网盘，体积小；
     * - [FOLDER]：在下载目录建专属文件夹，把 manifest / prefs / files / workspaces
     *   按原结构**直接铺开**。好处是不用解压就能用文件管理器逐个查看、
     *   单文件拷贝；坏处是几十万个小文件时拷贝很慢。
     */
    enum class Mode { ZIP, FOLDER }

    /**
     * 执行导出。
     *
     * ⚠ 必须在**后台线程**调用（会做大量 IO）。不要在 UI 线程直接调。
     *
     * @param targetDir 落盘目录，通常是 /sdcard/Download/WorkspaceMigration
     * @param mode      压缩包 or 文件夹铺开
     */
    fun export(
        context: Context,
        targetDir: File,
        mode: Mode = Mode.ZIP,
        progress: Progress? = null,
    ): Result {
        val stamp = java.text.SimpleDateFormat("yyyyMMdd-HHmmss", java.util.Locale.US)
            .format(java.util.Date())
        val baseName = "workspace-migration-4.6-$stamp"
        val outFile = when (mode) {
            Mode.ZIP -> File(targetDir, "$baseName.zip")
            Mode.FOLDER -> File(targetDir, baseName)
        }

        return runCatching {
            targetDir.mkdirs()
            if (targetDir.exists() && !targetDir.canWrite()) {
                error("目标目录不可写：${targetDir.absolutePath}")
            }

            progress?.onMessage("统计待导出内容…")

            // ⚠ 内存纪律（4.6 曾在此 OOM 150MB）：
            //   `SharedPreferences.all` 每次调用都会把**整个 pref 文件**复制成一个
            //   HashMap。agent_workspace_store 里存着全部会话的完整消息 JSON，
            //   可达上百 MB。所以这里**只取一次快照**，之后所有读取都走它，
            //   并且处理完立刻置空引用，让 GC 尽早回收。
            val wsPrefs = context.getSharedPreferences("agent_workspace_store", Context.MODE_PRIVATE)
            val wsSnapshot: Map<String, *> = wsPrefs.all

            val sessions = collectSessions(context, wsSnapshot)

            val fileDirs = EXPORTED_FILE_DIRS.filter { File(context.filesDir, it).isDirectory }
            val workspaceRoot = workspaceRoot(context)
            val workspaceDirs = workspaceRoot?.listFiles { f -> f.isDirectory }?.sortedBy { it.name }.orEmpty()

            // 预估总字节数（用于进度条；工作区占绝对大头）
            val totalBytes = workspaceDirs.sumOf { dirSize(it) } +
                fileDirs.sumOf { dirSize(File(context.filesDir, it)) }

            val unit = if (mode == Mode.ZIP) "迁移包" else "迁移文件夹"
            progress?.onMessage("写入$unit（共 ${sessions.length()} 个会话，${formatSize(totalBytes)}）…")

            var written = 0L
            fun tick(delta: Long) {
                written += delta
                if (totalBytes > 0) {
                    val p = ((written * 100) / totalBytes).toInt()
                    if (p in 0..99) progress?.onProgress(p)
                }
            }

            // 预统计一下会话数，用于日志与进度文案；不保留完整 prefs 结构体。
            val sessionCount = sessions.length()
            val manifest = buildManifest(context, sessions, workspaceDirs)
            // sessions 是个小数组（每个会话只有 id/title/mode/条数），留着无妨；
            // 但真正占内存的是 wsSnapshot 里的每个 session_<id> 完整 JSON。
            // manifest 建好后 sessions 也可以放掉。
            @Suppress("UNUSED_EXPRESSION") sessions

            if (mode == Mode.ZIP) {
                BufferedOutputStream(FileOutputStream(outFile)).use { bos ->
                    ZipOutputStream(bos).use { zos ->
                        zos.setLevel(6)   // 平衡速度/体积；工作区大量已是压缩格式，9 收益不大

                        // ---- 1) manifest.json ----
                        putEntry(zos, MANIFEST, manifest.toString(2).toByteArray())

                        // ---- 2) prefs/*.json ----
                        // ⚠ 逐个 pref 现算现写：绝不先把 9 个 pref 全部编成 JSONObject
                        //   再整体持有。agent_workspace_store 一个文件就是上百 MB，
                        //   预先生成 `{key:{t,v}}` 结构等于又复制了一份 → OOM。
                        progress?.onMessage("导出设置与登录状态…")
                        for (name in EXPORTED_PREFS) {
                            val all: Map<String, *> = if (name == "agent_workspace_store") {
                                wsSnapshot
                            } else {
                                context.getSharedPreferences(name, Context.MODE_PRIVATE).all
                            }
                            val obj = JSONObject()
                            for ((k, v) in all) obj.put(k, encodeValue(v))
                            putEntry(zos, "$DIR_PREFS/$name.json", obj.toString().toByteArray())
                            // obj / all 出作用域即可被回收
                        }

                        // ---- 3) files/<子目录>/... ----
                        var dirIndex = 0
                        for (dirName in fileDirs) {
                            dirIndex++
                            progress?.onMessage("导出 $dirName/（$dirIndex/${fileDirs.size}）…")
                            val base = File(context.filesDir, dirName)
                            // ⚠ 进度由 onBytes 回调累加 written；zipTree 的**返回值不要**再加，
                            // 否则同一个字节被计两次，进度会虚高一倍、提前冲到 100%。
                            zipTree(zos, base, "$DIR_FILES/$dirName", buf = TMP_BUF) { tick(it) }
                        }

                        // ---- 4) workspaces/<sessionId>/... ----
                        // 原样搬运：不改名、不筛选、不排除构建产物（主人要求「直接原样」）。
                        var wsIndex = 0
                        for (dir in workspaceDirs) {
                            wsIndex++
                            progress?.onMessage("导出工作区 $wsIndex/${workspaceDirs.size}：${dir.name}")
                            zipTree(zos, dir, "$DIR_WORKSPACES/${dir.name}", buf = TMP_BUF) { tick(it) }
                        }
                    }
                }
            } else {
                // ---- 文件夹模式：按与 zip 完全相同的目录结构铺开 ----
                // 4.7 的 importer 两种模式都认：一个是 zip 条目路径，一个是真实路径，
                // 相对结构一致，所以解析代码可以共用。
                outFile.mkdirs()
                progress?.onMessage("写入清单与设置…")
                File(outFile, MANIFEST).writeText(manifest.toString(2))
                val prefsDir = File(outFile, DIR_PREFS).apply { mkdirs() }
                // 同 ZIP 分支：逐个现算现写，不预生成整份 prefs 结构。
                for (name in EXPORTED_PREFS) {
                    val all: Map<String, *> = if (name == "agent_workspace_store") {
                        wsSnapshot
                    } else {
                        context.getSharedPreferences(name, Context.MODE_PRIVATE).all
                    }
                    val obj = JSONObject()
                    for ((k, v) in all) obj.put(k, encodeValue(v))
                    File(prefsDir, "$name.json").writeText(obj.toString())
                }

                var dirIndex = 0
                for (dirName in fileDirs) {
                    dirIndex++
                    progress?.onMessage("复制 $dirName/（$dirIndex/${fileDirs.size}）…")
                    copyTree(File(context.filesDir, dirName), File(outFile, "$DIR_FILES/$dirName")) { tick(it) }
                }

                var wsIndex = 0
                for (dir in workspaceDirs) {
                    wsIndex++
                    progress?.onMessage("复制工作区 $wsIndex/${workspaceDirs.size}：${dir.name}")
                    copyTree(dir, File(outFile, "$DIR_WORKSPACES/${dir.name}")) { tick(it) }
                }
            }

            progress?.onProgress(100)
            val size = if (mode == Mode.ZIP) outFile.length() else dirSize(outFile)
            progress?.onMessage("导出完成：${formatSize(size)}")
            Result(
                ok = true,
                zip = outFile,
                message = "${unit}已生成（${sessions.length()} 个会话，${formatSize(size)}）",
                sessions = sessions.length(),
                bytes = size,
                mode = mode,
            )
        }.getOrElse { e ->
            runCatching { if (outFile.exists()) outFile.deleteRecursively() }
            Result(false, null, "导出失败：${e.message ?: e.javaClass.simpleName}")
        }
    }

    /** 复用同一块缓冲区，避免每个文件都 new 64KB。 */
    private val TMP_BUF = ByteArray(64 * 1024)

    // ================= 采集 =================

    /** 工作区根目录（所有会话目录的父目录）。 */
    fun workspaceRoot(context: Context): File? {
        val base = context.getExternalFilesDir(null) ?: context.filesDir
        val root = File(base, "workspaces")
        return if (root.isDirectory) root else null
    }

    /**
     * 从 `agent_workspace_store` 里读出全部会话元数据。
     *
     * 直接解析 session JSON，把 **mode（项目类型标识）** 提到 manifest 里做双保险：
     * 即使 4.7 导入时某个 session JSON 解析失败，也能从 manifest 恢复分类。
     */
    private fun collectSessions(
        context: Context,
        prefsSnapshot: Map<String, *>,
    ): JSONArray {
        val out = JSONArray()

        // ⚠ `session_index` **必须显式排除**：
        //   它同样以 "session_" 开头，但值是 StringSet（会话 id 集合），
        //   不是单个会话的 JSON 字符串。若不排除会抛
        //   java.util.HashSet cannot be cast to java.lang.String —— 4.6 实测崩溃点。
        //
        // 以下键都在 agent_workspace_store 里以 session_ 开头，但**不是**会话 JSON：
        //   session_index               → StringSet（会话 id 集合）
        //   session_workspace_<id>      → String（工作区绝对路径）
        //   session_active_<id>         → Long（最后活动时间戳）
        //   session_prompt_<id>         → String（提示词，在 prompt_store 里，这里防御性排除）
        //   session_title_locked_<id>   → Boolean（标题已锁定）
        //   session_title_done_<id>     → Boolean/String（自动命名已完成）
        fun isSessionJsonKey(k: String): Boolean {
            if (!k.startsWith("session_")) return false
            if (k == "session_index") return false
            if (k.startsWith("session_workspace_")) return false
            if (k.startsWith("session_active_")) return false
            if (k.startsWith("session_prompt_")) return false
            if (k.startsWith("session_title_locked_")) return false
            if (k.startsWith("session_title_done_")) return false
            return true
        }

        val ids = (prefsSnapshot["session_index"] as? Set<*>)
            ?.mapNotNull { it?.toString() }
            ?.toMutableSet()
            ?: mutableSetOf()
        // session_index 可能不全（历史遗留），补扫所有 session_* 键。
        // 但只收「值确实是 String」的键，避免又踩到别的集合类型。
        prefsSnapshot.forEach { (k, v) ->
            if (isSessionJsonKey(k) && v is String) ids.add(k.removePrefix("session_"))
        }

        val wsRoot = workspaceRoot(context)
        ids.sorted().forEach { id ->
            // 直接查快照，不再调用 prefs.all（那是 O(n) 的全量拷贝）。
            val raw = prefsSnapshot["session_$id"] as? String ?: return@forEach
            val obj = runCatching { JSONObject(raw) }.getOrNull() ?: return@forEach
            // ⚠ 别把 return@forEach 写进 .put(...) 的参数里：那会让整条 put 链
            // 在求值时提前中止，manifest 里只剩 hasWorkspace，title/mode/消息数全丢。
            val hasWorkspace = wsRoot != null && File(wsRoot, id).isDirectory
            out.put(
                JSONObject()
                    .put("id", id)
                    .put("title", obj.optString("title"))
                    .put("mode", obj.optString("mode", "chat"))
                    .put("messageCount", obj.optJSONArray("messages")?.length() ?: 0)
                    // 是否真的有工作区目录（4.7 导入时按它决定要不要建目录）
                    .put("hasWorkspace", hasWorkspace)
            )
        }
        return out
    }

    /**
     * 值编码：保留原始类型，避免 4.7 导入时「int 变 String」这类静默降级。
     * 支持 SharedPreferences 的全部类型：String / Int / Long / Float / Boolean / Set<String>。
     */
    private fun encodeValue(v: Any?): JSONObject = when (v) {
        null -> JSONObject().put("t", "null")
        is String -> JSONObject().put("t", "s").put("v", v)
        is Int -> JSONObject().put("t", "i").put("v", v)
        is Long -> JSONObject().put("t", "l").put("v", v)
        is Float -> JSONObject().put("t", "f").put("v", v.toDouble())
        is Boolean -> JSONObject().put("t", "b").put("v", v)
        is Set<*> -> JSONObject().put("t", "ss").put("v", JSONArray(v.map { it?.toString() ?: "" }))
        else -> JSONObject().put("t", "s").put("v", v.toString())
    }

    private fun buildManifest(
        context: Context,
        sessions: JSONArray,
        workspaceDirs: List<File>,
    ): JSONObject {
        val pkg = context.packageName
        val pm = context.packageManager
        val vCode = runCatching {
            pm.getPackageInfo(pkg, 0).let {
                if (Build.VERSION.SDK_INT >= 28) it.longVersionCode else @Suppress("DEPRECATION") it.versionCode.toLong()
            }
        }.getOrDefault(0L)
        val vName = runCatching { pm.getPackageInfo(pkg, 0).versionName }.getOrNull() ?: ""

        return JSONObject()
            .put("schemaVersion", SCHEMA_VERSION)
            .put("kind", "workspace-migration")
            .put("appLabel", "Workspace")
            .put("fromPackage", pkg)
            .put("fromVersionCode", vCode)
            .put("fromVersionName", vName)
            .put("exportedAt", System.currentTimeMillis())
            .put("exportedAtText", java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date()))
            .put("androidVersion", Build.VERSION.RELEASE)
            .put("deviceModel", "${Build.MANUFACTURER} ${Build.MODEL}")
            .put("includedPrefs", JSONArray(EXPORTED_PREFS))
            .put("includedFileDirs", JSONArray(EXPORTED_FILE_DIRS))
            .put("excludedNote", "沙箱系统镜像与全部工具链（Java/Python/Go/Node/NDK/Kotlin/视频/逆向）不打包，4.7 首启自动重装")
            .put("sessions", sessions)
            .put("workspaceDirCount", workspaceDirs.size)
            // 4.7 导入后要用它重写 session_workspace_<id> 的绝对路径
            .put("workspaceDirName", "workspaces")
    }

    // ================= 打包工具 =================

    private fun putEntry(zos: ZipOutputStream, name: String, data: ByteArray) {
        val e = ZipEntry(name)
        e.time = System.currentTimeMillis()
        zos.putNextEntry(e)
        zos.write(data)
        zos.closeEntry()
    }

    /**
     * 递归把一个目录塞进 zip，返回写入的原始字节数。
     *
     * ⚠ 逐文件流式读写，绝不整目录 readBytes() —— 工作区里有单个大文件，
     * 也有几十万个小文件（Gradle 缓存），必须扛得住。
     * ⚠ 符号链接按普通文件处理（isFile 为 true 才读），避免循环。
     */
    private fun zipTree(
        zos: ZipOutputStream,
        base: File,
        entryPrefix: String,
        buf: ByteArray,
        onBytes: (Long) -> Unit,
    ): Long {
        var total = 0L
        if (!base.exists()) return 0L
        if (base.isFile) {
            val name = "$entryPrefix/${base.name}"
            val e = ZipEntry(name)
            e.time = base.lastModified().takeIf { it > 0 } ?: System.currentTimeMillis()
            zos.putNextEntry(e)
            base.inputStream().use { input -> total += pump(input, zos, buf, onBytes) }
            zos.closeEntry()
            return total
        }
        val children = base.listFiles() ?: return 0L
        // 空目录也要留一个条目，导入时才知道它的存在
        if (children.isEmpty()) {
            putEntry(zos, "$entryPrefix/", ByteArray(0))
            return 0L
        }
        for (child in children) {
            if (child.isDirectory) {
                total += zipTree(zos, child, "$entryPrefix/${child.name}", buf, onBytes)
            } else if (child.isFile) {
                val entryName = "$entryPrefix/${child.name}"
                val e = ZipEntry(entryName)
                e.time = child.lastModified().takeIf { it > 0 } ?: System.currentTimeMillis()
                // ⚠ 单个文件读不出来（权限/导出中途被删）不该让整包失败：
                // 失败就跳过该条目，继续下一个。
                // 注意 openEntry 标志：只有 putNextEntry 成功过才 closeEntry，
                // 否则会对一个未打开的条目 close，抛出新的异常把循环打断。
                var opened = false
                runCatching {
                    zos.putNextEntry(e)
                    opened = true
                    child.inputStream().use { input -> total += pump(input, zos, buf, onBytes) }
                }.onFailure {
                    // 忽略该文件；zip 里最多留一个空条目，不影响其它内容
                }
                if (opened) runCatching { zos.closeEntry() }
            }
        }
        return total
    }

    private fun pump(input: InputStream, out: ZipOutputStream, buf: ByteArray, onBytes: (Long) -> Unit): Long {
        var n: Int
        var total = 0L
        while (input.read(buf).also { n = it } > 0) {
            out.write(buf, 0, n)
            total += n
            onBytes(n.toLong())
        }
        return total
    }

    /**
     * 递归复制目录树（文件夹导出模式用）。
     *
     * 与 [zipTree] 的目录遍历规则保持一致，这样两种模式产出的**相对路径完全相同**，
     * 4.7 的 importer 可以共用一套解析。
     *
     * ⚠ 单个文件复制失败只跳过它，不中断整个导出 —— 工作区里可能有
     * 被删除的临时文件、权限异常的 socket 之类。
     */
    private fun copyTree(src: File, dst: File, onBytes: (Long) -> Unit) {
        if (!src.exists()) return
        if (src.isFile) {
            dst.parentFile?.mkdirs()
            runCatching {
                src.inputStream().use { input ->
                    FileOutputStream(dst).use { output ->
                        var n: Int
                        while (input.read(TMP_BUF).also { n = it } > 0) {
                            output.write(TMP_BUF, 0, n)
                            onBytes(n.toLong())
                        }
                    }
                }
            }
            return
        }
        dst.mkdirs()
        val children = src.listFiles() ?: return
        for (child in children) {
            if (child.isDirectory) {
                copyTree(child, File(dst, child.name), onBytes)
            } else if (child.isFile) {
                val target = File(dst, child.name)
                target.parentFile?.mkdirs()
                runCatching {
                    child.inputStream().use { input ->
                        FileOutputStream(target).use { output ->
                            var n: Int
                            while (input.read(TMP_BUF).also { n = it } > 0) {
                                output.write(TMP_BUF, 0, n)
                                onBytes(n.toLong())
                            }
                        }
                    }
                }
            }
        }
    }

    private fun dirSize(dir: File): Long {
        if (!dir.exists()) return 0L
        if (dir.isFile) return dir.length()
        var sum = 0L
        dir.listFiles()?.forEach { sum += dirSize(it) }
        return sum
    }

    fun formatSize(bytes: Long): String = when {
        bytes >= 1_073_741_824 -> "%.2f GB".format(bytes / 1_073_741_824.0)
        bytes >= 1_048_576 -> "%.1f MB".format(bytes / 1_048_576.0)
        bytes >= 1024 -> "%.0f KB".format(bytes / 1024.0)
        else -> "$bytes B"
    }
}