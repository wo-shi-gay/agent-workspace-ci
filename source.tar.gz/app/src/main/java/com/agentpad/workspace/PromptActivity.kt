package com.agentpad.workspace

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agentpad.workspace.ai.PromptPreset
import com.agentpad.workspace.ai.PromptStore
import com.agentpad.workspace.ui.*

/**
 * 自定义提示词页（多方案版）。
 *
 * 只叠加、不替换：内置工具提示词原样保留，这里的内容会作为
 * <user_custom_instructions> 区块追加到系统提示词末尾。
 *
 * v5.3 起改成**方案列表**：
 *  - 可以建任意多个方案，各自独立开关，按展示顺序全部叠加；
 *  - **字数不再有上限**（旧版硬截断在 8000 字符）；
 *  - 全局方案对所有会话生效，会话方案只对当前会话生效。
 */
class PromptActivity : ComponentActivity() {

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        val sessionId = intent.getStringExtra("session_id").orEmpty().ifBlank { null }
        setContent {
            AgentTheme {
                Content(sessionId = sessionId)
            }
        }
    }

    /** 编辑中的草稿；id 为 null 表示新建。 */
    private data class Draft(
        val id: String?,
        val name: String,
        val content: String,
    )

    @Composable
    private fun Content(sessionId: String?) {
        // 当前管理的作用域：全局 或 本会话
        var scope by remember { mutableStateOf(PromptStore.SCOPE_GLOBAL) }
        var presets by remember { mutableStateOf(PromptStore.presets(this)) }
        var draft by remember { mutableStateOf<Draft?>(null) }

        fun reload() {
            presets = PromptStore.presets(this@PromptActivity)
        }

        val current = draft
        if (current != null) {
            EditorPage(
                draft = current,
                onDraftChange = { draft = it },
                onCancel = { draft = null },
                onSave = {
                    val name = current.name.trim().ifBlank { "未命名方案" }
                    if (current.content.isBlank()) {
                        Toast.makeText(this@PromptActivity, "内容为空，没保存喵", Toast.LENGTH_SHORT).show()
                    } else {
                        PromptStore.upsert(
                            this@PromptActivity,
                            PromptPreset(
                                id = current.id ?: PromptStore.newId(),
                                name = name,
                                content = current.content,
                                enabled = true,
                                scope = scope,
                            )
                        )
                        draft = null
                        reload()
                        Toast.makeText(this@PromptActivity, "已保存，下一次请求生效", Toast.LENGTH_SHORT).show()
                    }
                },
            )
            return
        }

        val shown = presets.filter { it.scope == scope }

        SubPage(
            title = "自定义提示词",
            subtitle = "多套方案 · 独立开关 · 字数无上限",
            onBack = { finish() },
            trailing = {
                Text(
                    "新建",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = AColors.Accent,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            draft = Draft(id = null, name = "", content = "")
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                )
            },
        ) {
            if (sessionId != null) {
                SectionLabel("作用范围")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ScopeChip("全局（所有会话）", scope == PromptStore.SCOPE_GLOBAL) {
                        scope = PromptStore.SCOPE_GLOBAL
                    }
                    ScopeChip("本会话", scope == sessionId) {
                        scope = sessionId
                    }
                }
            }

            SectionLabel(if (scope == PromptStore.SCOPE_GLOBAL) "全局方案" else "本会话方案")

            if (shown.isEmpty()) {
                AgentCard {
                    Text(
                        "还没有方案喵～点右上角「新建」写一条吧。",
                        fontSize = 13.sp, color = AColors.Muted, lineHeight = 19.sp,
                    )
                }
            } else {
                shown.forEachIndexed { index, p ->
                    AgentCard(modifier = Modifier.padding(bottom = ADimens.GapCard)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    p.name.ifBlank { "未命名方案" },
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = AColors.Ink,
                                )
                                Text(
                                    "${p.content.length} 字" + if (p.enabled) " · 已启用" else " · 已停用",
                                    fontSize = 11.sp, color = AColors.Faint,
                                    modifier = Modifier.padding(top = 3.dp),
                                )
                            }
                            Switch(
                                checked = p.enabled,
                                onCheckedChange = { on ->
                                    PromptStore.setEnabled(this@PromptActivity, p.id, on)
                                    reload()
                                },
                            )
                        }
                        if (p.content.isNotBlank()) {
                            Text(
                                p.content.trim(),
                                fontSize = 12.sp,
                                color = AColors.Muted,
                                lineHeight = 18.sp,
                                maxLines = 3,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(top = 8.dp),
                            )
                        }
                        Divider(Modifier.padding(vertical = 10.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            MiniAction("编辑") {
                                draft = Draft(id = p.id, name = p.name, content = p.content)
                            }
                            MiniAction("上移", enabled = index > 0) {
                                PromptStore.move(this@PromptActivity, p.id, -1); reload()
                            }
                            MiniAction("下移", enabled = index < shown.lastIndex) {
                                PromptStore.move(this@PromptActivity, p.id, +1); reload()
                            }
                            MiniAction("删除", danger = true) {
                                PromptStore.delete(this@PromptActivity, p.id)
                                reload()
                            }
                        }
                    }
                }
            }

            if (scope != PromptStore.SCOPE_GLOBAL) {
                Spacer(Modifier.height(12.dp))
                SecondaryButton("清空本会话全部方案") {
                    PromptStore.clearSessionPrompt(this@PromptActivity, scope)
                    reload()
                    Toast.makeText(this@PromptActivity, "已清空本会话方案", Toast.LENGTH_SHORT).show()
                }
            }

            Spacer(Modifier.height(20.dp))
            SectionLabel("说明")
            AgentCard {
                Column {
                    listOf(
                        "叠加位置：系统提示词末尾的 <user_custom_instructions> 区块。",
                        "同时启用多条方案时，按列表顺序全部拼接送出。",
                        "全局排在前，会话排在后；留空或停用即不生效，不消耗上下文。",
                        "字数没有上限，可以放长文档、完整编码规范、角色设定。",
                        "每次修改在下一次发送消息时生效。",
                    ).forEach {
                        Text(
                            "· $it", fontSize = 12.sp, color = AColors.Muted,
                            lineHeight = 18.sp, modifier = Modifier.padding(bottom = 4.dp),
                        )
                    }
                }
            }
        }
    }

    @Composable
    private fun EditorPage(
        draft: Draft,
        onDraftChange: (Draft) -> Unit,
        onCancel: () -> Unit,
        onSave: () -> Unit,
    ) {
        SubPage(
            title = if (draft.id == null) "新建方案" else "编辑方案",
            subtitle = "内容长度不限，想写多长写多长",
            onBack = onCancel,
        ) {
            SectionLabel("方案名称")
            AgentCard {
                AgentTextField(
                    value = draft.name,
                    onValueChange = { onDraftChange(draft.copy(name = it)) },
                    placeholder = "例如：代码风格 / 猫娘人设 / 这个项目的约定",
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            Spacer(Modifier.height(14.dp))
            SectionLabel("提示词内容")
            AgentCard {
                AgentTextField(
                    value = draft.content,
                    onValueChange = { onDraftChange(draft.copy(content = it)) },
                    placeholder = "想怎么约束 AI 就怎么写……",
                    singleLine = false,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 280.dp)
                        .heightIn(max = 1600.dp),
                )
                Text(
                    "${draft.content.length} 字 · 无上限",
                    fontSize = 11.sp, color = AColors.Faint,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }

            Spacer(Modifier.height(18.dp))
            PrimaryButton("保存方案", Modifier.fillMaxWidth(), onClick = onSave)
            Spacer(Modifier.height(10.dp))
            SecondaryButton("取消", Modifier.fillMaxWidth(), onClick = onCancel)
            Spacer(Modifier.height(20.dp))
        }
    }

    @Composable
    private fun ScopeChip(label: String, selected: Boolean, onClick: () -> Unit) {
        Box(
            Modifier
                .clip(RoundedCornerShape(ADimens.ChipRadius))
                .background(if (selected) AColors.Accent else AColors.SurfaceAlt)
                .clickable(onClick = onClick)
                .padding(horizontal = 14.dp, vertical = 9.dp),
        ) {
            Text(
                label,
                fontSize = 13.sp,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                color = if (selected) Color.White else AColors.InkSoft,
            )
        }
    }

    @Composable
    private fun MiniAction(
        text: String,
        enabled: Boolean = true,
        danger: Boolean = false,
        onClick: () -> Unit,
    ) {
        val tint = when {
            !enabled -> AColors.Faint
            danger -> AColors.Danger
            else -> AColors.InkSoft
        }
        Text(
            text,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = tint,
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable(enabled = enabled, onClick = onClick)
                .padding(horizontal = 6.dp, vertical = 4.dp),
        )
    }
}