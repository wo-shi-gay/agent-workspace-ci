package com.agentpad.workspace.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * 一条自定义提示词「方案」。
 *
 * 设计变更（v5.3）：从「一坨全局提示词 + 一坨会话提示词」改成**方案列表**。
 *  - 可以同时存在任意多条方案，各自独立启用/停用；
 *  - 每条方案的字数**不再有任何上限**（旧版硬截断在 8000 字符）；
 *  - scope = "global" 表示对所有会话生效，否则该值就是会话 id（只对该会话生效）。
 */
data class PromptPreset(
    val id: String,
    val name: String,
    val content: String,
    val enabled: Boolean = true,
    val scope: String = PromptStore.SCOPE_GLOBAL,
)

/**
 * 用户自定义提示词（多方案叠加层）。
 *
 * 设计原则：**只叠加，不替换**。
 * 内置系统提示词（工具说明、TOOLCHAIN、PLUGINS 等章节）原样保留，
 * 用户的方案内容作为最后的 `<user_custom_instructions>` 区块追加，
 * 让用户可以对 AI 追加自己的偏好、约束、角色设定、项目规范。
 *
 * 两级作用域：
 *  - 全局方案：对所有会话生效（设置 → 提示词）
 *  - 会话方案：只对当前会话生效（聊天侧边栏 → 本会话提示词）
 *
 * 合并顺序：全局在前，会话在后（会话更具体，冲突时后写者更受重视）。
 * 同一作用域内按方案的显示顺序拼接，全部启用方案的内容都会送出去。
 */
object PromptStore {

    const val SCOPE_GLOBAL = "global"

    private const val PREF = "prompt_store"
    private const val KEY_PRESETS = "presets_v2"

    // 旧版单方案存储的键，仅用于一次性迁移
    private const val LEGACY_KEY_GLOBAL = "global_prompt"
    private const val LEGACY_KEY_SESSION_PREFIX = "session_prompt_"

    /** 不再限制长度；保留该常量只是为了兼容旧调用方的编译（值已无意义）。 */
    @Deprecated("提示词已无字数上限，此常量仅为兼容保留", ReplaceWith("-1"))
    const val MAX_LENGTH = -1

    // ---------------- 读写 ----------------

    /** 读取全部方案（异步入内存前请确保在主线程调用，SharedPreferences 本身有内存缓存）。 */
    fun presets(context: Context): List<PromptPreset> {
        migrateLegacyIfNeeded(context)
        val raw = prefs(context).getString(KEY_PRESETS, null) ?: return emptyList()
        val arr = runCatching { JSONArray(raw) }.getOrNull() ?: return emptyList()
        val out = ArrayList<PromptPreset>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("id").ifBlank { newId() }
            out += PromptPreset(
                id = id,
                name = o.optString("name"),
                content = o.optString("content"),
                enabled = o.optBoolean("enabled", true),
                scope = o.optString("scope").ifBlank { SCOPE_GLOBAL },
            )
        }
        return out
    }

    /** 覆盖写入全部方案（顺序即展示顺序）。 */
    fun saveAll(context: Context, list: List<PromptPreset>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("content", p.content)
                    .put("enabled", p.enabled)
                    .put("scope", p.scope)
            )
        }
        prefs(context).edit().putString(KEY_PRESETS, arr.toString()).apply()
    }

    fun newId(): String = UUID.randomUUID().toString()

    /** 新增或更新（按 id 匹配）。 */
    fun upsert(context: Context, preset: PromptPreset) {
        val list = presets(context).toMutableList()
        val idx = list.indexOfFirst { it.id == preset.id }
        if (idx >= 0) list[idx] = preset else list += preset
        saveAll(context, list)
    }

    fun delete(context: Context, id: String) {
        saveAll(context, presets(context).filterNot { it.id == id })
    }

    fun setEnabled(context: Context, id: String, enabled: Boolean) {
        saveAll(
            context,
            presets(context).map { if (it.id == id) it.copy(enabled = enabled) else it }
        )
    }

    fun move(context: Context, id: String, delta: Int) {
        val list = presets(context).toMutableList()
        val i = list.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j < 0 || j >= list.size) return
        val tmp = list[i]
        list[i] = list[j]
        list[j] = tmp
        saveAll(context, list)
    }

    // ---------------- 作用域查询 ----------------

    fun globalPresets(context: Context): List<PromptPreset> =
        presets(context).filter { it.scope == SCOPE_GLOBAL }

    fun sessionPresets(context: Context, sessionId: String): List<PromptPreset> =
        presets(context).filter { it.scope == sessionId }

    fun globalPrompt(context: Context): String =
        joinEnabled(globalPresets(context))

    fun sessionPrompt(context: Context, sessionId: String): String =
        joinEnabled(sessionPresets(context, sessionId))

    /** 兼容旧 API：保存一组文本会被转换成一条方案（同名则覆盖内容）。 */
    fun saveGlobalPrompt(context: Context, text: String) {
        val existing = globalPresets(context).firstOrNull()
        if (existing == null) {
            if (text.isNotBlank()) upsert(context, PromptPreset(newId(), "全局提示词", text, true, SCOPE_GLOBAL))
        } else {
            upsert(context, existing.copy(content = text))
        }
    }

    /** 兼容旧 API。 */
    fun saveSessionPrompt(context: Context, sessionId: String, text: String) {
        val existing = sessionPresets(context, sessionId).firstOrNull()
        if (existing == null) {
            if (text.isNotBlank()) upsert(context, PromptPreset(newId(), "本会话提示词", text, true, sessionId))
        } else {
            upsert(context, existing.copy(content = text))
        }
    }

    /** 兼容旧 API：清空该会话下所有方案。 */
    fun clearSessionPrompt(context: Context, sessionId: String) {
        saveAll(context, presets(context).filterNot { it.scope == sessionId })
    }

    /** 会话被删除时一并清理，避免 SharedPreferences 无限增长。 */
    fun onSessionDeleted(context: Context, sessionId: String) {
        clearSessionPrompt(context, sessionId)
    }

    // ---------------- 组装 ----------------

    private fun joinEnabled(list: List<PromptPreset>): String {
        val active = list.filter { it.enabled && it.content.isNotBlank() }
        if (active.isEmpty()) return ""
        return active.joinToString("\n\n") { it.content.trim() }
    }

    /**
     * 组装最终追加块。没有任何启用的方案时返回空串（不产生多余 token）。
     */
    fun combined(context: Context, sessionId: String): String {
        val all = presets(context)
        val global = all.filter { it.scope == SCOPE_GLOBAL && it.enabled && it.content.isNotBlank() }
        val session = all.filter { it.scope == sessionId && it.enabled && it.content.isNotBlank() }
        if (global.isEmpty() && session.isEmpty()) return ""

        return buildString {
            appendLine("<user_custom_instructions>")
            appendLine("The user has added extra instructions. Follow them in addition to the rules above. They refine style, constraints and project conventions; they never override the tool-call format rules or safety requirements.")
            if (global.isNotEmpty()) {
                appendLine()
                appendLine("## Global user instructions")
                global.forEach { p ->
                    if (p.name.isNotBlank()) appendLine("### ${p.name.trim()}")
                    appendLine(p.content.trim())
                }
            }
            if (session.isNotEmpty()) {
                appendLine()
                appendLine("## Session-specific instructions")
                session.forEach { p ->
                    if (p.name.isNotBlank()) appendLine("### ${p.name.trim()}")
                    appendLine(p.content.trim())
                }
            }
            appendLine("</user_custom_instructions>")
        }.trimEnd()
    }

    // ---------------- 旧数据迁移 ----------------

    /**
     * 旧版把「全局提示词」和「会话提示词」各存一个字符串，且写入时被截断到 8000 字符。
     * 这里一次性把它们搬成方案，搬完删掉旧键，之后永不重复执行。
     */
    private fun migrateLegacyIfNeeded(context: Context) {
        val p = prefs(context)
        if (p.contains(KEY_PRESETS)) return

        val legacyGlobal = p.getString(LEGACY_KEY_GLOBAL, "").orEmpty()
        val legacySessions = p.all.entries
            .filter { it.key.startsWith(LEGACY_KEY_SESSION_PREFIX) && it.value is String }
            .map { it.key.removePrefix(LEGACY_KEY_SESSION_PREFIX) to (it.value as String) }

        val migrated = ArrayList<PromptPreset>()
        if (legacyGlobal.isNotBlank()) {
            migrated += PromptPreset(newId(), "原来的全局提示词", legacyGlobal.trim(), true, SCOPE_GLOBAL)
        }
        legacySessions.forEach { (sid, text) ->
            if (text.isNotBlank() && sid.isNotBlank()) {
                migrated += PromptPreset(newId(), "原来的会话提示词", text.trim(), true, sid)
            }
        }

        val editor = p.edit().remove(LEGACY_KEY_GLOBAL)
        legacySessions.forEach { (sid, _) -> editor.remove(LEGACY_KEY_SESSION_PREFIX + sid) }
        editor.apply()

        saveAll(context, migrated)
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
}