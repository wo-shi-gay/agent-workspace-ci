package com.agentpad.workspace.ai

/** Tiny JNI PTY bridge; no third-party terminal dependency. */
object PtyBridge {
    init { System.loadLibrary("agentpad_pty") }
    @JvmStatic external fun open(rows: Int, cols: Int): Int
    @JvmStatic external fun read(fd: Int, out: ByteArray): Int
    @JvmStatic external fun write(fd: Int, data: ByteArray): Int
    @JvmStatic external fun resize(fd: Int, rows: Int, cols: Int): Int
    @JvmStatic external fun interrupt(fd: Int): Int
    @JvmStatic external fun close(fd: Int)
}