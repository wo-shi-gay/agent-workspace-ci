package com.agentpad.workspace.ai

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream

object SandboxInstaller {
    // 沙箱系统镜像：Debian ARM64 slim（debuerreotype 官方构建）。
    // 主源走 gh-proxy；备用源走小飞机网盘（部分网络 gh-proxy 不通时回退）。
    private const val DEBIAN_SLIM_PROXY =
        "https://gh-proxy.com/https://raw.githubusercontent.com/debuerreotype/docker-debian-artifacts/dist-arm64v8/stable/slim/oci/blobs/rootfs.tar.gz"
    /** 小飞机网盘备用源（用户分享的 Debian ARM64 rootfs 镜像）。 */
    private const val DEBIAN_SLIM_FEIJI =
        "https://share.feijipan.com/s/VQw8M1V9"
    private val DISTRO_SOURCES = listOf(DEBIAN_SLIM_PROXY, DEBIAN_SLIM_FEIJI)

    /** 可选下载源：id / 显示名 / 描述 / 地址。 */
    data class DistroSource(val id: String, val label: String, val desc: String, val url: String)

    val SOURCES = listOf(
        DistroSource("auto", "自动（推荐）", "先试 gh-proxy，失败自动切换小飞机网盘", ""),
        DistroSource("ghproxy", "GitHub 加速（gh-proxy）", "海外/直连较快的网络", DEBIAN_SLIM_PROXY),
        DistroSource("feiji", "小飞机网盘", "国内网络更稳定，自动解析直链", DEBIAN_SLIM_FEIJI),
    )

    private const val PREF = "sandbox_prefs"
    private const val KEY_SOURCE = "distro_source"

    fun selectedSourceId(context: Context): String =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_SOURCE, "auto") ?: "auto"

    fun selectSource(context: Context, id: String) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY_SOURCE, id).apply()
    }

    /** 根据偏好返回实际尝试顺序。auto = 全部；指定则只试该源。 */
    private fun sourcesFor(context: Context): List<String> {
        return when (selectedSourceId(context)) {
            "ghproxy" -> listOf(DEBIAN_SLIM_PROXY)
            "feiji" -> listOf(DEBIAN_SLIM_FEIJI)
            else -> DISTRO_SOURCES
        }
    }

    /** Prebuilt CPython 3.12 (python-build-standalone, aarch64 glibc, stripped:
     *  no bundled pip — `python3 -m ensurepip` can materialize it on demand).
     *  实测 gh-proxy 通道 ~830KB/s、29MB 下载 + 7s 解压 < 40s 总耗时。 */
    private const val PYTHON_BUNDLE =
        "https://gh-proxy.com/https://github.com/astral-sh/python-build-standalone/releases/download/20260901/cpython-3.12.14+20260901-aarch64-unknown-linux-gnu-install_only_stripped.tar.gz"

    /** PREFIX: writable private dir passed into init-sandbox.sh. */
    fun sandboxDir(context: Context): File = File(context.filesDir, "sandbox")
    /** NATIVE_LIB_DIR == app's system-managed native library dir. The .so payloads
     *  ship as real app native libs under jniLibs, so Android places them in
     *  nativeLibraryDir where exec / mmap PROT_EXEC is permitted (files/ is
     *  often not). We never copy proot itself into files/. */
    fun nativeDir(context: Context): File = File(context.applicationInfo.nativeLibraryDir)
    /** ROOTFS_DIR: extracted Debian base rootfs. */
    fun rootfsDir(context: Context): File = File(sandboxDir(context), "rootfs")
    /** WRITABLE dir where init-sandbox.sh is staged (scripts only need to be
     *  readable, and files/ is writable; the proot binaries exec out of the
     *  system native dir, NOT from here). */
    fun initScript(context: Context): File = File(sandboxDir(context), "init-sandbox.sh")
    /** App-private external dir on /sdcard (FUSE always allows the owning app,
     *  no storage permission required, visible in the file manager). */
    fun externalDir(context: Context): File =
        context.getExternalFilesDir(null) ?: File(context.filesDir, "external")

    /** PROJECT_DIR bound to /workspace inside the container. */
    fun projectDir(context: Context): File = File(context.getExternalFilesDir(null) ?: context.filesDir, "workspaces/current")

    enum class SandboxStatus { READY, NEEDS_DOWNLOAD, REPAIR_NEEDED }

    /** Callbacks surface work during a (possibly slow) first-time setup. */
    interface Progress {
        fun onMessage(text: String)
        fun onProgress(percent: Int)   // 0..100
    }

    /** True once rootfs is present and its real shell is actually executable.
     *  Old builds used to extract files without the exec bit (and skipped
     *  symlinks), so we verify a real binary (usr/bin/dash, not the sh
     *  symlink) can execute — otherwise the sandbox is repaired. */
    fun isHealthy(context: Context): Boolean {
        val root = rootfsDir(context)
        if (File(root, ".installed-v2").isFile.not()) return false
        if (File(nativeDir(context), "libproot-xed.so").isFile.not()) return false
        // Package tooling must exist too: a rootfs with a working shell but a
        // broken/missing dpkg silently breaks every later apt install (seen
        // in the field: python3-minimal configure failed, '/usr/bin/dpkg' not
        // found). Treat that as REPAIR_NEEDED so the rootfs is re-extracted.
        if (File(root, "usr/bin/dpkg").isFile.not() || File(root, "usr/bin/apt-get").isFile.not()) return false
        return probeExecutable(File(root, "usr/bin/dash")) ||
            probeExecutable(File(root, "usr/bin/bash")) ||
            probeExecutable(File(root, "bin/busybox"))
    }

    private fun probeExecutable(file: File): Boolean {
        if (!file.isFile) return false
        val r = runCatching { file.canExecute() }.getOrDefault(false)
        return r
    }

    /** Lightweight health scan used before deciding to show a boot gate. */
    fun status(context: Context): SandboxStatus {
        if (isHealthy(context)) return SandboxStatus.READY
        val root = rootfsDir(context)
        val native = nativeDir(context)
        if (File(native, "libproot-xed.so").isFile) {
            // 原写法 root.list() 连调两次：既多一次系统调用，又存在 TOCTOU ——
            // 两次调用之间目录被删会拿到 null 再 !! 崩。取一次再判。
            val entries = if (root.isDirectory) root.list() else null
            return if (!entries.isNullOrEmpty()) SandboxStatus.REPAIR_NEEDED else SandboxStatus.NEEDS_DOWNLOAD
        }
        return SandboxStatus.NEEDS_DOWNLOAD
    }

    @Synchronized
    fun ensureInstalled(context: Context, progress: Progress? = null) {
        progress?.onMessage("准备环境目录")
        val base = sandboxDir(context)
        base.mkdirs()
        rootfsDir(context).mkdirs()
        // Staged launcher script (must be under files/, writable; proot binaries
        // are not copied — they come from the jniLibs-backed nativeLibraryDir).
        copyAsset(context, "sandbox/init-sandbox.sh", initScript(context), true)
        ensureRootfs(context, base, progress)
        ensurePythonRuntime(context, progress)
    }

    /**
     * 「设置 → 下载环境」的**系统镜像补装入口**。
     *
     * 为什么需要：首次启动时 [ensureInstalled] 是在 BootActivity 里被
     * runCatching 包着调的 —— 断网/镜像站不可达就直接放行进主页。用户之后
     * 想补装，界面上却没有对应卡片，只能干瞪眼。这里把 [ensureRootfs]
     * 原样暴露出来，供卡片复用（不复制任何下载/解压逻辑）。
     */
    @Synchronized
    fun reinstallRootfs(context: Context, progress: Progress? = null) {
        val base = sandboxDir(context)
        base.mkdirs()
        rootfsDir(context).mkdirs()
        copyAsset(context, "sandbox/init-sandbox.sh", initScript(context), true)
        ensureRootfs(context, base, progress)
    }

    /**
     * 「设置 → 下载环境」的 **Python 运行时补装入口**。
     *
     * 同上的理由：断网时 Python 会被静默跳过，用户没有补装入口。
     * 这里原样复用 [ensurePythonRuntime]（直链 python-build-standalone →
     * 失败回退 apt TUNA 源两条通道都保留）。
     */
    @Synchronized
    fun reinstallPython(context: Context, progress: Progress? = null) {
        sandboxDir(context).mkdirs()
        rootfsDir(context).mkdirs()
        copyAsset(context, "sandbox/init-sandbox.sh", initScript(context), true)
        ensurePythonRuntime(context, progress)
    }

    /** Debian trixie apt sources pointed at TUNA over plain HTTP. slim rootfs
     *  has no ca-certificates, so https mirrors would fail; http works and is
     *  still ~10x faster than deb.debian.org direct on mainland networks
     *  (实测官方源直连 ~100KB/s). */
    private const val DEBIAN_CN_SOURCES = """
Types: deb
URIs: http://mirrors.tuna.tsinghua.edu.cn/debian
Suites: stable stable-updates
Components: main
Signed-By: /usr/share/keyrings/debian-archive-keyring.pgp

Types: deb
URIs: http://mirrors.tuna.tsinghua.edu.cn/debian-security
Suites: stable-security
Components: main
Signed-By: /usr/share/keyrings/debian-archive-keyring.pgp
"""

    /** Bootstrap python3 into the SHARED rootfs on first boot. Channel 1 (fast):
     *  prebuilt python-build-standalone tarball via gh-proxy, extracted to
     *  usr/local/python3 (its bin is on PATH via init-sandbox.sh). Channel 2
     *  (fallback): apt from TUNA Debian mirror. Skipped if python3 exists. */
    private fun ensurePythonRuntime(context: Context, progress: Progress?) {
        val root = rootfsDir(context)
        if (File(root, "usr/bin/python3").isFile) return
        val target = File(root, "usr/local/python3")
        if (File(target, "python/bin/python3").isFile) {
            // Earlier direct-channel install: link bin into place and done.
            linkPythonIntoUsrBin(root, target)
            return
        }
        val channelErrors = mutableListOf<String>()
        progress?.onMessage("下载 Python 运行时（约 29MB）")
        // Channel 1: prebuilt tarball with download progress.
        runCatching {
            val archive = File(sandboxDir(context), "python-bundle.tar.gz")
            downloadFile(PYTHON_BUNDLE, archive, progress)
            progress?.onMessage("正在解压 Python 运行时")
            target.mkdirs()
            extractPythonBundle(archive, target, progress)
            archive.delete()
            // The tarball's top-level dir is `python/` -> target/python/bin/python3.
            val realBin = File(target, "python/bin/python3")
            if (!realBin.isFile) throw IllegalStateException("解压布局异常：未找到 python/bin/python3")
            realBin.setExecutable(true, false)
            linkPythonIntoUsrBin(root, target)
            File(target, ".installed").writeText("python3 direct install")
            progress?.onMessage("Python 运行时就绪")
            return
        }.onFailure { error ->
            channelErrors += "直链: ${error.message}"
            progress?.onMessage("直链安装失败，改用 apt…")
        }
        // Channel 2: apt fallback over TUNA http mirror.
        runCatching {
            val sources = File(root, "etc/apt/sources.list.d/debian.sources")
            if (sources.isFile) sources.writeText(DEBIAN_CN_SOURCES.trim() + "\n")
            val (exit, tail) = runInSandbox(
                context,
                "export DEBIAN_FRONTEND=noninteractive; apt-get update -qq && apt-get install -y --no-install-recommends python3"
            )
            if (exit != 0 || File(root, "usr/bin/python3").isFile.not()) {
                throw IllegalStateException("apt exit=$exit: ${tail.takeLast(300).replace(Regex("\u001B\\[[0-9;]*m"), "").trim()}")
            }
            progress?.onMessage("Python 运行时就绪（apt）")
        }.onFailure { error ->
            channelErrors += "apt: ${error.message}"
            progress?.onMessage("Python 安装失败。${channelErrors.joinToString("；")}（可稍后在沙箱内手动重试）")
        }
    }

    /** Expose the direct-channel python on the standard PATH for every
     *  sandbox session (usr/bin symlinks into the bundle layout). */
    private fun linkPythonIntoUsrBin(root: File, target: File) {
        runCatching {
            val bin = File(root, "usr/bin")
            bin.mkdirs()
            listOf("python3", "python3.12", "pip3").forEach { name ->
                val link = File(bin, name)
                if (!link.exists()) {
                    java.nio.file.Files.createSymbolicLink(
                        link.toPath(),
                        java.nio.file.Path.of("/usr/local/python3/python/bin/$name")
                    )
                }
            }
        }
    }

    /** Run a command inside the proot sandbox using the exact same launch
     *  layout as SandboxRunner (via init-sandbox.sh). Returns exit code and
     *  the tail of combined output (for error reporting). */
    private fun runInSandbox(context: Context, command: String): Pair<Int, String> {
        val process = ProcessBuilder(
            listOf(
                "/system/bin/sh",
                initScript(context).absolutePath,
                sandboxDir(context).absolutePath,
                rootfsDir(context).absolutePath,
                nativeDir(context).absolutePath,
                projectDir(context).absolutePath,
                "sh", "-c", command
            )
        ).directory(sandboxDir(context)).redirectErrorStream(true).start()
        val output = StringBuilder()
        val reader = Thread {
            try { process.inputStream.bufferedReader().useLines { it.forEach { line -> output.appendLine(line) } } }
            catch (_: Exception) { }
        }
        reader.start()
        val exit = process.waitFor()
        reader.join(1_000)
        return exit to output.toString()
    }

    private fun ensureRootfs(context: Context, base: File, progress: Progress?) {
        val root = rootfsDir(context)
        if (isHealthy(context)) { progress?.onProgress(100); progress?.onMessage("沙箱已就绪"); return }
        progress?.onMessage("沙箱缺失或损坏，正在安装系统镜像")
        root.deleteRecursively()
        root.mkdirs()
        val archive = File(base, "debian-rootfs-arm64.tar.gz")
        archive.delete()
        downloadWithFallback(context, archive, progress)
        progress?.onMessage("正在解压系统镜像")
        progress?.onProgress(8)
        extractTarGz(archive, root, progress)
        archive.delete()
        File(root, ".installed-v2").writeText("rootfs installed v2")
        progress?.onProgress(100)
        progress?.onMessage("环境就绪")
    }

    private fun downloadWithFallback(context: Context, target: File, progress: Progress?) {
        var lastError: Exception? = null
        var index = 0
        val sources = sourcesFor(context)
        for (source in sources) {
            index++
            try {
                if (source.contains("feijipan.com/s/")) {
                    progress?.onMessage("正在从小飞机网盘解析系统镜像")
                    val resolved = org.json.JSONObject(FeijipanParser.resolve(source))
                    val directUrl = resolved.getString("url")
                    progress?.onMessage("正在从小飞机网盘下载 Debian 系统镜像")
                    downloadFile(directUrl, target, progress, referer = "https://www.feijipan.com/")
                } else {
                    progress?.onMessage(if (index == 1 && sources.size == 1) "正在下载 Debian 12 (arm64) 系统镜像" else "正在从 GitHub 加速源下载")
                    downloadFile(source, target, progress)
                }
                if (target.isFile && target.length() > 10_000_000) return
                lastError = IllegalStateException("unexpected small download")
                target.delete()
            } catch (error: Exception) {
                lastError = error
                target.delete()
            }
        }
        throw IllegalStateException("failed to download Debian rootfs: ${lastError?.message}")
    }

    private fun downloadFile(urlString: String, target: File, progress: Progress?, referer: String? = null) {
        target.parentFile?.mkdirs()
        val connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
            connectTimeout = 25_000
            readTimeout = 300_000
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android)")
            referer?.let { setRequestProperty("Referer", it) }
            instanceFollowRedirects = true
        }
        try {
            connection.connect()
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code for $urlString")
            val total = connection.contentLengthLong
            connection.inputStream.use { input ->
                BufferedOutputStream(FileOutputStream(target)).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var readCount: Int
                    var transferred = 0L
                    var lastPct = -1
                    while (input.read(buffer).also { readCount = it } != -1) {
                        output.write(buffer, 0, readCount)
                        transferred += readCount
                        if (total > 0) {
                            val pct = (8 + (transferred * 90 / total)).toInt().coerceIn(8, 98)
                            if (pct != lastPct) { lastPct = pct; progress?.onProgress(pct) }
                        }
                    }
                }
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun copyAsset(context: Context, assetPath: String, target: File, executable: Boolean) {
        if (target.exists() && target.length() > 0) return
        target.parentFile?.mkdirs()
        context.assets.open(assetPath).use { input -> FileOutputStream(target).use { output -> input.copyTo(output) } }
        target.setReadable(true, false)
        if (executable) {
            target.setExecutable(true, false)
            // Hard chmod fallback: Java setExecutable sometimes does not persist
            // as a real exec bit on all filesystems. Force 0755 via the system
            // shell so ProcessBuilder can exec it (and SELinux sees exec).
            target.setWritable(true, false)
            try {
                val sh = ProcessBuilder("/system/bin/sh", "-c", "chmod 755 '${target.absolutePath}'").redirectErrorStream(true).start()
                sh.waitFor(5, TimeUnit.SECONDS)
            } catch (_: Exception) {
                // ignore; Java mode bits above usually suffice on app private dirs
            }
        }
    }

    private fun extractTarGz(archive: File, destination: File, progress: Progress?) {
        val totalSize = archive.length()
        var written = 0L
        var lastPct = -1
        GZIPInputStream(BufferedInputStream(archive.inputStream())).use { input ->
            val header = ByteArray(512)
            while (true) {
                readFully(input, header) ?: break
                if (header.all { it == 0.toByte() }) break
                val name = header.copyOfRange(0, 100).decodeToString().trimEnd('\u0000')
                val prefix = header.copyOfRange(345, 500).decodeToString().trimEnd('\u0000')
                val relative = if (prefix.isBlank()) name else "$prefix/$name"
                val size = parseOctal(header, 124, 12)
                val mode = parseOctal(header, 100, 8) // tar file mode, e.g. 0o100755
                val type = header[156].toInt().toChar()
                val linkName = header.copyOfRange(157, 257).decodeToString().trimEnd('\u0000')
                // normalize() (string-level) instead of canonicalFile(): the
                // canonical form resolves symlinks via the FS and throws
                // "Invalid file path" on some devices for the deep
                // rootfs/usr/local/python3/... paths. String normalization is
                // enough for the traversal check below.
                val target = File(destination, relative).normalize()
                require(target.path == destination.path || target.path.startsWith(destination.path + File.separator)) { "invalid archive path" }
                when (type) {
                    '5' -> target.mkdirs()
                    '2' -> { // symbolic link (Debian ships /bin/sh, /usr/bin/sh etc.)
                        // parentFile 为 null 时旧写法 `?.exists()!!` 直接 NPE。改成安全调用。
                        val parent = target.parentFile
                        if (parent != null && !parent.exists()) parent.mkdirs()
                        try { if (target.exists()) target.delete(); java.nio.file.Files.createSymbolicLink(target.toPath(), java.nio.file.Paths.get(linkName)) } catch (_: Exception) { /* some devices disallow symlinks */ }
                    }
                    '0', '\u0000' -> {
                        target.parentFile?.mkdirs()
                        FileOutputStream(target).use { output ->
                            val count = copyExactly(input, output, size)
                            written += count
                        }
                        target.setReadable(true, false)
                        // user execute bit (0o100 octal) == 0x40
                        if ((mode and 0x40L) != 0L) target.setExecutable(true, false)
                    }
                    else -> skipExactly(input, size)
                }
                val padding = (512 - (size % 512)) % 512
                skipExactly(input, padding)
                if (totalSize > 0) {
                    val pct = (98 + (written * 2 / totalSize)).toInt().coerceIn(98, 100)
                    if (pct != lastPct) { lastPct = pct; progress?.onProgress(pct) }
                }
            }
        }
    }

    /** Extract the python-build-standalone bundle into the rootfs. Unlike
     *  extractTarGz this is tuned for the bundle: skips terminfo/man (thousands
     *  of symlink entries, runtime-irrelevant), falls back to a hard copy when
     *  the FS rejects symlinks, and REPORTS write failures with the exact path
     *  instead of swallowing them — silent half-extracts surfaced later as
     *  "Invalid file path". */
    private fun extractPythonBundle(archive: File, destination: File, progress: Progress?) {
        val totalSize = archive.length()
        var written = 0L
        var lastPct = -1
        GZIPInputStream(BufferedInputStream(archive.inputStream())).use { input ->
            val header = ByteArray(512)
            var entryIndex = 0
            var extendedName: String? = null
            var extendedSize: Long? = null
            var extendedLink: String? = null
            while (true) {
                readFully(input, header) ?: break
                if (header.all { it == 0.toByte() }) break
                val headerType = header[156].toInt().toChar()
                // PAX/GNU header handling: python-build-standalone tarballs are PAX
                // format — type 'x' blocks carry the REAL name/size for the next
                // entry. Without this, extension data gets written as garbage
                // files and the whole stream desyncs ("Invalid file path" etc.).
                // Supported keys: path, size, linkpath. Everything else ignored.
                if (headerType == 'x' || headerType == 'g' || headerType == 'L' || headerType == 'K') {
                    val extSize = parseOctal(header, 124, 12)
                    val rawData = ByteArray(extSize.toInt())
                    readFully(input, rawData)
                    skipExactly(input, (512 - (extSize % 512)) % 512)
                    if (headerType == 'L' || headerType == 'K') {
                        extendedName = String(rawData).trimEnd('\u0000')
                    } else if (headerType == 'x') {
                        // Robustness: split records on BOTH '\n' (spec) and
                        // '\0' (some writers pad lines with NULs instead).
                        String(rawData).split("\n", "\u0000").forEach { segment ->
                            val line = segment.trim('\u0000')
                            if (line.isBlank()) return@forEach
                            val sp = line.indexOf(' ')
                            if (sp > 0) {
                                val key = line.substring(0, sp)
                                val value = line.substring(sp + 1).replace("\u0000", "").trim()
                                when (key) {
                                    "path" -> extendedName = value
                                    "size" -> extendedSize = value.toLongOrNull()
                                    "linkpath" -> extendedLink = value
                                }
                            }
                        }
                    }
                    continue
                }
                // Tar name fields are NUL-terminated; some archives in the wild have
                // garbage AFTER the terminator. Cut at the FIRST NUL — trimEnd
                // alone can't remove mid-field junk (field-verified: the python
                // bundle's first entry carries "2to3\0in/2to3" in its name).
                fun tarString(bytes: ByteArray, start: Int, len: Int): String {
                    var end = start
                    val stop = start + len
                    while (end < stop && bytes[end] != 0.toByte()) end++
                    return bytes.copyOfRange(start, end).decodeToString()
                }
                val name = tarString(header, 0, 100)
                val prefix = tarString(header, 345, 155)
                val relative = extendedName ?: (if (prefix.isBlank()) name else "$prefix/$name")
                val size = extendedSize ?: parseOctal(header, 124, 12)
                val mode = parseOctal(header, 100, 8)
                val type = headerType
                val linkName = extendedLink ?: tarString(header, 157, 100)
                extendedName = null; extendedSize = null; extendedLink = null
                // Skip bulky runtime-irrelevant trees (symlink storm + docs).
                if (relative.startsWith("python/share/terminfo") ||
                    relative.startsWith("python/share/man")) {
                    if (type != '5') {
                        skipExactly(input, size)
                        skipExactly(input, (512 - (size % 512)) % 512)
                    }
                    continue
                }
                val target = File(destination, relative).normalize()
                require(target.path == destination.path || target.path.startsWith(destination.path + File.separator)) { "invalid archive path" }
                when (type) {
                    '5' -> if (!target.isDirectory) target.mkdirs()
                    '2' -> {
                        target.parentFile?.let { if (!it.isDirectory) it.mkdirs() }
                        try { if (target.exists()) target.delete() } catch (_: Exception) {}
                        try {
                            java.nio.file.Files.createSymbolicLink(target.toPath(), java.nio.file.Paths.get(linkName))
                        } catch (e: Exception) {
                            // FS may reject symlinks; a hard copy keeps python working.
                            val copied = runCatching {
                                val linkTarget = File(target.parentFile, linkName)
                                if (linkTarget.isFile) { linkTarget.copyTo(target, overwrite = true); true } else false
                            }.getOrDefault(false)
                            if (!copied) throw IllegalStateException("symlink $relative -> $linkName: ${e.message}")
                        }
                    }
                    '0', '\u0000' -> {
                        target.parentFile?.let { parent ->
                            if (!parent.isDirectory && !parent.mkdirs()) throw IllegalStateException("mkdir failed: ${parent.path}")
                        }
                        try {
                            FileOutputStream(target).use { output -> copyExactly(input, output, size) }
                        } catch (e: Exception) {
                            throw IllegalStateException("write $relative: ${e.message}", e)
                        }
                        written += size
                        target.setReadable(true, false)
                        if ((mode and 0x40L) != 0L) target.setExecutable(true, false)
                    }
                    else -> skipExactly(input, size)
                }
                val padding = (512 - (size % 512)) % 512
                skipExactly(input, padding)
                entryIndex++
                if (totalSize > 0 && entryIndex % 200 == 0) {
                    val pct = (98 + (written * 2 / totalSize)).toInt().coerceIn(98, 100)
                    if (pct != lastPct) { lastPct = pct; progress?.onProgress(pct) }
                }
            }
        }
    }

    private fun parseOctal(bytes: ByteArray, offset: Int, length: Int): Long =
        bytes.copyOfRange(offset, offset + length).decodeToString().trim('\u0000', ' ').ifBlank { "0" }.trim().toLong(8)

    private fun readFully(input: java.io.InputStream, buffer: ByteArray): ByteArray? {
        var offset = 0
        while (offset < buffer.size) {
            val count = input.read(buffer, offset, buffer.size - offset)
            if (count < 0) return if (offset == 0) null else throw IllegalStateException("truncated tar")
            offset += count
        }
        return buffer
    }

    private fun copyExactly(input: java.io.InputStream, output: FileOutputStream, size: Long): Long {
        var left = size
        val buffer = ByteArray(8192)
        var written = 0L
        while (left > 0) {
            val count = input.read(buffer, 0, minOf(buffer.size.toLong(), left).toInt())
            if (count < 0) throw IllegalStateException("truncated tar entry")
            output.write(buffer, 0, count)
            left -= count
            written += count
        }
        return written
    }

    private fun skipExactly(input: java.io.InputStream, size: Long) { var left = size; while (left > 0) { val skipped = input.skip(left); if (skipped <= 0) { if (input.read() < 0) throw IllegalStateException("truncated tar"); left-- } else left -= skipped } }
}