package com.agentpad.workspace.ai

import android.content.Context
import java.io.File

/**
 * 「下载环境」里所有资源卡片的**唯一真相源**。
 *
 * 之前卡片目录硬编码在 [com.agentpad.workspace.DownloadEnvironmentActivity] 里，
 * AI 看不到，只能瞎猜「有没有某工具链」，常常谎报缺失/存在。
 *
 * 现在目录集中在这里：UI 和 AI 工具（list_env_cards）都读它 —— 保证
 * AI 看到的清单和用户在「设置 → 下载环境」看到的**永远一致**。
 *
 * 只描述「是什么 / 装没装 / 装在哪」，不含下载逻辑（下载逻辑仍在 Activity，
 * 因为它要 Android 的 IO/进度 UI）。
 */
object EnvCatalog {

    /** 一张资源卡片的目录信息。 */
    data class Card(
        val id: String,
        /** 展示名（与 UI 卡片标题完全一致） */
        val title: String,
        /** 一句话说明 */
        val desc: String,
        /** 安装判据：返回 true 表示已部署到沙箱 */
        val installed: (Context) -> Boolean,
    )

    private fun rootfs(context: Context): File = File(context.filesDir, "sandbox/rootfs")

    /** 全部卡片，顺序与「下载环境」页面一致。 */
    fun cards(context: Context): List<Card> = listOf(
        // ---- 基础设施（首次启动自动装，断网被跳过时可在这里补装）----
        Card(
            id = "rootfs",
            title = "系统镜像（Debian 12 ARM64）",
            desc = "沙箱底层 Linux 系统（proot + Debian rootfs，约 30MB）。App 首次启动会自动下载；" +
                "若当时断网被跳过、或提示「沙箱尚未初始化」，在这里补装即可修复（约 30MB）",
        ) { SandboxInstaller.isHealthy(it) },
        Card(
            id = "python3",
            title = "Python 3.12 运行时",
            desc = "预编译 CPython 3.12（aarch64，约 29MB），AI 终端里 python3 / pip3 的基础。" +
                "App 首次启动会自动下载；断网跳过或 `python3: not found` 时在这里补装。需先装系统镜像",
        ) {
            val root = rootfs(it)
            File(root, "usr/bin/python3").isFile ||
                File(root, "usr/local/python3/python/bin/python3").isFile
        },
        Card(
            id = "jre17",
            title = "Java 17 运行时",
            desc = "Temurin JRE 17 (aarch64)，ecj / d8 / apksigner 等 Java 工具的运行环境（约 45MB）。建议先装这个再装工具链",
        ) { File(rootfs(it), "usr/local/jre17/bin/java").isFile },
        Card(
            id = "toolchain",
            title = "编译工具链",
            desc = "ecj / d8 / aapt2 / apksigner / android.jar，部署后 AI 可在终端内编译并打包 APK（约 42MB）",
        ) { File(rootfs(it), "opt/toolchain-pack/compiler").isDirectory },
        Card(
            id = "toolchain_patch_v3",
            title = "工具链补丁 v3（aapt2 成套）",
            desc = "aapt2 35.0.0 + android-35 android.jar 成套替换（修复 illegal map type / R.java missing），含 SELFCHECK.sh 自检（约 27MB）。需先装编译工具链",
        ) { File(rootfs(it), "opt/toolchain-pack/SELFCHECK.sh").isFile },
        Card(
            id = "go_env",
            title = "Go 环境",
            desc = "Go 1.22.2 (aarch64)，含完整 stdlib 源码与 gofmt，部署后 AI 可在终端内 go build / go run（约 38MB）",
        ) {
            File(rootfs(it), "usr/local/go/bin/go").isFile ||
                File(rootfs(it), "tmp/go-env.tar.gz").isFile
        },
        // ⚠ 2026-11-05 移除 Node.js 卡片。
        //
        // 原因（主人实测）：这张卡片只把 node-env.tar.gz 下载到 /tmp，
        // **不会自动解压部署**，需要 AI 手动执行解压命令才算装好。
        // 用户以为装完了，实际 `node` 根本不存在，
        // Codex 启动时才会莫名其妙失败。
        //
        // 现在 Node 运行时由「部署服务 → Codex」自己管理：
        // 离线包里已带 Node，或由 CodexService 按绝对路径探测 + 现场解压。
        // 所以这里不再暴露给用户，避免"装了却没用"的困惑。
        //
        // 如需恢复，原定义：
        //   id = "node_env", title = "Node.js 环境（含 PNPM）",
        //   installed = File(rootfs, "usr/local/node/node").isFile
        //            || File(rootfs, "tmp/node-env.tar.gz").isFile
        Card(
            id = "kotlin_compose",
            title = "Kotlin + Compose 构建器",
            desc = "Kotlin 编译器 2.2.10 + Compose 编译器插件 + 52 个运行时依赖（约 74MB）。装了它，AI 就能在终端里构建 Kotlin/Compose 项目，而不只是 Java 项目",
        ) { File(rootfs(it), "opt/kotlin-toolchain/bin/kotlinc").isFile },
        Card(
            id = "video_buildchain",
            title = "视频工具链",
            desc = "moviepy + ffmpeg 7.0.2 + Pillow/numpy + 中文字体（内含「视频项目」模板）。装了它，「视频项目」会话里的 AI 才能在终端里渲染 out.mp4（约 47MB）",
        ) { File(rootfs(it), "opt/video-buildchain/pypkgs").isDirectory },
        Card(
            id = "ndk",
            title = "C/C++ 原生工具链（NDK）",
            desc = "Android NDK r29 clang 21 + qemu 转译 + Android sysroot，可在 ARM64 主机上编译 Android arm64-v8a 的 C/C++ 程序（.so / 可执行文件）。装了它，AI 才能编原生 UCI 引擎、native 库等（约 87MB）",
        ) {
            File(rootfs(it), "opt/android-ndk-toolchain/bin/clang").isFile ||
                File(rootfs(it), "opt/ndk-toolchain/bin/clang").isFile
        },
        Card(
            id = "rev_toolchain",
            title = "逆向工具链",
            desc = "apktool 3.0.3 + jadx 1.5.6 + dex2jar 2.4 + uber-apk-signer 1.3.0 + Bytecode Viewer + JByteMod（均兼容 JDK 17）。装了它，「逆向模式」会话里的 AI 才能反编译/回编译/签名 APK（约 188MB）",
        ) { File(rootfs(it), "opt/rev-toolchain/bin/apktool").isFile },
    )

    /** 已安装的卡片标题列表。 */
    fun installedTitles(context: Context): List<String> =
        cards(context).filter { runCatching { it.installed(context) }.getOrDefault(false) }.map { it.title }

    /** 卡片总数。 */
    fun total(context: Context): Int = cards(context).size
}
