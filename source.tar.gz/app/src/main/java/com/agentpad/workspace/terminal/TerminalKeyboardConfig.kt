package com.agentpad.workspace.terminal

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Port of OperitTerminalCore's VirtualKeyAction. */
enum class VirtualKeyAction(val persistedValue: String) {
    SEND_TEXT("send_text"),
    TOGGLE_CTRL("toggle_ctrl"),
    TOGGLE_ALT("toggle_alt");

    companion object {
        fun fromPersistedValue(value: String): VirtualKeyAction =
            entries.firstOrNull { it.persistedValue == value } ?: SEND_TEXT
    }
}

data class VirtualKeyConfig(
    val label: String,
    val value: String,
    val action: VirtualKeyAction = VirtualKeyAction.SEND_TEXT
)

data class VirtualKeyboardLayout(val rows: List<List<VirtualKeyConfig>>) {
    init {
        require(rows.size == ROW_COUNT) { "Virtual keyboard must have $ROW_COUNT rows." }
        require(rows.all { it.size == COLUMN_COUNT }) { "Each row must have $COLUMN_COUNT keys." }
    }

    companion object {
        const val ROW_COUNT = 2
        const val COLUMN_COUNT = 7
    }
}

/**
 * Virtual keyboard layout store. Defaults mirror Operit's two-row layout:
 *   ESC  /  -  HOME ↑ END PGUP
 *   TAB CTRL ALT ←  ↓  →  PGDN
 */
class VirtualKeyboardConfigManager private constructor(private val context: Context) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadLayout(): VirtualKeyboardLayout {
        val raw = prefs.getString(PREF_KEY_LAYOUT, null) ?: return defaultLayout()
        return runCatching { parseLayout(raw) }.getOrElse { defaultLayout() }
    }

    fun saveLayout(layout: VirtualKeyboardLayout) {
        prefs.edit().putString(PREF_KEY_LAYOUT, serializeLayout(layout)).apply()
    }

    private fun parseLayout(raw: String): VirtualKeyboardLayout {
        val root = JSONObject(raw)
        val rowsJson = root.getJSONArray(KEY_ROWS)
        val rows = mutableListOf<List<VirtualKeyConfig>>()
        for (i in 0 until rowsJson.length()) {
            val rowJson = rowsJson.getJSONArray(i)
            val row = mutableListOf<VirtualKeyConfig>()
            for (j in 0 until rowJson.length()) {
                val b = rowJson.getJSONObject(j)
                row.add(
                    VirtualKeyConfig(
                        label = b.getString(KEY_LABEL),
                        value = b.optString(KEY_VALUE, ""),
                        action = VirtualKeyAction.fromPersistedValue(
                            b.optString(KEY_ACTION, VirtualKeyAction.SEND_TEXT.persistedValue)
                        )
                    )
                )
            }
            rows.add(row)
        }
        return VirtualKeyboardLayout(rows)
    }

    private fun serializeLayout(layout: VirtualKeyboardLayout): String {
        val rowsJson = JSONArray()
        layout.rows.forEach { row ->
            val rowJson = JSONArray()
            row.forEach { b ->
                rowJson.put(JSONObject().apply {
                    put(KEY_LABEL, b.label)
                    put(KEY_VALUE, b.value)
                    put(KEY_ACTION, b.action.persistedValue)
                })
            }
            rowsJson.put(rowJson)
        }
        return JSONObject().put(KEY_ROWS, rowsJson).toString()
    }

    companion object {
        const val PREFS_NAME = "terminal_settings"
        const val PREF_KEY_LAYOUT = "virtual_keyboard_layout_v1"
        private const val KEY_ROWS = "rows"
        private const val KEY_LABEL = "label"
        private const val KEY_VALUE = "value"
        private const val KEY_ACTION = "action"

        @Volatile private var instance: VirtualKeyboardConfigManager? = null

        fun getInstance(context: Context): VirtualKeyboardConfigManager =
            instance ?: synchronized(this) {
                instance ?: VirtualKeyboardConfigManager(context.applicationContext).also { instance = it }
            }

        fun defaultLayout(): VirtualKeyboardLayout = VirtualKeyboardLayout(
            listOf(
                listOf(
                    VirtualKeyConfig("ESC", "\\e"),
                    VirtualKeyConfig("/", "/"),
                    VirtualKeyConfig("-", "-"),
                    VirtualKeyConfig("HOME", "\\e[H"),
                    VirtualKeyConfig("↑", "\\e[A"),
                    VirtualKeyConfig("END", "\\e[F"),
                    VirtualKeyConfig("PGUP", "\\e[5~")
                ),
                listOf(
                    VirtualKeyConfig("TAB", "\\t"),
                    VirtualKeyConfig("CTRL", "", VirtualKeyAction.TOGGLE_CTRL),
                    VirtualKeyConfig("ALT", "", VirtualKeyAction.TOGGLE_ALT),
                    VirtualKeyConfig("←", "\\e[D"),
                    VirtualKeyConfig("↓", "\\e[B"),
                    VirtualKeyConfig("→", "\\e[C"),
                    VirtualKeyConfig("PGDN", "\\e[6~")
                )
            )
        )

        /** Turn Operit's "\\e" style escapes into real control characters. */
        fun decodeKeyValue(raw: String): String {
            val out = StringBuilder()
            var i = 0
            while (i < raw.length) {
                val c = raw[i]
                if (c == '\\' && i + 1 < raw.length) {
                    when (raw[i + 1]) {
                        'e' -> out.append('\u001b')
                        't' -> out.append('\t')
                        'n' -> out.append('\n')
                        'r' -> out.append('\r')
                        '\\' -> out.append('\\')
                        else -> { out.append('\\'); out.append(raw[i + 1]) }
                    }
                    i += 2
                    continue
                }
                out.append(c)
                i++
            }
            return out.toString()
        }
    }
}