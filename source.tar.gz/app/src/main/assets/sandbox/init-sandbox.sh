#!/system/bin/sh
# PRoot sandbox launcher (mirrors the reference APK layout / aarch64).
# Usage:
#   init-sandbox.sh <PREFIX> <ROOTFS_DIR> <NATIVE_LIB_DIR> [<PROJECT_DIR>] [cmd...]
#   PREFIX         writable scratch dir (must live under files/: tmp + public)
#   ROOTFS_DIR     extracted Debian rootfs
#   NATIVE_LIB_DIR app nativeLibraryDir: executable location that already holds
#                  libproot.so, libproot-xed.so, libtalloc.so, libtalloc.so.2
#                  shipped via jniLibs. We exec proot out of there because files/
#                  is frequently mounted non-executable on Android.
set -u
PREFIX="$1"
ROOTFS_DIR="$2"
NATIVE_LIB_DIR="$3"
PROJECT_DIR="${4:-/nonexistent}"
shift 4 || shift $(( $# )) 2>/dev/null || true

# Libraries (incl. talloc under its soname) all live in the native dir; no copy
# into the possibly non-exec PREFIX is needed.
export LD_LIBRARY_PATH="$NATIVE_LIB_DIR"
export PROOT_TMP_DIR="$PREFIX/tmp"
mkdir -p "$PREFIX/tmp" "$ROOTFS_DIR/tmp" "$PREFIX/public" "$PREFIX/tmp/proot"

# If nativeLibraryDir lacks the talloc symlink name, alias it inside PREFIX as a
# last-resort (kept for unusual devices; native dir normally already has it).
if [ ! -f "$NATIVE_LIB_DIR/libtalloc.so.2" ] && [ -f "$NATIVE_LIB_DIR/libtalloc.so" ]; then
  cp "$NATIVE_LIB_DIR/libtalloc.so" "$NATIVE_LIB_DIR/libtalloc.so.2" 2>/dev/null || cp "$NATIVE_LIB_DIR/libtalloc.so" "$PREFIX/libtalloc.so.2"
  export LD_LIBRARY_PATH="$PREFIX:$NATIVE_LIB_DIR"
fi

# Pick a shell that actually exists AND is executable inside the rootfs.
# /bin/sh and /usr/bin/sh may be symlinks (-> dash); use -x so we never hand
# proot a shell without the exec bit. Fall back across dash/bash/busybox.
ROOTFS_SHELL=
for candidate in /usr/bin/sh /bin/sh /usr/bin/dash /bin/dash /bin/bash /usr/bin/bash /bin/busybox; do
  if [ -x "$ROOTFS_DIR$candidate" ]; then
    ROOTFS_SHELL=$candidate
    break
  fi
done
if [ -z "$ROOTFS_SHELL" ]; then
  echo "init-sandbox: no executable shell found in rootfs" >&2
  exit 127
fi

ARGS="--kill-on-exit"
for system_mnt in /apex /odm /product /system /system_ext /vendor /linkerconfig/ld.config.txt /linkerconfig/com.android.art/ld.config.txt /plat_property_contexts /property_contexts; do
  if [ -e "$system_mnt" ]; then
    system_mnt=$(realpath "$system_mnt")
    ARGS="$ARGS -b ${system_mnt}"
  fi
done
ARGS="$ARGS -b /dev"
ARGS="$ARGS -b /data"
ARGS="$ARGS -b /dev/urandom:/dev/random"
ARGS="$ARGS -b /sys"
# User storage: resolve the real mount path (e.g. /storage/emulated/0) so the
# bind is not defeated by the /sdcard symlink on some ROMs.
for user_mnt in /sdcard /storage; do
  if [ -e "$user_mnt" ]; then
    user_mnt=$(realpath "$user_mnt")
    ARGS="$ARGS -b ${user_mnt}"
  fi
done
ARGS="$ARGS -b $PREFIX"
if [ -d "$PROJECT_DIR" ]; then
  ARGS="$ARGS -b $PROJECT_DIR:/workspace"
fi
ARGS="$ARGS -b $PREFIX/public:/public"
ARGS="$ARGS -b $PREFIX/public:/home"
ARGS="$ARGS -b $PREFIX/public:/root"
ARGS="$ARGS -b $ROOTFS_DIR/tmp:/dev/shm"
ARGS="$ARGS -r $ROOTFS_DIR"
ARGS="$ARGS -0"
ARGS="$ARGS --link2symlink"
ARGS="$ARGS --sysvipc"
ARGS="$ARGS -L"
# Start in the session workspace when it exists (cwd param from the tool
# layer is honored further down via an explicit cd; default = /workspace).
START_CWD="/"
if [ -d "$PROJECT_DIR" ]; then
  START_CWD="/workspace"
fi
ARGS="$ARGS --cwd=$START_CWD"

export PROOT_LOADER="$NATIVE_LIB_DIR/libproot.so"
export PROOT="$NATIVE_LIB_DIR/libproot-xed.so"
export PROOT_LIB_PATH="$PREFIX:$NATIVE_LIB_DIR"
export LD_LIBRARY_PATH="$PROOT_LIB_PATH:$LD_LIBRARY_PATH"

if [ ! -f "$ROOTFS_DIR/etc/resolv.conf" ]; then
  mkdir -p "$ROOTFS_DIR/etc"
  echo 'nameserver 1.1.1.1' > "$ROOTFS_DIR/etc/resolv.conf"
fi
if [ ! -f "$ROOTFS_DIR/linkerconfig/ld.config.txt" ]; then
  mkdir -p "$ROOTFS_DIR/linkerconfig"
  touch "$ROOTFS_DIR/linkerconfig/ld.config.txt"
fi

# Persist the bundled JRE's lib path into every shell session (libjli.so lives
# in /usr/local/jre17/lib; without this `java` fails with
# "libjli.so: cannot open shared object file"). Empty if JRE not installed.
JRE_LIB=""
if [ -d "$ROOTFS_DIR/usr/local/jre17/lib" ]; then
  JRE_LIB="/usr/local/jre17/lib"
fi

if [ $# -eq 0 ]; then
  "$PROOT" $ARGS "$ROOTFS_SHELL" -c 'export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin; export HOME=/root; export TERM=xterm-256color; [ -f /root/.agentpad_rc ] && . /root/.agentpad_rc; [ -n "'"$JRE_LIB"'" ] && export LD_LIBRARY_PATH="'"$JRE_LIB"':${LD_LIBRARY_PATH:-}"; printf "\033[1;36m  AgentPad Terminal\033[0m \033[2m- PRoot Linux sandbox\033[0m\n"; printf "\033[2m  pinch = zoom · swipe up = history · long-press = copy\033[0m\n\n"; exec "$0"' "$ROOTFS_SHELL"
else
  "$PROOT" $ARGS "$ROOTFS_SHELL" -c 'export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin; export HOME=/root; export TERM=xterm-256color; [ -f /root/.agentpad_rc ] && . /root/.agentpad_rc; [ -n "'"$JRE_LIB"'" ] && export LD_LIBRARY_PATH="'"$JRE_LIB"':${LD_LIBRARY_PATH:-}"; exec "$@"' sh "$@"
fi
